import os
import sys

def truncate_file(file_path, size):
    with open(file_path, 'ab') as f:
        f.truncate(int(size[:-1]) * 1024)  # Truncate to size in KB

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python truncate_bin.py <file_path> <size>")
    else:
        truncate_file(sys.argv[1], sys.argv[2])
