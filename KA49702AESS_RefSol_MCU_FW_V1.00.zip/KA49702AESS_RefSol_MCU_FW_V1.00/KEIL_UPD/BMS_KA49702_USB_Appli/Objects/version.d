./objects/version.o: ..\..\SRC\BMS\version.c
