.\objects\startup_m480.o: ..\..\SRC\Library\Device\Nuvoton\M480\Source\ARM\startup_M480.s
