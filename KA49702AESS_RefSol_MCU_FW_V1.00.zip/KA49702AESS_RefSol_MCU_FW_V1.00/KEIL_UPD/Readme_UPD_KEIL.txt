BMS KA49702A ESS Reference Solution MCU Firmware Project Readme
/============================================================================/
I. Project Folder Structure:
/============================================================================/

├─\KEIL_UPD
│  ├─\BMS_KA49702_USB_Appli
│  ├─\BMS_KA49702_USB_Loader
│  ├─post_build_process.py
│  └─truncate_bin.py
└─\SRC
   ├─\Library
   └─\BMS

/============================================================================/
II. Keil Project Compile/Linker Setup
/============================================================================/

Keil version: uVision V5.41.0.0

Keil download:
https://www.nuvoton.com/tool-and-software/ide-and-compiler/keil-mdk-nuvoton-edition/index.html

Application project file:
\KEIL_UPD\BMS_KA49702_USB_Appli\BMS_KA49702_USB_Appli.uvprojx

Loader binary file:
\KEIL_UPD\BMS_KA49702_USB_Loader\Objects\BMS_KA49702_USB_Loader.bin

/============================================================================/
III. Python Post-Build Scripts
/============================================================================/

\KEIL_UPD\post_build_process.py

\KEIL_UPD\truncate_bin.py

Note: These custom post-build Python scripts are verified with Python v3.12.
Please install Python v3.12 or later to ensure compatibility.


/============================================================================/
IV. Source Code
/============================================================================/

1. Library
Library folder contains Nuvoton M480 series MCU peripheral device driver APIs
from Nuvoton MCU BSP package "M480_BSP_CMSIS_V3.06.000".

Download BSP from Nuvoton website:
https://www.nuvoton.com/tool-and-software/software-development-tool/bsp/

2. BMS
Source code for the MCU Application of the BMS KA49702 ESS Reference Solution.

2.1 This BMS Reference Solution support BMIC: KA49702A
#define	BMIC_KA49701A			(0x01u)
#define	BMIC_KA49702A			(0x02u)

#define	BMIC_IC_TYPE			BMIC_KA49702A

Note:
Please keep this BMIC_IC_TYPE define for BMIC KA49702A.


2.2. To include the library file "test_tsk.lib" for the reference solution test mode function, follow these steps:

2.2.1 In Keil project, Project -> Manage -> Project Items...
2.2.2 In [Manage Project Items] -> Project Items -> Groups: select BMS
2.2.3 Under [Manage Project Items] -> Project Items -> Files, click [Add Files...] button to browse the directory
    "\BMS\tsk\" where the "test_tsk.lib" file is located and select Files of type as "Library file (*.lib)"
2.2.4 Select "test_tsk.lib" and click [Add] button to add the file to project items

*Note: The "test_tsk.lib" file is for use in our reference solution platform demo only. If not needed for development,
you can disable the #define BMS_TESTMODE compile option in "main.h" and remove the file "test_tsk.lib".


/============================================================================/
V. Compile & Debug Procedure
/============================================================================/
1. Keil project Compile/Linker Setups

  - In Keil uVision, Project -> Open Project... -> browse to "\KEIL_UPD\BMS_KA49702_USB_Appli" and select "BMS_KA49702_USB_Appli.uvprojx"
    to open application project.

  - Project -> Build Target To compile it. This generates "\KEIL_UPD\BMS_KA49702_USB_Appli\Objects\BMS_KA49702_USB_Appli.bin"
    also post build scripts "\KEIL_UPD\post_build_process.py" generates "\KEIL_UPD\BMS_KA49702_USB_CombinedWCRC.bin"

The file "\KEIL_UPD\BMS_KA49702_USB_CombinedWCRC.bin" includes the loader, application code, and checksum.
This .bin file is used to flash the MCU with the ICP tool or for firmware updates via USB using the GUI.

2. Flash Combined Binary to MCU

Use the Nuvoton ICP tool to flash onto the MCU:
\KEIL_UPD\BMS_KA49702_USB_CombinedWCRC.bin


3. Debug in Keil uVision

To debug the Application (e.g., BMS_KA49702_USB_Appli:

- Go to Flash -> Download to load the .axf file.

- Start debugging via Debug -> Start/Stop Debug Session.
