import zlib

def calculate_crc32(filename, chunk_size=4096):
    """
    Calculate the CRC32 checksum of a file.

    Args:
    - filename: Path to the file whose CRC32 checksum is to be calculated.
    - chunk_size: The size of each chunk to read at a time (in bytes).

    Returns:
    - The CRC32 checksum of the file (as an unsigned number).
    """
    # Initialize the checksum
    checksum = 0

    # Open the file in binary read mode
    with open(filename, 'rb') as file:
        # Read the file in chunks
        while chunk := file.read(chunk_size):
            # Update the checksum with the contents of the chunk
            checksum = zlib.crc32(chunk, checksum)

    # Ensure the checksum is unsigned
    checksum_unsigned = checksum & 0xffffffff

    return checksum_unsigned


def expand_file_with_ff_in_chunks(filename, target_size, chunk_size=4096):
    """
    Expand a binary file to a specified size, filling with 0xFF in chunks.

    Args:
    - filename: Path to the binary file to be expanded.
    - target_size: The desired size of the file in bytes.
    - chunk_size: The size of each chunk to write at a time (in bytes).
    """
    # Determine the current size of the file
    current_size = 0
    with open(filename, 'rb') as file:
        file.seek(0, 2)  # Move to the end of the file
        current_size = file.tell()  # Get the current size

    # Calculate the amount of padding needed
    padding_size = target_size - current_size

    # If the file is already the target size or larger, do nothing
    if padding_size <= 0:
        print(f"File is already {current_size} bytes long, no expansion needed.")
        return

    # Prepare the chunk filled with 0xFF
    chunk =  b'\xFF' * chunk_size

    # Open the file in append binary mode to add the padding
    with open(filename, 'ab') as file:
        # Write full chunks of 0xFF
        full_chunks = padding_size // chunk_size
        #print(f"{full_chunks} Chunks filled with 0xFF.")
        for _ in range(full_chunks):
            file.write(chunk)
        # Write any remaining part of the chunk
        remaining_bytes = padding_size % chunk_size
        if remaining_bytes:
            #print(f"Remaining {remaining_bytes} bytes filled with 0xFF.")
            file.write(b'\xFF' * remaining_bytes)

    print(f"File {filename} expanded to {target_size} bytes with 0xFF.")

# The name of the input files, please change accordingly
filenames = ['..\\BMS_KA49702_USB_Loader\\Objects\\BMS_KA49702_USB_Loader.bin', '.\\Objects\\BMS_KA49702_USB_Appli.bin']

# The name of the output file, please change accordingly
output_filename = '..\\BMS_KA49702_USB_CombinedWCRC.bin'

# Define chunk_size
chunk_size = 4096  # Chunk size: 4KB

# Expand input file filenames[1] to target_size with 0xFF
target_size = 1024 * 108  # 108KB
expand_file_with_ff_in_chunks(filenames[1], target_size, chunk_size)

# Calculate CRC32 checksum of expanded file
crc32_checksum = calculate_crc32(filenames[1])
print(f"CRC32 Checksum of file {filenames[1]}: {crc32_checksum:x}")

# Concatenate input files to output file
# Open the output file in binary write mode
with open(output_filename, 'wb') as outfile:
    # Iterate over the list of filenames
    for fname in filenames:
        # Open each file in binary read mode
        with open(fname, 'rb') as infile:
            # Read and write the contents of the file in chunks
            while chunk := infile.read(chunk_size):
                outfile.write(chunk)

print(f'Files {filenames} have been concatenated into {output_filename}')

# Append the checksum to the outfile
with open(output_filename, 'ab') as file:
    # The checksum is converted to bytes and written to the file
    file.write(crc32_checksum.to_bytes(4, 'little'))  # or \'big\' depending on your needs

print(f"{output_filename} appended with CRC32 Checksum: {crc32_checksum:x}")
