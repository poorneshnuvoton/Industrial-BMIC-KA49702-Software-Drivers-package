/****************************************************************************
#ifdef DOC
File Name		:drv_timer.c
Description		:
Remark			:
Date			:2023/06/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/
#include "NuMicro.h"
#include <stdbool.h>
#include "sys_type.h"
#include "main.h"
#include "drv_timer.h"
#include "drv_bmic.h"

/****************************************************************************
 define macro
*****************************************************************************/
#define	LOOP_500MS_CNT		(20u)			/* 500ms base on 25ms main loop, 500ms/25ms */
#define	LOOP_1000MS_CNT		(40u)			/* 1sec based on 25ms main loop, 1000ms/25ms */

/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/

/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/

/****************************************************************************
 Variable declaration
*****************************************************************************/
volatile UCHAR ucMainLoopCnt = MAIN_LOOP_CNT;
volatile UCHAR ucCnt500ms = LOOP_500MS_CNT;
#if(ESS_DEMO_CB)
volatile UCHAR ucCnt1sec = LOOP_1000MS_CNT;
#endif	/* ESS_DEMO_CB */

volatile UCHAR ucMainLoopFlg = 1u;
volatile UCHAR ucLoop500msFlg = 0u;
#if(ESS_DEMO_CB)
volatile UCHAR ucLoop1secFlg = 0u;
#endif	/* ESS_DEMO_CB */
/****************************************************************************
 Prototype declaration
*****************************************************************************/

/****************************************************************************
FUNCTION	: vTIMER_Init
DESCRIPTION	: Initialization of timer settings
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/06/28
*****************************************************************************/
void vTIMER_Init(void)
{
	/* ++TIMER0 Init start++ */
	/* Enable TIMER module clock */
	CLK_EnableModuleClock(TMR0_MODULE);
	CLK_SetModuleClock(TMR0_MODULE, CLK_CLKSEL1_TMR0SEL_PCLK0, 0u);

	/* Open Timer0 in periodic mode, enable interrupt and 1000 interrupt tick per second */
	TIMER_Open(TIMER0, TIMER_PERIODIC_MODE, 1000u);
	TIMER_EnableInt(TIMER0);
	/* ++TIMER0 Init end++ */

	/* Set TIMER0 IRQ priority */
	NVIC_SetPriority(TMR0_IRQn, 5u);

#if(BMS_DIAGNOSTIC_SUPPORT)
	/* Enable Timer 3 module clock *//* For use in Safety Diagnostic Function*/
    CLK_EnableModuleClock(TMR3_MODULE);
	CLK_SetModuleClock(TMR3_MODULE, CLK_CLKSEL1_TMR3SEL_PCLK1, MODULE_NoMsk);
#endif /* BMS_DIAGNOSTIC_SUPPORT */

}

/****************************************************************************
FUNCTION	: TMR0_IRQHandler
DESCRIPTION	: ISR to handle Timer 0 interrupt event
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/06/28
*****************************************************************************/
void TMR0_IRQHandler(void)
{
	if(TIMER_GetIntFlag(TIMER0) == 1u)
	{
		/* Clear Timer0 time-out interrupt flag */
		TIMER_ClearIntFlag(TIMER0);

		ucMainLoopCnt--;

		if(ucMainLoopCnt ==(UCHAR)0u){
			ucMainLoopCnt = MAIN_LOOP_CNT;
			ucMainLoopFlg = 1u;

			ucCnt500ms --;
			if(ucCnt500ms ==(UCHAR)0u){
				ucCnt500ms = LOOP_500MS_CNT;
				ucLoop500msFlg = 1u;
			}

#if(ESS_DEMO_CB)
			ucCnt1sec --;
			if(ucCnt1sec == (UCHAR)0u){
				ucCnt1sec = LOOP_1000MS_CNT;
				ucLoop1secFlg = 1u;
			}
#endif	/* ESS_DEMO_CB */
		}

	}
}

