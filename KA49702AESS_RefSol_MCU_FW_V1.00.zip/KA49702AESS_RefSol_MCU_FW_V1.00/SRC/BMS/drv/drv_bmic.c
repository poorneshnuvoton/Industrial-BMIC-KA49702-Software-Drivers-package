/****************************************************************************
#ifdef DOC
File Name		:drv_bmic.c
Description		:BMIC 49702 device driver
Remark			:
Date			:2024/03/01
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/
#include "NuMicro.h"
#include <stdbool.h>
#include "sys_type.h"
#include "main.h"
#include "drv_timer.h"
#include "drv_bmic.h"
#if(BMIC_IC_TYPE == BMIC_KA49702A)
#include "bmic_reg_702.h"
#else
#include "bmic_reg_701.h"
#endif /* BMIC_KA49702A */
#include "drv_spi.h"
#include "portio.h"
#if(BMS_DIAGNOSTIC_SUPPORT)
#include "tsk_diagn.h"
#endif /* BMS_DIAGNOSTIC_SUPPORT */
/****************************************************************************
 define macro
*****************************************************************************/
#if(ESS_DEMO_CB)
#define	NON_CELL_BALANCE		(0u)
#define CELL_BALANCE_ON			(1u)

#define CELL_BALANCE_ONOFF_MIN_TIME 	(1u)					/* CB on/off minimum time: 1sec */
#else
#define NON_CELL_BALANCE		(0u)
#define ODD_CELL_BALANCE		(1u)
#define CELL_BALANCE_OFF		(2u)
#define EVEN_CELL_BALANCE		(3u)

#define CELL_BALANCE_ONOFF_MIN_TIME 	BMS_CTL_TM_500MSEC		/* CB on/off minimum time: 500ms */
#endif	/* ESS_DEMO_CB */

#define BMIC_DEAD_DETECT_CNT		(10u)


/* usBMIC_AdState	*/
#define NOT_FIN_ADV_LATCH			(0x01u)			/* not finish ADV Latch		*/
#define NOT_FIN_ADIH_LATCH			(0x02u)			/* not finish ADIH Latch  */
#define AD_AVE_DATA_NG				(0x04u)			/* SPI NG to receive AD   */


/*usSPI_ComAtLeastOnceFlg	*/
#define COMM_MULTI_READ				(0x0001u)
#define COMM_AD_CELLV				(0x0002u)
#define COMM_AD_TMONI				(0x0004u)
#define COMM_AD_IHIGH				(0x0008u)
#define COMM_AD_ILOW				(0x0010u)
#define COMM_AD_OTHER				(0x0020u)
#define COMM_RECEIVE_ALL			(0x0037u)


#define	BMIC_WAIT_1US				((USHORT)4u)
#define	MS_100US					(10u)			/* 1000us/100us = 10 */
#define BMIC_SPIWAIT_TIMEOUT		(1000u)			/* ~250us */

#if(BMIC_IC_TYPE == BMIC_KA49702A)
#define	BMIC_CTRL_INITTBL_NUM		(27u)
#else
#define	BMIC_CTRL_INITTBL_NUM		(26u)
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

#define	MAX_ADIL_LOG_NUM	(ADIL_FAST_CYCLE_500MS * 2u * 256u) 	/* ADIL data log size: 256sec */
/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/
/*--------------------------------------------*/
typedef struct {
	UCHAR	ucTxBuf[BMIC_PACKET_BUF_SIZE];
	UCHAR	ucRxBuf[BMIC_PACKET_BUF_SIZE];

	USHORT	usRegData[DATA_ELEMENTSIZE];

	UCHAR	ucCellList[MAX_CELL_NUM];			/* List of connect cell	*/
	UCHAR	ucOpenCellList[MAX_CELL_NUM];		/* List of open cell	*/

	USHORT	usCVAD[MAX_CELL_NUM];				/* Cell voltage ADC */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	USHORT	usVPACKAD;							/* usVPACKAD voltage ADC */
#else
	USHORT	usCV17SAD;							/* CV17S_AD voltage ADC */
#endif /* BMIC_KA49702A */
	USHORT	usVdd50AD;							/* Vdd50 voltage ADC */
	USHORT	usVdd15AD;							/* Vdd15 voltage ADC */
	USHORT	usVREGEXTAD;						/* REGEXT voltage ADC */

	USHORT	usVREF2AD;							/* VREF2 voltage ADC */
	#if(0)	/* VREF1 not used */
	USHORT	usVREF1AD;							/* VREF1 voltage ADC */
	#endif

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	USHORT	usGPIOH1AD;							/* GPIOH1 voltage ADC */
	USHORT	usGPIOH2AD;							/* GPIOH2 voltage ADC */
#else
	USHORT	usGPIO1AD;							/* GPIO1 voltage ADC */
	USHORT	usGPIO2AD;							/* GPIO2 voltage ADC */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	SHORT	sCVIL_AD;							/* Slow-speed current (coulomb counter)ADC */
	USHORT	usTmoniAD[THERMISTOR_NUM];			/* Thermistor voltage ADC */

	UCHAR	ucBMIC_Ctrl_Status;					/* BMIC Control Status */

	UCHAR	ucBMIC_Cell_Balancer;				/* Target line of cell balance */
	UCHAR	ucCellBalancingCounter;				/* Cell balance control time	*/
	UCHAR	ucCellBalancingOnTime;				/* Cell balance ON timing */
	UCHAR	ucCellBalancingOffTime;				/* Cell balance OFF timing */
	ULONG	ulBMIC_Cell_Balancetgt;				/* Target cell of cell balance request	*/
	ULONG	ulBMIC_Cell_Balancetgt_set;			/* Target cell of cell balance */
	ULONG	ulBMIC_CBL_Odd_Mask;

	ULONG	ulRfuse[MAX_THERMISTOR_NUM];

	UCHAR	ucBMIC_AdState;

	USHORT	usSPI_ComAtLeastOnceFlg;
	UCHAR	ucBMIC_SPI_status;
	UCHAR	ucBMIC_SPI_err_count;
	UCHAR	ucBMIC_SPI_err_detail;
	UCHAR	ucBMIC_ComOffCount;
#if(0)
	UCHAR	ucBMIC_ShutdownReq;
#endif
#if(BMS_STANDBYMODE_SUPPORT)
	UCHAR	ucBMIC_OpeMode;
	UCHAR	ucBMIC_OpeMode_Req;
#endif	/* BMS_STANDBYMODE_SUPPORT */
	ULONG	ulBMIC_ChkSpiMisoCount;
	bool	bBMIC_NgSpiMiso;
	UCHAR	ucBMIC_DiagNReq;					/* Safety Diagnostic request */
}TBMIC_Drv;


/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/
/****************************************************************************
 Variable declaration
*****************************************************************************/
static TBMIC_Drv	BMIC_Drv;
static UCHAR		BMIC_SpiBusy;
TBMICCellConf		BMICCellConf;
TBMIC_Info			BMIC_Info;
TBMICSetParam 		BMICSetParam;


static float fBMIC_CurClbGain;
static UCHAR ucCurErr_ClrTime;

/*static USHORT	SHUNT_mohm = 1u;*/
static USHORT	SHUNT_uohm = 1000u;			/* default: 1000uOhm (1mOhm), 500/1000/1500/2000/3000/5000 uOhm, please match actual Shunt Resistor value */

static UCHAR	iads_complete;
static UCHAR	adc_complete;

#if(0/*BMS_STANDBYMODE_SUPPORT*/)
USHORT usActiveComm_cnt = 0u;				/* Intermittent operation in Standby/LowPower mode active SPI communication counter */
#endif /* BMS_STANDBYMODE_SUPPORT */

static USHORT	usADIL_Data[MAX_ADIL_LOG_NUM];				/* Ring buffer to log ADIL data */
static USHORT	usADIL_Log_WrPnt;							/* ADIL data ring buffer write pointer */
static USHORT	usADIL_Log_RdPnt;							/* ADIL data ring buffer read pointer */

#define	ADIL_DATA_OVERLAP_MASK	(0x01u)						/* b0:  0 (continuous data), 1 (overlapped data) */
#define	ADIL_DATA_FAST_MASK		(0x06u)						/* b2~1:  00 (2 valid data for 250ms conversion time), 01 (8 valid data for 62.5ms conversion time), 10 (16 valid data for 31.25ms conversion time) */
#define	ADIL_DATA_250MS			(0x00u)						/* b2~1:  00 (2 valid data for 250ms conversion time) */
#define	ADIL_DATA_62_5MS		(0x02u)						/* b2~1:  01 (8 valid data for 62.5ms conversion time) */
#define	ADIL_DATA_31_25MS		(0x04u)						/* b2~1:  10 (16 valid data for 31.25ms conversion time) */

#if(BMIC_IC_TYPE == BMIC_KA49702A)
static UCHAR	ucADIL_LogStatus = (UCHAR)((ADCTL2_INI & ADILSEL_MASK) >>13u);	/* ADIL data log Status Flag, Fast Mask bit depend on ADCTL2 bit 14,13 (ADIL_SEL[1:0])init setting */
#else
static UCHAR	ucADIL_LogStatus = (UCHAR)((ADCTL_INI & ADILSEL_MASK) >>13u);	/* ADIL data log Status Flag, Fast Mask bit depend on ADCTL bit 14,13 (ADIL_SEL[1:0])init setting */
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */

static UCHAR ucADILLogReadStart = 0u;

/****************************************************************************
 Prototype declaration
*****************************************************************************/
static void vBMIC_Register_Init(void);
void		vBMIC_InitParams(void);
static UCHAR 	ucBMIC_Make_CellList(void);
UCHAR		ucBMIC_CellConf_Init(void);
void		vBMIC_Ctrl_Startup(void);
void		vBMIC_Ctrl_Normal(void);
void		vBMIC_Ctrl_SpiErr(void);
void		vBMIC_Ctrl_Restart(void);
void		vBMIC_Ctrl_Shutdown(void);
void		vBMIC_ShutdownRequest(void);
#if(BMS_DIAGNOSTIC_SUPPORT)
void 		vBMIC_Ctrl_Diagnostic(void);
void 		vBMIC_Diagnostic_Req(UCHAR req);
#endif /*BMS_DIAGNOSTIC_SUPPORT*/

void		vBMIC_SetCtrlStatus(void);
UCHAR	getBMIC_Ctrl_Status(void);

static void 	vBMIC_ADC_ctrl(void);
static void 	vBMIC_VolADCRead(void);
static void		vBMIC_CalcMeasuredVol(void);
static void		vBMIC_CalcMeasuredTemp(void);
static void		vBMIC_CalcMeasuredCur(void);
void		vBMIC_Error_Ctrl(void);
void		vBMIC_Register_ReadCtrl(void);


UCHAR 	ucChk_Cellbalance_Req(void);
void		vBMIC_CBL_Control(void);
void		vBMICRegInitRead(void);
UCHAR		ucGetBMIC_SDO_In(void);
#if(0)	/* BMIC GPIO port need to select ADIRQ2 output */
UCHAR 	ucGetBMIC_ADIRQ2_In(void);
#endif
void		vBMICWriteReg(UCHAR addr, USHORT data);
void		vBMICWriteReg_Mask(UCHAR addr, USHORT usdata, USHORT usMask, UCHAR ucdata);
USHORT	usBMICReadReg(UCHAR addr);
void 		vBMICReadReg_Multi(UCHAR addr, UCHAR num);
UCHAR		ucBMIC_Check_SPI_status(void);
UCHAR		ucBMIC_Check_SPI_status_crc(UCHAR crc_chk);
bool		bBMICCheckSpiResult(void);
USHORT	usBMICReferRegData(UCHAR addr);
void		vBMICInputRecvData(UCHAR addr, USHORT usdata);
UCHAR		ucBMICRegInitChk(void);
UCHAR		ucBMICChk_CtrlReg(void);
UCHAR		ucBMICReadFuse(void);
ULONG	ulBMICCalcRfuse(SHORT sfuse);
SHORT		sCalcTemperature_01deg(USHORT vtm_ad, UCHAR num);
SHORT		iLookupTemp_01deg(ULONG rth);

static ULONG ulLookupTemp_Resistance(short stemp);
static ULONG ulGetTmoniMaxRfuse(UCHAR ucgrp);
static ULONG ulGetTmoniMinRfuse(UCHAR ucgrp);

UCHAR		ucGetBMICcrc(UCHAR *buf, UCHAR size);
void		vBMIC_Wait(USHORT usdata);
void		vBMIC_CBL_Init(void);
void		Wait_msec(USHORT time_inms);
void		BMIC_SpiRelease(void);
bool		bBMIC_SpiTake(USHORT timeout);

void vBMIC_Set_GPIO_PortSel(UCHAR ucgpio, UCHAR ucport);
void vLogBMIC_ADIL_Data(USHORT usdata);
void vSetADIL_LogCycle(void);

/****************************************************************************
 define data table
*****************************************************************************/
/*--------------------------------------------*/
typedef struct {
	UCHAR m_ucreg;				/* Write Reg Address */
	USHORT	m_usdata;			/* Write Data 			*/
}TYPE_INITTBL;

/*--------------------------------------------*/
const static TYPE_INITTBL stCtrlReg_Init_BMIC[BMIC_CTRL_INITTBL_NUM] ={
	{ PWR_CTRL_ADDR,	PWR_CTRL_INI	},
	{ REG_INT_EN_ADDR,	REG_INT_EN_INI	},
	{ SPIWD_CTRL_ADDR,	SPIWD_CTRL_INI	},
	{ FDRV_CTRL_ADDR,	FDRV_CTRL_INI	},
	{ CVSEL1_ADDR,		CVSEL1_INI		},
	{ CVSEL2_ADDR,		CVSEL2_INI		},
	{ GVSEL_ADDR,		GVSEL_INI		},

	{ FUSE_CTL1_ADDR,	FUSE_CTL1_INI	},
	{ FUSE_CTL2_ADDR,	FUSE_CTL2_INI	},
	{ FUSE_CTL3_ADDR,	FUSE_CTL3_INI	},

	{ OP_MODE_ADDR, 	OP_MODE_INI		},

	{ GPIO_CTL1_ADDR,	GPIO_CTL1_INI	},
	{ GPIO_CTL2_ADDR,	GPIO_CTL2_INI	},
	{ GPIO_CTL3_ADDR,	GPIO_CTL3_INI	},

	{ GPIO_CTL4_ADDR,	GPIO_CTL4_INI	},
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	{ OSC_CTL_ADDR,		OSC_CTL_INI		},
#else
	{ GPIO_CTL5_ADDR,	GPIO_CTL5_INI	},
#endif /* BMIC_KA49702A */
	{ ALARM_CTL1_ADDR, ALARM_CTL1_INI	},
	{ ALARM_CTL2_ADDR, ALARM_CTL2_INI	},
	{ ALARM_CTL3_ADDR, ALARM_CTL3_INI	},
	{ ALARM_CTL4_ADDR, ALARM_CTL4_INI	},

	{ CBSEL_ADDR, 		CBSEL_INI		},
	{ CBSEL_17_ADDR, 	CBSEL_17_INI	},
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	{ ADCTL1_ADDR, 		ADCTL1_INI 		},
	{ ADCTL2_ADDR, 		ADCTL2_INI		},
	{ GPOH_CTL_ADDR,	GPOH_CTL_INI	},
	{ OTUT_CTRL_ADDR,	OTUT_CTRL_INI	},
#else
	{ OTHCTL_ADDR, 		OTHCTL_INI 		},
	{ ADCTL_ADDR, 		ADCTL_INI		},
	{ FDRV_CTRL2_ADDR,	FDRV_CTRL2_INI	},
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */
	{ DIAG_EN_ADDR,		DIAG_EN_INI	 	},


};

/****************************************************************************
FUNCTION	: vBMIC_CtrlParameter_Init
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
static void vBMIC_CtrlParameter_Init(void)
{
	UCHAR i = 0u;

	BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_STARTUP;

	BMIC_Info.BMICMeasured = false;

	BMIC_Info.ulBatPackErr = 0u;
	BMIC_Info.ulBatPackErrLog = 0u;

	fBMIC_CurClbGain = 1.0;
	BMIC_Drv.ulBMIC_Cell_Balancetgt = 0u;

#if(ESS_DEMO_CB)
	BMIC_Drv.ucCellBalancingOnTime = CELL_BALANCE_ONOFF_MIN_TIME;			/* default: 1sec */
	BMIC_Drv.ucCellBalancingOffTime = CELL_BALANCE_ONOFF_MIN_TIME;			/* default: 1sec */
#else
	BMIC_Drv.ucCellBalancingOnTime = BMS_CTL_TM_1SEC;		/* default: 1000ms */
	BMIC_Drv.ucCellBalancingOffTime = BMS_CTL_TM_1SEC;		/* default: 1000ms */
#endif	/* ESS_DEMO_CB */

	for(i=0u; i< THERMISTOR_NUM; i++){
		BMIC_Drv.usTmoniAD[i] = 0u;
	}

#if(BMS_STANDBYMODE_SUPPORT)
	BMIC_Drv.ucBMIC_OpeMode = BMIC_OPEMODE_ACTIVE;
#endif	/* BMS_STANDBYMODE_SUPPORT */

	BMICSetParam.usOVInfo_vol = 4200u;				/* OV threshold: 4200mV */
	BMICSetParam.ucOVInfo_delay1 = 4u;				/* OV delay: 4 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms (Active mode) */
	BMICSetParam.ucOVInfo_delay2 = 1u;				/* OV delay: 1 times of voltage measurement cycle of 4/8/16/32 cycles * ADIL_SEL setting time (Stby/LP mode)*/
	BMICSetParam.usOVInfo_hys = 100u;				/* OV hysteresis: 100mV */
	BMICSetParam.usUVInfo_vol = 1800u;				/* UV threshold: 1800mV */
	BMICSetParam.ucUVInfo_delay1 = 4u;				/* UV delay: 4 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms (Active mode) */
	BMICSetParam.ucUVInfo_delay2 = 1u;				/* UV delay: 1 times of voltage measurement cycle of 4/8/16/32 cycles * ADIL_SEL setting time (Stby/LP mode) */
	BMICSetParam.usUVInfo_hys = 100u;				/* UV hysteresis: 100mV */

	BMICSetParam.usOCCInfo_cur = 5u;				/* OCC threshold: 5A */
	BMICSetParam.usOCCInfo_delay = 10u;				/* OCC delay: 10ms */
	BMICSetParam.usOCDInfo_cur = 10u;				/* OCD threshold: 10A */
	BMICSetParam.usOCDInfo_delay = 10u;				/* OCD delay: 10ms */
	BMICSetParam.usSCDInfo_cur = 20u;				/* SCD threshold: 20A */
	BMICSetParam.ulSCDInfo_delay = 62500u;			/* SCD delay: 62500nsec (62.5us) */

	BMICSetParam.sOTC1Info_temp = OT_TEMP_THINIT;	/* OTC detection threshold : 80 Cdegree  (for Grp1) */
	BMICSetParam.sOTC2Info_temp = OT_TEMP_THINIT;	/* OTC detection threshold :  80 Cdegree (for Grp2) */
	BMICSetParam.ucOTCInfo_delay1 = 4u;				/* OTC ALARM delay :4 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms. (Active mode) */
	BMICSetParam.ucOTCInfo_delay2 = 1u;				/* OTC ALARM delay :1 times of voltage measurement cycle of 4/8/16/32 cycles * ADIL_SEL setting(Stby/LP mode) */
	BMICSetParam.usOTCInfo_hys = 100u;				/* OTC detection hysteresis level : 100mV */

	BMICSetParam.sOTD1Info_temp	= OT_TEMP_THINIT;	/* OTD detection threshold : 80 Cdegree (for Grp1) */
	BMICSetParam.sOTD2Info_temp = OT_TEMP_THINIT;	/* OTD detection threshold : 80 Cdegree (for Grp2) */
	BMICSetParam.ucOTDInfo_delay1 = 4u;				/* OTD ALARM delay :4 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms. (Active mode) */
	BMICSetParam.ucOTDInfo_delay2 = 1u;				/* OTD ALARM delay :1 times of voltage measurement cycle of 4/8/16/32 cycles * ADIL_SEL setting(Stby/LP mode) */
	BMICSetParam.usOTDInfo_hys = 100u;				/* OTD detection hysteresis level : 100mV */

	BMICSetParam.sUTC1Info_temp = UT_TEMP_THINIT;	/* Under Temperature in Charge (UTC) detection threshold -10 Cdegree(for Grp1) */
	BMICSetParam.sUTC2Info_temp	= UT_TEMP_THINIT;	/* UTC detection threshold : -10 Cdegree (for Grp2) */
	BMICSetParam.ucUTCInfo_delay1  = 4u;			/* UTC ALARM delay :4 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms. (Active mode) */
	BMICSetParam.ucUTCInfo_delay2  = 1u;			/* UTC ALARM delay :1 times of voltage measurement cycle of 4/8/16/32 cycles * ADIL_SEL setting(Stby/LP mode) */
	BMICSetParam.usUTCInfo_hys = 100u;				/* UTC detection hysteresis level : 100mV */

	BMICSetParam.sUTD1Info_temp = UT_TEMP_THINIT;	/* UTD detection threshold : -10 Cdegree (for Grp1) */
	BMICSetParam.sUTD2Info_temp	= UT_TEMP_THINIT;	/* UTD detection threshold : -10 Cdegree (for Grp2) */
	BMICSetParam.ucUTDInfo_delay1 = 4u;				/* UTD ALARM delay :4 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms. (Active mode) */
	BMICSetParam.ucUTDInfo_delay2 = 1u;				/* UTD ALARM delay :1 times of voltage measurement cycle of 4/8/16/32 cycles * ADIL_SEL setting(Stby/LP mode) */
	BMICSetParam.usUTDInfo_hys = 100u;				/* UTD detection hysteresis level : 100mV */

	BMICSetParam.usOTUT_ITHInfo_mA = 175u * OTUT_ITH_INI; /* Current Threshold to switch between Charging & Discharging: +/- 3*175mA */

	BMICSetParam.usOTUT_MSK = ((OP_MODE_INI) & OTUTMSK_MASK);	/* UTD|UTC|OTD|OTC protection: 0 enable, 1 disable */


	#if(1)	/* 17cells */
	BMICCellConf.ulCellPos = 0x0001FFFFu;			/* assume connected 17 cells */
	BMICCellConf.ucSeriesCount = 17u;				/* assume connected 17 cells */
	#endif

	#if(0)	/* 4cells */
	BMICCellConf.ulCellPos = 0x00018003u;			/* assume connected 4 cells */
	BMICCellConf.ucSeriesCount = 4u;				/* assume connected 4 cells */
	#endif

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	BMICCellConf.ucTmoniTempCount = 3u;				/* TMONIx temperature measurement: 3 */
	BMICCellConf.ulTmoniTempPos = 0x31u;			/* TMONI1, 5 & 6 to measure temperature */
#else
	BMICCellConf.ucTmoniTempCount = 5u;				/* TMONIx temperature measurement: 5 */
	BMICCellConf.ulTmoniTempPos = 0x1Fu;			/* TMONI1, 2, 3, 4 & 5 to measure temperature */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
}

/****************************************************************************
FUNCTION	: usBMIC_Calc_OVCTL1
DESCRIPTION	: Set BMIC register OVCTL1 according to BMIC set parameters: usOVInfo_hys, ucOVInfo_delay1, ucOVInfo_delay2, usOVInfo_vol
INPUT		:
OUTPUT		:
UPDATE		: 2023/11/17
DATE		: 2023/10/19
*****************************************************************************/
static USHORT usBMIC_Calc_OVCTL1(void)
{
	USHORT ret = OVCTL1_INI;
	UCHAR valid = 1u;
	USHORT ov_hys = 0u, ovth = 0u;
	USHORT ov_dly1, ov_dly2 = 0u;
	USHORT dat = 0u;

	dat = BMICSetParam.usOVInfo_hys;
	if(dat < 25u){
		dat = 25u;
	} else if(dat > 200u){
		dat = 200u;
	}
	ov_hys = (dat - 25u) / 25u;						/* ov_hys = (usOVInfo_hys(mv) - 25mV) / 25u */

	switch(BMICSetParam.ucOVInfo_delay1){
		case 4u:
			ov_dly1 = 0u;					/* OV_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
		case 8u:
			ov_dly1 = 1u;					/* OV_DLY1: 8 times of voltage measurement cycle (Active mode)	*/
			break;
		case 16u:
			ov_dly1 = 2u;					/* OV_DLY1: 16 times of voltage measurement cycle (Active mode)	*/
			break;
		case 32u:
			ov_dly1 = 3u;					/* OV_DLY1: 32 times of voltage measurement cycle (Active mode)	*/
			break;
		default:
			ov_dly1 = 0u;					/* OV_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
	}

	switch(BMICSetParam.ucOVInfo_delay2){
		case 1u:
			ov_dly2 = 0u;					/* OV_DLY2: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
		case 2u:
			ov_dly2 = 1u;					/* OV_DLY2: 2 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 4u:
			ov_dly2 = 2u;					/* OV_DLY2: 4 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 8u:
			ov_dly2 = 3u;					/* OV_DLY2: 8 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		default:
			ov_dly2 = 0u;					/* OV_DLY2: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
	}

	if(BMICSetParam.usOVInfo_vol >= 2000u){
		dat = BMICSetParam.usOVInfo_vol;
		if(dat > 4500u){
			dat = 4500u;
		}
		ovth = (dat - 2000u) / 50u + 2u;					/* OVTH = (usOVInfo_vol(mV) - 2000(mV)) / 50(mV) + 2(offset) */
	} else {
		valid = 0u;
	}

	if(valid == 1u){
		ret = (USHORT)(ov_hys << 12u)| (USHORT)(ov_dly2 << 10u)| (USHORT)(ov_dly1 << 8u)|(USHORT) ovth;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: vBMIC_Send_OVCTL1
DESCRIPTION	: Set Over Voltage hystereis, delay1, delay2 and threhold of BMIC OVCTL1 register
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/19
*****************************************************************************/
void vBMIC_Send_OVCTL1(void)
{
	USHORT data = 0u;
	data = usBMIC_Calc_OVCTL1();
	ucBMIC_Send_Req(OVCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
}

/****************************************************************************
FUNCTION	: usBMIC_Calc_UVCTL1
DESCRIPTION	: Set BMIC register UVCTL1 according to BMIC set parameters: usUVInfo_hys, ucUVInfo_delay1, ucUVInfo_delay2, usUVInfo_vol
INPUT		:
OUTPUT		:
UPDATE		: 2023/11/17
DATE		: 2023/10/19
*****************************************************************************/
static USHORT usBMIC_Calc_UVCTL1(void)
{
	USHORT ret = UVCTL1_INI;
	UCHAR valid = 1u;
	USHORT uv_hys = 0u, uvth = 0u;
	USHORT uv_dly1, uv_dly2 = 0u;
	USHORT dat = 0u;

	dat = BMICSetParam.usUVInfo_hys;
	if(dat < 25u){
		dat = 25u;
	} else if(dat > 200u){
		dat = 200u;
	}
	uv_hys = (dat - 25u) / 25u;						/* uv_hys = (usUVInfo_hys(mv) - 25mV) / 25u */

	switch(BMICSetParam.ucUVInfo_delay1){
		case 4u:
			uv_dly1 = 0u;					/* UV_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
		case 8u:
			uv_dly1 = 1u;					/* UV_DLY1: 8 times of voltage measurement cycle (Active mode)	*/
			break;
		case 16u:
			uv_dly1 = 2u;					/* UV_DLY1: 16 times of voltage measurement cycle (Active mode)	*/
			break;
		case 32u:
			uv_dly1 = 3u;					/* UV_DLY1: 32 times of voltage measurement cycle (Active mode)	*/
			break;
		default:
			uv_dly1 = 0u;					/* UV_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
	}

	switch(BMICSetParam.ucUVInfo_delay2){
		case 1u:
			uv_dly2 = 0u;					/* UV_DLY2: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
		case 2u:
			uv_dly2 = 1u;					/* UV_DLY2: 2 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 4u:
			uv_dly2 = 2u;					/* UV_DLY2: 4 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 8u:
			uv_dly2 = 3u;					/* UV_DLY2: 8 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		default:
			uv_dly2 = 0u;					/* UV_DLY2: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
	}

	if(BMICSetParam.usUVInfo_vol >= 500u){
		dat = BMICSetParam.usUVInfo_vol;
		if(dat > (USHORT)3000){
			dat = 3000u;
		}
		uvth = (dat - 500u) / 50u;			/* UVTH = (usUVInfo_vol(mV) - 500(mV)) / 50(mV) */
	} else {
		valid = 0u;
	}

	if(valid == 1u){
		ret = (USHORT)(uv_hys << 12u)| (USHORT)(uv_dly2 << 10u)| (USHORT)(uv_dly1 << 8u)|(USHORT) uvth;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: vBMIC_Send_UVCTL1
DESCRIPTION	: Set Under Voltage hystereis, delay1, delay2 and threhold of BMIC UVCTL1 register
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/19
*****************************************************************************/
void vBMIC_Send_UVCTL1(void)
{
	USHORT data = 0u;
	data = usBMIC_Calc_UVCTL1();
	ucBMIC_Send_Req(UVCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
}


/****************************************************************************
FUNCTION	: usGetOT_Threshold
DESCRIPTION	: Get OT threshold settings based on temperature setting and TMONI group's maximum Rfuse
INPUT		: SHORT tempth, UCHAR tmonigrp
OUTPUT		: USHORT
UPDATE		: 2023/11/23
DATE		: 2023/10/30
*****************************************************************************/
static USHORT usGetOT_Threshold(SHORT tempth, UCHAR tmonigrp)
{
	USHORT ot_th;
	ULONG ntc_resistance;
	ULONG ultmoni_maxpullup;
	ULONG ulVol_th_mv;

	ntc_resistance = ulLookupTemp_Resistance(tempth);

	ultmoni_maxpullup = ulGetTmoniMaxRfuse(tmonigrp);

	ulVol_th_mv = (ULONG)((ntc_resistance * 5000u) / (ntc_resistance + ultmoni_maxpullup));
	ot_th = (USHORT)(ulVol_th_mv*1000u / (ULONG)19531);			/* step: 5.0V / 256 = 0.0019531 */
	if(ot_th > 0xFFu){
		ot_th = 0xFFu;
	}
	return(ot_th);
}


/****************************************************************************
FUNCTION	: usGetUT_Threshold
DESCRIPTION	: Get UT threshold settings based on temperature setting and TMONI group's minimum Rfuse
INPUT		: SHORT tempth, UCHAR tmonigrp
OUTPUT		: USHORT
UPDATE		: 2023/11/23
DATE		: 2023/10/30
*****************************************************************************/
static USHORT usGetUT_Threshold(SHORT tempth, UCHAR tmonigrp)
{
	USHORT ut_th;
	ULONG ntc_resistance;
	ULONG ultmoni_minpullup;
	ULONG ulVol_th_mv;

	ntc_resistance = ulLookupTemp_Resistance(tempth);

	ultmoni_minpullup = ulGetTmoniMinRfuse(tmonigrp);

	ulVol_th_mv = (ULONG)((ntc_resistance * 5000u) / (ntc_resistance + ultmoni_minpullup));
	ut_th = (USHORT)(ulVol_th_mv*1000u / (ULONG)19531);			/* step: 5.0V / 256 = 0.0019531 */
	if(ut_th > 0xFFu){
		ut_th = 0xFFu;
	}
	return(ut_th);
}

/****************************************************************************
FUNCTION	: usBMIC_Calc_OTCCTL1
DESCRIPTION	: Set BMIC register OTCCTL1 according to BMIC set parameters: usOTCInfo_hys, sOTC1Info_temp, ucOTCInfo_delay1, ucOTCInfo_delay2
INPUT		:
OUTPUT		:
UPDATE		: 2023/11/17
DATE		: 2023/10/30
*****************************************************************************/
static USHORT usBMIC_Calc_OTCCTL1(void)
{
	USHORT ret = OTCCTL1_INI;
	UCHAR valid = 1u;
	USHORT otc_hys = 0u, otcth = 0u;
	USHORT otc_dly1, otc_dly2 = 0u;
	USHORT dat = 0u;
	SHORT sOT_Temp;

	dat = BMICSetParam.usOTCInfo_hys;
	if(dat < 25u){
		dat = 25u;
	} else if(dat > 200u){
		dat = 200u;
	}
	otc_hys = (dat - 25u) / 25u;						/* otc_hys = (usOTCInfo_hys(mv) - 25mV) / 25u */

	switch(BMICSetParam.ucOTCInfo_delay1){
		case 4u:
			otc_dly1 = 0u;					/* OTC_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
		case 8u:
			otc_dly1 = 1u;					/* OTC_DLY1: 8 times of voltage measurement cycle (Active mode)	*/
			break;
		case 16u:
			otc_dly1 = 2u;					/* OTC_DLY1: 16 times of voltage measurement cycle (Active mode)	*/
			break;
		case 32u:
			otc_dly1 = 3u;					/* OTC_DLY1: 32 times of voltage measurement cycle (Active mode)	*/
			break;
		default:
			otc_dly1 = 0u;					/* OTC_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
	}

	switch(BMICSetParam.ucOTCInfo_delay2){
		case 1u:
			otc_dly2 = 0u;					/* OTC_DLY2: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
		case 2u:
			otc_dly2 = 1u;					/* OTC_DLY2: 2 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 4u:
			otc_dly2 = 2u;					/* OTC_DLY2: 4 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 8u:
			otc_dly2 = 3u;					/* OTC_DLY2: 8 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		default:
			otc_dly2 = 0u;					/* OTC_DLY2: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
	}

	sOT_Temp = BMICSetParam.sOTC1Info_temp;
	if(sOT_Temp >= OT_TEMP_THMIN){
		if(sOT_Temp > OT_TEMP_THMAX){
			sOT_Temp = OT_TEMP_THMAX;
		}
		otcth = usGetOT_Threshold(sOT_Temp, TMONI_GROUP1);
	} else {
		valid = 0u;
	}

	if(valid == 1u){
		ret = (USHORT)(otc_hys << 12u)| (USHORT)(otc_dly2 << 10u)| (USHORT)(otc_dly1 << 8u)|(USHORT) otcth;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: vBMIC_Send_OTCCTL1
DESCRIPTION	: Set Over Temperature Charge Voltage hysteresis, delay1, delay2 and threhold of BMIC OTCCTL1 register
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/30
*****************************************************************************/
void vBMIC_Send_OTCCTL1(void)
{
	USHORT data = 0u;
	data = usBMIC_Calc_OTCCTL1();
	ucBMIC_Send_Req(OTCCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
}

/****************************************************************************
FUNCTION	: usBMIC_Calc_OTDCTL1
DESCRIPTION	: Set BMIC register OTDCTL1 according to BMIC set parameters: usOTDInfo_hys, sOTD1Info_temp, ucOTDInfo_delay1, ucOTDInfo_delay2
INPUT		:
OUTPUT		:
UPDATE		: 2023/11/17
DATE		: 2023/10/30
*****************************************************************************/
static USHORT usBMIC_Calc_OTDCTL1(void)
{
	USHORT ret = OTDCTL1_INI;
	UCHAR valid = 1u;
	USHORT otd_hys = 0u, otdth = 0u;
	USHORT otd_dly1, otd_dly2 = 0u;
	USHORT dat = 0u;
	SHORT sOT_Temp;

	dat = BMICSetParam.usOTDInfo_hys;
	if(dat < 25u){
		dat = 25u;
	} else if(dat > 200u){
		dat = 200u;
	}
	otd_hys = (dat - 25u) / 25u;						/* otd_hys = (usOTDInfo_hys(mv) - 25mV) / 25u */

	switch(BMICSetParam.ucOTDInfo_delay1){
		case 4u:
			otd_dly1 = 0u;					/* OTD_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
		case 8u:
			otd_dly1 = 1u;					/* OTD_DLY1: 8 times of voltage measurement cycle (Active mode)	*/
			break;
		case 16u:
			otd_dly1 = 2u;					/* OTD_DLY1: 16 times of voltage measurement cycle (Active mode)	*/
			break;
		case 32u:
			otd_dly1 = 3u;					/* OTD_DLY1: 32 times of voltage measurement cycle (Active mode)	*/
			break;
		default:
			otd_dly1 = 0u;					/* OTD_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
	}

	switch(BMICSetParam.ucOTDInfo_delay2){
		case 1u:
			otd_dly2 = 0u;					/* OTD_DLY2: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
		case 2u:
			otd_dly2 = 1u;					/* OTD_DLY2: 2 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 4u:
			otd_dly2 = 2u;					/* OTD_DLY2: 4 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 8u:
			otd_dly2 = 3u;					/* OTD_DLY2: 8 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		default:
			otd_dly2 = 0u;					/* OTD_DLY2: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
	}

	sOT_Temp = BMICSetParam.sOTD1Info_temp;
	if(sOT_Temp >= OT_TEMP_THMIN){
		if(sOT_Temp > OT_TEMP_THMAX){
			sOT_Temp = OT_TEMP_THMAX;
		}
		otdth = usGetOT_Threshold(sOT_Temp, TMONI_GROUP1);
	} else {
		valid = 0u;
	}

	if(valid == 1u){
		ret = (USHORT)(otd_hys << 12u)| (USHORT)(otd_dly2 << 10u)| (USHORT)(otd_dly1 << 8u)|(USHORT) otdth;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: vBMIC_Send_OTDCTL1
DESCRIPTION	: Set Over Temperature Discharge Voltage hystereis, delay1, delay2 and threhold of BMIC OTDCTL1 register
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/30
*****************************************************************************/
void vBMIC_Send_OTDCTL1(void)
{
	USHORT data = 0u;
	data = usBMIC_Calc_OTDCTL1();
	ucBMIC_Send_Req(OTDCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
}

/****************************************************************************
FUNCTION	: usBMIC_Calc_UTCCTL1
DESCRIPTION	: Set BMIC register UTCCTL1 according to BMIC set parameters: usUTCInfo_hys, sUTC1Info_temp, ucUTCInfo_delay1, ucUTCInfo_delay2
INPUT		:
OUTPUT		:
UPDATE		: 2023/11/17
DATE		: 2023/10/30
*****************************************************************************/
static USHORT usBMIC_Calc_UTCCTL1(void)
{
	USHORT ret = UTCCTL1_INI;
	UCHAR valid = 1u;
	USHORT utc_hys = 0u, utcth = 0u;
	USHORT utc_dly1, utc_dly2 = 0u;
	USHORT dat = 0u;
	SHORT sUT_Temp;

	dat = BMICSetParam.usUTCInfo_hys;
	if(dat < 25u){
		dat = 25u;
	} else if(dat > 200u){
		dat = 200u;
	}
	utc_hys = (dat - 25u) / 25u;						/* utc_hys = (usUTCInfo_hys(mv) - 25mV) / 25u */

	switch(BMICSetParam.ucUTCInfo_delay1){
		case 4u:
			utc_dly1 = 0u;					/* UTC_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
		case 8u:
			utc_dly1 = 1u;					/* UTC_DLY1: 8 times of voltage measurement cycle (Active mode)	*/
			break;
		case 16u:
			utc_dly1 = 2u;					/* UTC_DLY1: 16 times of voltage measurement cycle (Active mode)	*/
			break;
		case 32u:
			utc_dly1 = 3u;					/* UTC_DLY1: 32 times of voltage measurement cycle (Active mode)	*/
			break;
		default:
			utc_dly1 = 0u;					/* UTC_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
	}

	switch(BMICSetParam.ucUTCInfo_delay2){
		case 1u:
			utc_dly2 = 0u;					/* UTC_DLY1: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
		case 2u:
			utc_dly2 = 1u;					/* UTC_DLY1: 2 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 4u:
			utc_dly2 = 2u;					/* UTC_DLY1: 4 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 8u:
			utc_dly2 = 3u;					/* UTC_DLY1: 8 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		default:
			utc_dly2 = 0u;					/* UTC_DLY1: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
	}

	sUT_Temp = BMICSetParam.sUTC1Info_temp;
	if(sUT_Temp <= UT_TEMP_THMAX){
		if(sUT_Temp < UT_TEMP_THMIN){
			sUT_Temp = UT_TEMP_THMIN;
		}
		utcth = usGetUT_Threshold(sUT_Temp, TMONI_GROUP1);
	} else {
		valid = 0u;
	}

	if(valid == 1u){
		ret = (USHORT)(utc_hys << 12u)| (USHORT)(utc_dly2 << 10u)| (USHORT)(utc_dly1 << 8u)|(USHORT) utcth;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: vBMIC_Send_UTCCTL1
DESCRIPTION	: Set Under Temperarue Charge Voltage hystereis, delay1, delay2 and threhold of BMIC UTCCTL1 register
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/30
*****************************************************************************/
void vBMIC_Send_UTCCTL1(void)
{
	USHORT data = 0u;
	data = usBMIC_Calc_UTCCTL1();
	ucBMIC_Send_Req(UTCCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
}

/****************************************************************************
FUNCTION	: usBMIC_Calc_UTDCTL1
DESCRIPTION	: Set BMIC register UTDCTL1 according to BMIC set parameters: usUTDInfo_hys, sUTD1Info_temp, ucUTDInfo_delay1, ucUTDInfo_delay2
INPUT		:
OUTPUT		:
UPDATE		: 2023/11/17
DATE		: 2023/10/30
*****************************************************************************/
static USHORT usBMIC_Calc_UTDCTL1(void)
{
	USHORT ret = UTDCTL1_INI;
	UCHAR valid = 1u;
	USHORT utd_hys = 0u, utdth = 0u;
	USHORT utd_dly1, utd_dly2 = 0u;
	USHORT dat = 0u;
	SHORT sUT_Temp;

	dat = BMICSetParam.usUTDInfo_hys;
	if(dat < 25u){
		dat = 25u;
	} else if(dat > 200u){
		dat = 200u;
	}
	utd_hys = (dat - 25u) / 25u;						/* utd_hys = (usUTDInfo_hys(mv) - 25mV) / 25u */

	switch(BMICSetParam.ucUTDInfo_delay1){
		case 4u:
			utd_dly1 = 0u;					/* UTD_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
		case 8u:
			utd_dly1 = 1u;					/* UTD_DLY1: 8 times of voltage measurement cycle (Active mode)	*/
			break;
		case 16u:
			utd_dly1 = 2u;					/* UTD_DLY1: 16 times of voltage measurement cycle (Active mode)	*/
			break;
		case 32u:
			utd_dly1 = 3u;					/* UTD_DLY1: 32 times of voltage measurement cycle (Active mode)	*/
			break;
		default:
			utd_dly1 = 0u;					/* UTD_DLY1: 4 times of voltage measurement cycle (Active mode)(default)	*/
			break;
	}

	switch(BMICSetParam.ucUTDInfo_delay2){
		case 1u:
			utd_dly2 = 0u;					/* UTD_DLY1: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
		case 2u:
			utd_dly2 = 1u;					/* UTD_DLY1: 2 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 4u:
			utd_dly2 = 2u;					/* UTD_DLY1: 4 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		case 8u:
			utd_dly2 = 3u;					/* UTD_DLY1: 8 times of voltage measurement cycle (Stby/LP mode)	*/
			break;
		default:
			utd_dly2 = 0u;					/* UTD_DLY1: 1 times of voltage measurement cycle (Stby/LP mode)(default)	*/
			break;
	}

	sUT_Temp = BMICSetParam.sUTD1Info_temp;
	if(sUT_Temp <= UT_TEMP_THMAX){
		if(sUT_Temp < UT_TEMP_THMIN){
			sUT_Temp = UT_TEMP_THMIN;
		}
		utdth = usGetUT_Threshold(sUT_Temp, TMONI_GROUP1);
	} else {
		valid = 0u;
	}

	if(valid == 1u){
		ret = (USHORT)(utd_hys << 12u)| (USHORT)(utd_dly2 << 10u)| (USHORT)(utd_dly1 << 8u)|(USHORT) utdth;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: vBMIC_Send_UTDCTL1
DESCRIPTION	: Set Under Temperature Discharge Voltage hystereis, delay1, delay2 and threhold of BMIC UTDCTL1 register
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/30
*****************************************************************************/
void vBMIC_Send_UTDCTL1(void)
{
	USHORT data = 0u;
	data = usBMIC_Calc_UTDCTL1();
	ucBMIC_Send_Req(UTDCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
}


/****************************************************************************
FUNCTION	: usBMIC_Calc_OTCTL2
DESCRIPTION	: Set BMIC register OTCTL2 according to BMIC set parameters: sOTC2Info_temp, sOTD2Info_temp
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/10/30
*****************************************************************************/
static USHORT usBMIC_Calc_OTCTL2(void)
{
	USHORT ret = OTCTL2_INI;
	UCHAR valid = 1u;
	USHORT otcth = 0u, otdth = 0u;
	SHORT sOT_Temp;

	sOT_Temp = BMICSetParam.sOTC2Info_temp;
	if(sOT_Temp >= OT_TEMP_THMIN){
		if(sOT_Temp > OT_TEMP_THMAX){
			sOT_Temp = OT_TEMP_THMAX;
		}
		otcth = usGetOT_Threshold(sOT_Temp, TMONI_GROUP2);
	} else {
		valid = 0u;
	}

	sOT_Temp = BMICSetParam.sOTD2Info_temp;
	if(sOT_Temp >= OT_TEMP_THMIN){
		if(sOT_Temp > OT_TEMP_THMAX){
			sOT_Temp = OT_TEMP_THMAX;
		}
		otdth = usGetOT_Threshold(sOT_Temp, TMONI_GROUP2);
	} else {
		valid = 0u;
	}

	if(valid == 1u){
		ret = (USHORT)(otdth << 8u)|(USHORT) otcth;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: vBMIC_Send_OTCTL2
DESCRIPTION	: Set TMONI group 2 Over Temperature Charge & Discharge Voltage threhold of BMIC OTCTL2 register
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/30
*****************************************************************************/
void vBMIC_Send_OTCTL2(void)
{
	USHORT data = 0u;
	data = usBMIC_Calc_OTCTL2();
	ucBMIC_Send_Req(OTCTL2_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
}

/****************************************************************************
FUNCTION	: usBMIC_Calc_UTCTL2
DESCRIPTION	: Set BMIC register UTCTL2 according to BMIC set parameters: sUTC2Info_temp, sUTD2Info_temp
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/10/30
*****************************************************************************/
static USHORT usBMIC_Calc_UTCTL2(void)
{
	USHORT ret = UTCTL2_INI;
	UCHAR valid = 1u;
	USHORT utcth = 0u, utdth = 0u;
	SHORT sUT_Temp;

	sUT_Temp = BMICSetParam.sUTC2Info_temp;
	if(sUT_Temp <= UT_TEMP_THMAX){
		if(sUT_Temp < UT_TEMP_THMIN){
			sUT_Temp = UT_TEMP_THMIN;
		}
		utcth = usGetUT_Threshold(sUT_Temp, TMONI_GROUP2);
	} else {
		valid = 0u;
	}

	sUT_Temp = BMICSetParam.sUTD2Info_temp;
	if(sUT_Temp <= UT_TEMP_THMAX){
		if(sUT_Temp < UT_TEMP_THMIN){
			sUT_Temp = UT_TEMP_THMIN;
		}
		utdth = usGetUT_Threshold(BMICSetParam.sUTD2Info_temp, TMONI_GROUP2);
	} else {
		valid = 0u;
	}

	if(valid == 1u){
		ret = (USHORT)(utdth << 8u)|(USHORT) utcth;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: vBMIC_Send_UTCTL2
DESCRIPTION	: Set TMONI group 2 Under Temperature Charge & Discharge Voltage threhold of BMIC UTCTL2 register
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/30
*****************************************************************************/
void vBMIC_Send_UTCTL2(void)
{
	USHORT data = 0u;
	data = usBMIC_Calc_UTCTL2();
	ucBMIC_Send_Req(UTCTL2_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
}

/****************************************************************************
FUNCTION	: usBMIC_Calc_OTUTITH
DESCRIPTION	: Set BMIC register FDRV_CTRL2 OTUT_ITH according to BMIC set parameters: usOTUT_ITHInfo_mA
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/11/01
*****************************************************************************/
static USHORT usBMIC_Calc_OTUTITH(void)
{
	USHORT ret = OTUT_ITH_INI;
	USHORT otut_ith = 0u;

	otut_ith = BMICSetParam.usOTUT_ITHInfo_mA / (USHORT)175u;

	if(otut_ith <= 0xFFu){
		ret = otut_ith;
	}

	return(ret);

}

/****************************************************************************
FUNCTION	: vBMIC_Send_OTUTITH
DESCRIPTION	: Set the threshold current for switching between charging
			  and discharging (compare by IADC)
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/30
*****************************************************************************/
void vBMIC_Send_OTUTITH(void)
{
	USHORT data = 0u;
	data = usBMIC_Calc_OTUTITH();
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	ucBMIC_Send_Req(OTUT_CTRL_ADDR, data, OTUT_ITH_MASK, BMIC_DATA_INPUT_NEED);
#else
	ucBMIC_Send_Req(FDRV_CTRL2_ADDR, data, OTUT_ITH_MASK, BMIC_DATA_INPUT_NEED);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
}

/****************************************************************************
FUNCTION	: usBMIC_Calc_OTUTMSK
DESCRIPTION	: Set BMIC register OP_MODE: UTDMSK,UTCMSK,OTDMSK,OTCMSK according to BMIC set parameters: usOTUT_MSK
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/10/30
*****************************************************************************/
static USHORT usBMIC_Calc_OTUTMSK(void)
{
	USHORT ret = 0u;

	if((BMICSetParam.usOTUT_MSK & OTCMSK_OFF) == OTCMSK_OFF){
		ret = ret | OTCMSK_OFF;
	}

	if((BMICSetParam.usOTUT_MSK & OTDMSK_OFF) == OTDMSK_OFF){
		ret = ret | OTDMSK_OFF;
	}

	if((BMICSetParam.usOTUT_MSK & UTCMSK_OFF) == UTCMSK_OFF){
		ret = ret | UTCMSK_OFF;
	}

	if((BMICSetParam.usOTUT_MSK & UTDMSK_OFF) == UTDMSK_OFF){
		ret = ret | UTDMSK_OFF;
	}

	return(ret);
}


/****************************************************************************
FUNCTION	: vBMIC_Send_OTUTMSK
DESCRIPTION	: Set BMIC register OP_MODE: UTDMSK,UTCMSK,OTDMSK,OTCMSK
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/11/02
*****************************************************************************/
void vBMIC_Send_OTUTMSK(void)
{
	USHORT data = 0u;
	data = usBMIC_Calc_OTUTMSK();

	ucBMIC_Send_Req(OP_MODE_ADDR, data, OTUTMSK_MASK, BMIC_DATA_INPUT_NEED);
}

/****************************************************************************
FUNCTION	: usBMIC_Calc_ALARM_CTL3
DESCRIPTION	: Set BMIC register ALARM_CTL3 according to BMIC set
              parameters: usSCDInfo_cur, usOCDInfo_cur, usOCCInfo_cur
INPUT		:
OUTPUT		:
UPDATE		: 2024/01/24
DATE		: 2023/10/19
*****************************************************************************/
static USHORT usBMIC_Calc_ALARM_CTL3(void)
{
	USHORT scd_d = 0u;
	USHORT ocd_d = 0u;
	USHORT occ_d = 0u;
	USHORT ret = 0u;
	USHORT thd_mv = 0u;

/*	thd_mv = BMICSetParam.usSCDInfo_cur * SHUNT_mohm;	*/						/* SCD threshold in mV */
	thd_mv = (USHORT)((ULONG)BMICSetParam.usSCDInfo_cur * SHUNT_uohm / 1000u);	/* SCD threshold in mV */
	if(thd_mv == 0u){
		scd_d = 0u;
	} else if((thd_mv % 20u) == 0){
		scd_d = thd_mv / 20u - 1u;
	} else {
		scd_d = thd_mv / 20u;
	}
	if(scd_d > 0x1Fu){														/* max 5bit	*/
		scd_d = 0x1Fu;
	}

/*	thd_mv = BMICSetParam.usOCDInfo_cur * SHUNT_mohm;	*/						/* OCD threshold in mV */
	thd_mv = (USHORT)((ULONG)BMICSetParam.usOCDInfo_cur * SHUNT_uohm / 1000u);	/* OCD threshold in mV */
	if(thd_mv == 0u){
		ocd_d = 0u;
	} else if((thd_mv % 10u) == 0){
		ocd_d = thd_mv / 10u - 1u;
	} else {
		ocd_d = thd_mv / 10u;
	}
	if(ocd_d > 0x1Fu){														/* max 5bit	*/
		ocd_d = 0x1Fu;
	}

/*	thd_mv = BMICSetParam.usOCCInfo_cur * SHUNT_mohm;	*/						/* OCC threshold in mV */
	thd_mv = (USHORT)((ULONG)BMICSetParam.usOCCInfo_cur * SHUNT_uohm / 1000u);	/* OCC threshold in mV */
	if(thd_mv == 0u){
		occ_d = 0u;
	} else if((thd_mv % 5u) == 0){
		occ_d = thd_mv / 5u - 1u;
	} else {
		occ_d = thd_mv / 5u;
	}
	if(occ_d > 0x17u){														/* max 5bit	*/
		occ_d = 0x17u;
	}

	ret = (USHORT)(scd_d << 10u) | (USHORT)(ocd_d << 5u) | occ_d;
	return ret;

}

/****************************************************************************
FUNCTION	: vBMIC_Send_ALARM_CTL3(void)
DESCRIPTION	: Set threshold of Short circuit detection at discharge (SCD_D),
              Overcurrent detection at discharge (OCD_D) & Overcurrent detection at charge (OCC_D)
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/19
*****************************************************************************/
void vBMIC_Send_ALARM_CTL3(void)
{
	USHORT data = usBMIC_Calc_ALARM_CTL3();
	ucBMIC_Send_Req(ALARM_CTL3_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
}

/****************************************************************************
FUNCTION	: usBMIC_Calc_ALARM_CTL4
DESCRIPTION	: Set BMIC register ALARM_CTL4 according to BMIC set
              parameters: ulSCDInfo_delay, usOCDInfo_delay, usOCCInfo_delay
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/10/19
*****************************************************************************/
static USHORT usBMIC_Calc_ALARM_CTL4(void)
{
	ULONG scddelay_dat = BMICSetParam.ulSCDInfo_delay;
	USHORT scd_dly = 0u;
	USHORT dat = 0u;
	USHORT ocd_dly = 0u;
	USHORT occ_dly = 0u;
	USHORT ret = 0u;

	if(scddelay_dat == 0u){
		scd_dly = 0u;
	} else {
		scd_dly = (USHORT)(scddelay_dat / 31250u);					/* (nsec)/31250(nsec)	*/
	}
	if(scd_dly  > 0x1Fu){									/* max 5bit	*/
		scd_dly = 0x1F;
	}

	dat = BMICSetParam.usOCDInfo_delay;
	if(dat == 0u){
		ocd_dly = 0u;
	} else {
		ocd_dly = dat / (USHORT)10 - 1u;							/* (msec)/10(msec) - 1	*/
	}
	if(ocd_dly > 0x1Fu){									/* max 5bit	*/
		ocd_dly = 0x1F;
	}

	dat = BMICSetParam.usOCCInfo_delay;
	if(dat == 0u){
		occ_dly = 0u;
	} else {
		occ_dly = dat / (USHORT)10 - 1u;							/* (msec)/10(msec) - 1	*/
	}
	if(occ_dly > 0x1Fu){									/* max 5bit	*/
		occ_dly = 0x1F;
	}

	ret = (USHORT)(scd_dly << 10u) | (USHORT)(ocd_dly << 5u) | occ_dly;
	return ret;

}

/****************************************************************************
FUNCTION	: vBMIC_Send_ALARM_CTL4(void)
DESCRIPTION	: Set delay time for Short circuit detection at discharge (SCD_DLY)
              Overcurrent detection at discharge (OCD_DLY) & Overcurrent detection at charge (OCC_DLY)
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/19
*****************************************************************************/
void vBMIC_Send_ALARM_CTL4(void)
{
	USHORT data = usBMIC_Calc_ALARM_CTL4();
	ucBMIC_Send_Req(ALARM_CTL4_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
}

/****************************************************************************
FUNCTION	: vBMIC_Register_Init
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		: 2024/03/01
DATE		: 2019/11/01
*****************************************************************************/
static void vBMIC_Register_Init(void)
{
	/* Controll Register Initial Setting */
	vBMICWriteReg(SPIWD_CTRL_ADDR, SPIWD_CTRL_INI);
	vBMICWriteReg(REG_INT_EN_ADDR, REG_INT_EN_INI);

	vBMICWriteReg(FDRV_CTRL_ADDR, FDRV_CTRL_INI);
	vBMICWriteReg(CVSEL1_ADDR, CVSEL1_INI);
	vBMICWriteReg(CVSEL2_ADDR, CVSEL2_INI);
	vBMICWriteReg(GVSEL_ADDR, GVSEL_INI);
	vBMICWriteReg(OVCTL1_ADDR, OVCTL1_INI);
	vBMICWriteReg(UVCTL1_ADDR, UVCTL1_INI);

	vBMICWriteReg(GPIO_CTL1_ADDR, GPIO_CTL1_INI);
	vBMICWriteReg(GPIO_CTL2_ADDR, GPIO_CTL2_INI);
	vBMICWriteReg(GPIO_CTL3_ADDR, GPIO_CTL3_INI);
	vBMICWriteReg(GPIO_CTL4_ADDR, GPIO_CTL4_INI);
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	vBMICWriteReg(OSC_CTL_ADDR, OSC_CTL_INI);
#else
	vBMICWriteReg(GPIO_CTL5_ADDR, GPIO_CTL5_INI);
#endif /* BMIC_KA49702A */
	vBMICWriteReg(ALARM_CTL1_ADDR, ALARM_CTL1_INI);
	vBMICWriteReg(ALARM_CTL2_ADDR, ALARM_CTL2_INI);
	vBMICWriteReg(ALARM_CTL3_ADDR, ALARM_CTL3_INI);
	vBMICWriteReg(ALARM_CTL4_ADDR, ALARM_CTL4_INI);

	vBMICWriteReg(CBSEL_ADDR, CBSEL_INI);
	vBMICWriteReg(CBSEL_17_ADDR, CBSEL_17_INI);
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	vBMICWriteReg(ADCTL1_ADDR, ADCTL1_INI);
	vBMICWriteReg(ADCTL2_ADDR, ADCTL2_INI);
	vBMICWriteReg(GPOH_CTL_ADDR, GPOH_CTL_INI);
	vBMICWriteReg(OTUT_CTRL_ADDR, OTUT_CTRL_INI);
#else
	vBMICWriteReg(OTHCTL_ADDR, OTHCTL_INI);

	vBMICWriteReg(ADCTL_ADDR, ADCTL_INI);

	vBMICWriteReg(FDRV_CTRL2_ADDR, FDRV_CTRL2_INI);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
	vBMICWriteReg(DIAG_EN_ADDR, DIAG_EN_INI);

	vBMICWriteReg(OP_MODE_ADDR, OP_MODE_INI);

	vBMICWriteReg(PWR_CTRL_ADDR, PWR_CTRL_INI);

}


/****************************************************************************
FUNCTION	: ucBMIC_Make_CellList
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
static UCHAR ucBMIC_Make_CellList(void)
{
	const ULONG bitpat_tbl[14u] = {
		BITPAT_4CELL,
		BITPAT_5CELL,
		BITPAT_6CELL,
		BITPAT_7CELL,
		BITPAT_8CELL,
		BITPAT_9CELL,
		BITPAT_10CELL,
		BITPAT_11CELL,
		BITPAT_12CELL,
		BITPAT_13CELL,
		BITPAT_14CELL,
		BITPAT_15CELL,
		BITPAT_16CELL,
		BITPAT_17CELL,
	};

	UCHAR chk = 0u;
	UCHAR cellnum = BMICCellConf.ucSeriesCount;
	UCHAR i = 0u;

	for(i=0u; i<MAX_CELL_NUM; i++){
		BMIC_Drv.ucCellList[i] = 0u;
		BMIC_Drv.ucOpenCellList[i] = 0u;
	}

	if((MIN_CELL_NUM <= cellnum)&&(cellnum <= MAX_CELL_NUM)){
		UCHAR cellcnt = 0u;
		UCHAR open_cellcnt = 0u;
		ULONG bitpat = bitpat_tbl[BMICCellConf.ucSeriesCount - MIN_CELL_NUM];

		BMICCellConf.ulCellPos = (ULONG)bitpat;
		chk = 1u;

		for(i=0; i<MAX_CELL_NUM; i++ ){
			if((bitpat & 0x1u) != 0){
				BMIC_Drv.ucCellList[cellcnt] = i;
				cellcnt++;
			} else {
				BMIC_Drv.ucOpenCellList[open_cellcnt] = i;
				open_cellcnt++;
			}
			bitpat = bitpat >> 1u;
		}
		vBMIC_CBL_Init();
	}


	return chk;
}


/****************************************************************************
FUNCTION	: vBMIC_InitParams
DESCRIPTION	: Initialize BMIC_Drv, BMIC Info, BMIC SetParam data struct & other control variables/flags
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMIC_InitParams(void)
{
	USHORT i;
#if(0)
	BMIC_Drv.ucBMIC_ShutdownReq = 0u;
#endif
	BMIC_Drv.ulBMIC_ChkSpiMisoCount = 0u;
	BMIC_Drv.bBMIC_NgSpiMiso = false;
	BMIC_Drv.usSPI_ComAtLeastOnceFlg = 0u;
	BMIC_Drv.ucBMIC_SPI_err_detail = 0u;

	vBMIC_CtrlParameter_Init();

	for(i=0u; i<DATA_ELEMENTSIZE; i++){
		BMIC_Drv.usRegData[i]=(USHORT)0u;
	}


	BMIC_SpiRelease();

}


/****************************************************************************
FUNCTION	: ucBMIC_CellConf_Init
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
UCHAR ucBMIC_CellConf_Init(void)
{
	USHORT data;
	UCHAR chk = ucBMIC_Make_CellList();
	volatile bool spi_result;
	UCHAR cell_conf_stat = OK;
	if(chk == OK){
		data = usBMIC_Calc_UVCTL1();
		vBMICWriteReg_Mask(UVCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;

		data = usBMIC_Calc_OVCTL1();
		vBMICWriteReg_Mask(OVCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;

		data = usBMIC_Calc_OTCCTL1();
		vBMICWriteReg_Mask(OTCCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;

		data = usBMIC_Calc_OTDCTL1();
		vBMICWriteReg_Mask(OTDCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;

		data = usBMIC_Calc_UTCCTL1();
		vBMICWriteReg_Mask(UTCCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;

		data = usBMIC_Calc_UTDCTL1();
		vBMICWriteReg_Mask(UTDCTL1_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;

		data = usBMIC_Calc_OTCTL2();
		vBMICWriteReg_Mask(OTCTL2_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;

		data = usBMIC_Calc_UTCTL2();
		vBMICWriteReg_Mask(UTCTL2_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;

		data = usBMIC_Calc_OTUTITH();
#if(BMIC_IC_TYPE == BMIC_KA49702A)
		vBMICWriteReg_Mask(OTUT_CTRL_ADDR, data, OTUT_ITH_MASK, BMIC_DATA_INPUT_NEED);
#else
		vBMICWriteReg_Mask(FDRV_CTRL2_ADDR, data, OTUT_ITH_MASK, BMIC_DATA_INPUT_NEED);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;

		data = usBMIC_Calc_OTUTMSK();
		vBMICWriteReg_Mask(OP_MODE_ADDR, data, OTUTMSK_MASK, BMIC_DATA_INPUT_NEED);
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;

		data = usBMIC_Calc_ALARM_CTL3();
		vBMICWriteReg_Mask(ALARM_CTL3_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;

		data = usBMIC_Calc_ALARM_CTL4();
		vBMICWriteReg_Mask(ALARM_CTL4_ADDR, data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
		spi_result = bBMICCheckSpiResult();
		cell_conf_stat &= (UCHAR)spi_result;
	} else {
		cell_conf_stat = NG;
	}
	return cell_conf_stat;
}


/****************************************************************************
FUNCTION	: vBMIC_Ctrl_Startup
DESCRIPTION	: Control register initial setting & readback verification
              TMONIn internal pull-up resistance readback & Cell configuration initialisation
INPUT		: None
OUTPUT		: None
UPDATE		: 2021/05/12
DATE		: 2019/11/01
*****************************************************************************/
void vBMIC_Ctrl_Startup(void)
{
	UCHAR ret;

	ret = ucGetBMIC_SDO_In();

	if(ret == HIGH){
		UCHAR fuse_jdg = 0u;
		UCHAR cellconf_jdg = 0u;

		BMIC_Drv.bBMIC_NgSpiMiso = false;
		/* BMIC register initial setting */
		vBMIC_Register_Init();

		/* BMIC register initial read */
		vBMICRegInitRead();

		/* BMIC register initial check */
		ret = ucBMICRegInitChk();

		fuse_jdg = ucBMICReadFuse();
		cellconf_jdg = ucBMIC_CellConf_Init();
		if((fuse_jdg == NG) || (cellconf_jdg == NG)){
			ret = NG;
		}
	} else {
		if(BMIC_Drv.ulBMIC_ChkSpiMisoCount >= BMIC_DEAD_DETECT_CNT){
			BMIC_Drv.bBMIC_NgSpiMiso = true;
		} else {
			BMIC_Drv.ulBMIC_ChkSpiMisoCount++;
		}
	}

	if( ret == OK ){
		BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_NORMAL;
		BMIC_Drv.ulBMIC_ChkSpiMisoCount = 0u;
		BMIC_Drv.ucBMIC_SPI_err_detail = 0u;
	} else {	/* BMIC Restart */
		BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_RESTART;
		BMIC_Drv.ucBMIC_ComOffCount = BMS_CTL_TM_500MSEC;
	}

}


/****************************************************************************
FUNCTION	: vBMIC_Ctrl_Normal
DESCRIPTION	: CV17S_AD/VDD50/VDD15/VREG_EXT/VREF2/Cell Voltage,
			  Low Speed Current & Temperature measurement and calculated conversion results.
              Cell balancing control(if any) and status register OV/UV/OCD/OCC/SCD/OTC/OTD/UTC/UTD flag monitoring
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMIC_Ctrl_Normal(void)
{
	vBMIC_ADC_ctrl();
	vBMIC_VolADCRead();

	vBMIC_CalcMeasuredVol();
	vBMIC_CalcMeasuredCur();
	vBMIC_CalcMeasuredTemp();

	vBMIC_Register_ReadCtrl();
	vBMIC_Error_Ctrl();
	vBMIC_CBL_Control();

	vBMIC_SetCtrlStatus();
}

/****************************************************************************
FUNCTION	: vBMIC_Ctrl_SpiErr
DESCRIPTION	: Monitor SPI communication status.
			  NG - transit to BMIC_RESTART
			  OK - transit to BMIC_NORMAL.
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMIC_Ctrl_SpiErr(void)
{
	if(BMIC_Drv.ucBMIC_ComOffCount != (UCHAR)0){
		BMIC_Drv.ucBMIC_ComOffCount--;
	} else{		/* 500msec passed */
		UCHAR i;

		for(i=0u; i < (UCHAR)5; i++){
#if(BMIC_IC_TYPE == BMIC_KA49702A)
			usBMICReadReg(STAT_ADDR);
#else
			usBMICReadReg(OTHSTAT_ADDR);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
		}

		if(BMIC_Drv.ucBMIC_SPI_status == 1u){
			BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_RESTART;
			BMIC_Drv.ucBMIC_ComOffCount = BMS_CTL_TM_500MSEC;
#if(BMS_FETSTATE_CTRL)
			if(ucGetFETCtrlMode() == 1u){				/* FET SW control mode? */
				vTskInit_sys();
			}
#endif	/* BMS_FETSTATE_CTRL */
		} else{
			BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_NORMAL;
			BMIC_Drv.ucBMIC_SPI_err_detail = 0u;
		}
	}
}

/****************************************************************************
FUNCTION	: vBMIC_Ctrl_Restart
DESCRIPTION	: BMIC control restart
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2020/10/12
*****************************************************************************/
void vBMIC_Ctrl_Restart(void)
{
	if(BMIC_Drv.ucBMIC_ComOffCount != 0u){
		BMIC_Drv.ucBMIC_ComOffCount--;

#if(BMIC_IC_TYPE == BMIC_KA49702A)
		usBMICReadReg(STAT_ADDR);
#else
		usBMICReadReg(OTHSTAT_ADDR);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

		if(bBMICCheckSpiResult() == true){							/* SDO high & CRC check OK? */
			BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_STARTUP;
		}
	} else{
		/* SPI error persist, go to STARTUP to confirm SDO */
		BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_STARTUP;
	}
}


/****************************************************************************
FUNCTION	: vBMIC_Ctrl_Shutdown
DESCRIPTION	: Control to transit to BMIC shutdown via register setting MSET_SHDN or via hardware control SHDN pin
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		: 2023/05/19
*****************************************************************************/
void vBMIC_Ctrl_Shutdown(void)
{
#if(1)
	USHORT usstat = 0u;

	#if(BMIC_IC_TYPE == BMIC_KA49702A)
	usstat = usBMICReadReg(OTUTSTAT_ADDR);
	#else
	usstat = usBMICReadReg(STAT5_ADDR);
	#endif /* BMIC_KA49702A */

#if(!BMS_ERRSTS_MANUALCLR)
	#if(BMIC_IC_TYPE == BMIC_KA49702A)
	/* check VPC detection status, clear before enter shutdown */
	if((usstat & (VPC_L_F|VPC_H_F)) != 0u){												/* check VPC, detection status */
		vBMICWriteReg_Mask(OTUTSTAT_ADDR, usstat, usstat, BMIC_DATA_INPUT_NEED);		/* clear VPC, detection status */
	}
	#else
	/* check VPC, LDM detection status, clear before enter shutdown */
	if((usstat & (VPC_L_F|VPC_H_F)) != 0u){								/* check VPC, LDM detection status */
		vBMICWriteReg_Mask(STAT5_ADDR, usstat, usstat, BMIC_DATA_INPUT_NEED);			/* clear VPC, LDM detection status */
	}
	#endif /* BMIC_KA49702A */
#endif	/* !BMS_ERRSTS_MANUALCLR */

	if((usstat & VPC_DET_F) == 0u){				/* VPC detection flag OFF? */

		BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_SHUTDOWN;

#if(BMS_STANDBYMODE_SUPPORT)
		if(BMIC_Drv.ucBMIC_OpeMode_Req == 1u){
			/* Shutdown control via software control register MSET_SHDN */
			vBMICWriteReg_Mask(PWR_CTRL_ADDR, MSET_SHDN, MSET_SHDN_MASK, BMIC_DATA_INPUT_NEED);		/* set MSET_SHDN */
			Wait_msec(1u);		/* Wait 1ms to enter shutdown mode */
		}else
#endif	/* BMS_STANDBYMODE_SUPPORT */
		{
			vBMIC_SHDN_Out(HIGH);
			Wait_msec(1u);						/* SHDN = High for minimum 1ms to put BMIC shutdown */
			vBMIC_SHDN_Out(LOW);
		}

	}else{
#if(BMS_STANDBYMODE_SUPPORT)
		/* VPC_DET_F "1", BMIC will not shutdown, remain Active */
		vBMIC_ChgOpeMode((UCHAR)BMIC_OPEMODE_ACTIVE);
#endif	/* BMS_STANDBYMODE_SUPPORT */
	}

#else

#if(BMS_STANDBYMODE_SUPPORT)
	if(BMIC_Drv.ucBMIC_OpeMode_Req == 1u){
		/* Shutdown control via software control register MSET_SHDN */
		BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_STARTUP;	/* Pre-set to startup BMIC after BMIC shutdown */
		vBMICWriteReg_Mask(PWR_CTRL_ADDR, MSET_SHDN, MSET_SHDN_MASK, BMIC_DATA_INPUT_NEED);		/* set MSET_SHDN */
		Wait_msec(1u);		/* Wait 1ms to enter shutdown mode */
	}else
#endif	/* BMS_STANDBYMODE_SUPPORT */
	{
		/* Shutdown control via hardware control SHDN pin */
		if(BMIC_Drv.ucBMIC_ComOffCount != 0u){
			if(BMIC_Drv.ucBMIC_ComOffCount == BMS_CTL_TM_500MSEC){
				vBMIC_SHDN_Out(HIGH);
				Wait_msec(1u);						/* SHDN = High for minimum 1ms to put BMIC shutdown */
				vBMIC_SHDN_Out(LOW);
			}
			BMIC_Drv.ucBMIC_ComOffCount--;
		} else{
			BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_STARTUP;
		}
	}
#endif
}
#if(BMS_DIAGNOSTIC_SUPPORT)
/****************************************************************************
FUNCTION	: vBMIC_Ctrl_Diagnostic
DESCRIPTION	: BMIC Safety Diagnostic Function check
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		: 2022/06/09
*****************************************************************************/
void vBMIC_Ctrl_Diagnostic(void)
{
	eBMS_DIAGN_REQ eReq = (eBMS_DIAGN_REQ)ucGetDiag_req();
	eBMS_DIAGN_STS eStatus = (eBMS_DIAGN_STS)ucGetDiag_sts();

	switch(eStatus){
		case(eBMS_DIAGN_NONE):
			vTskInit_Diag();
			vSetDiag_sts(eBMS_DIAGN_START);
			break;
		case(eBMS_DIAGN_START):
			vTskSet_Diag(eReq);

			break;
		case(eBMS_DIAGN_INPROGRESS):
			vTskMonitor_Diag(eReq);

			break;
		case(eBMS_DIAGN_COMPLETED):
			if(ucdiag_ret_result_flg == 1u){
				vBMIC_Diagnostic_Req(0u);					/* Exit Diagnostic */
				vBMIC_UpdateCtrlStatus(BMIC_NORMAL);
				vSetDiag_sts(eBMS_DIAGN_NONE);
				ucdiag_ret_result_flg = 0u;
#if(BMS_FETSTATE_CTRL)
				if(ucGetFETCtrlMode() == 1u){				/* FET SW control mode? */
					vTskInit_sys();
				}
#endif	/* BMS_FETSTATE_CTRL */
			}
			break;
		default:
			vSetDiag_sts(eBMS_DIAGN_NONE);
			break;
	}
}

/****************************************************************************
FUNCTION	: vBMIC_Diagnostic_Req
DESCRIPTION	: BMIC Safety Diagnostic Function Request
INPUT		: 0: clear request, 1: set request
OUTPUT		: NONE
UPDATE		:
DATE		: 2022/06/09
*****************************************************************************/
void vBMIC_Diagnostic_Req(UCHAR req)
{
	if(req == 1u){						/* 1u: Enter diagnostic request , 0u: Exit diagnostic request */
		BMIC_Drv.ucBMIC_DiagNReq = 1u;	/* request set */
	}else{
		BMIC_Drv.ucBMIC_DiagNReq = 0u;	/* request clear */
	}
}
#endif /* BMS_DIAGNOSTIC_SUPPORT */

#if(0)
/****************************************************************************
FUNCTION	: vBMIC_ShutdownRequest
DESCRIPTION	: Set BMIC shutdown request flag
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMIC_ShutdownRequest(void)
{
	BMIC_Drv.ucBMIC_ShutdownReq = 1u;
}
#endif

#if(BMS_STANDBYMODE_SUPPORT)
/****************************************************************************
FUNCTION	: vBMIC_Ctrl_RetToActive
DESCRIPTION	: Monitor control to return to active mode
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/05/19
*****************************************************************************/
void vBMIC_Ctrl_RetToActive(void)
{
	USHORT usdataPwr_ctrl = 0u;

	if(GPIO_PORT_BMIC_GPIO3 == GPIO_PIN_RESET){					/* GPIO3 (Standby or LP mode state output) become "L" (not in Standby or LP mode)?  */

		Wait_msec(2u);		/* Wait 2ms to return to Active mode */

		usdataPwr_ctrl = usBMICReadReg(PWR_CTRL_ADDR);

		if((usdataPwr_ctrl & MSET_MODE_MASK) == 0u){			/* Active mode? */
			BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_NORMAL;
			vBMIC_Set_GPIO_PortSel(BMIC_GPIO3, GPIO3_SEL_INI);	/* return BMIC's GPIO to GPIO INIT */

		}

		BMIC_Drv.ucBMIC_SPI_err_detail = 0u;

	}
}

/****************************************************************************
FUNCTION	: vBMIC_Ctrl_Sleep
DESCRIPTION	: Control to transit to BMIC sleep mode via register setting MSET_SLP
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		: 2022/06/07
*****************************************************************************/
void vBMIC_Ctrl_Sleep(void)
{
	USHORT usstat = 0u;

	#if(BMIC_IC_TYPE == BMIC_KA49702A)
	usstat = usBMICReadReg(OTUTSTAT_ADDR);
	#else
	usstat = usBMICReadReg(STAT5_ADDR);
	#endif /* BMIC_KA49702A */

#if(!BMS_ERRSTS_MANUALCLR)
	#if(BMIC_IC_TYPE == BMIC_KA49702A)
	/* check VPC detection status, clear before enter sleep */
	if((usstat & (VPC_L_F|VPC_H_F)) != 0u){												/* check VPC, detection status */
		vBMICWriteReg_Mask(OTUTSTAT_ADDR, usstat, usstat, BMIC_DATA_INPUT_NEED);		/* clear VPC, detection status */
	}
	#else
	/* check VPC, LDM detection status, clear before enter sleep */
	if((usstat & (VPC_L_F|VPC_H_F)) != 0u){								/* check VPC, LDM detection status */
		vBMICWriteReg_Mask(STAT5_ADDR, usstat, usstat, BMIC_DATA_INPUT_NEED);			/* clear VPC, LDM detection status */
	}
	#endif /* BMIC_KA49702A */
#endif	/* !BMS_ERRSTS_MANUALCLR */

	if((usstat & VPC_DET_F) == 0u){				/* VPC detection flag OFF? */

		BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_SLEEP;

		vBMICWriteReg_Mask(PWR_CTRL_ADDR, MSET_SLP, MSET_MODE_MASK, BMIC_DATA_INPUT_NEED);		/* set MSET_SLP */
		Wait_msec(2u);		/* Wait 2ms to enter sleep mode */

	}else{

		/* VPC_DET_F "1", BMIC will not sleep, remain Active */
		vBMIC_ChgOpeMode((UCHAR)BMIC_OPEMODE_ACTIVE);

	}

}

/****************************************************************************
FUNCTION	: vBMIC_Ctrl_Standby
DESCRIPTION	: Control to transit to BMIC standby mode via register setting MSET_STB
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/05/19
*****************************************************************************/
void vBMIC_Ctrl_Standby(void)
{
#if(!BMS_ERRSTS_MANUALCLR)
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	USHORT usdataOTUTstat = 0u;

	/* check VPC detection status, clear before enter standby */
	usdataOTUTstat = usBMICReadReg(OTUTSTAT_ADDR);
	if((usdataOTUTstat & (VPC_L_F|VPC_H_F)) != 0u){													/* check VPC detection status */
		vBMICWriteReg_Mask(OTUTSTAT_ADDR, usdataOTUTstat, usdataOTUTstat, BMIC_DATA_INPUT_NEED);	/* clear VPC detection status */
	}
#else
	USHORT usdataStat5 = 0u;

	/* check VPC, LDM detection status, clear before enter standby */
	usdataStat5 = usBMICReadReg(STAT5_ADDR);
	if((usdataStat5 & (VPC_L_F|VPC_H_F)) != 0u){							/* check VPC, LDM detection status */
		vBMICWriteReg_Mask(STAT5_ADDR, usdataStat5, usdataStat5, BMIC_DATA_INPUT_NEED);		/* clear VPC, LDM detection status */
	}
#endif /* BMIC_KA49702A */
#endif	/* !BMS_ERRSTS_MANUALCLR */

	if((usBMICReferRegData(PWR_CTRL_ADDR) & ADC_CONT) == 0u){								/* ADC_CONT "0" (1-shot mode)? */
		vBMICWriteReg_Mask(PWR_CTRL_ADDR, ADC_CONT, ADC_CONT, BMIC_DATA_INPUT_NEED);		/* set ADC_CONT "1" (continuous mode) */
		Wait_msec(1u);																		/* wait 1ms */
	}

	vBMIC_Set_GPIO_PortSel(BMIC_GPIO3, GPIO_SEL_STBST);										/* Pre-set GPIO to Standby mode state output */

	vBMICWriteReg_Mask(PWR_CTRL_ADDR, MSET_STB, MSET_MODE_MASK, BMIC_DATA_INPUT_NEED);		/* set MSET_STB */
	Wait_msec(2u);		/* Wait 2ms to enter standby mode */

	BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_STANDBY;
}

/****************************************************************************
FUNCTION	: vBMIC_Ctrl_LowPower
DESCRIPTION	: Control to transit to BMIC low power mode via register setting MSET_LP
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		: 2023/05/19
*****************************************************************************/
void vBMIC_Ctrl_LowPower(void)
{
#if(!BMS_ERRSTS_MANUALCLR)
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	USHORT usdataOTUTstat = 0u;

	/* check VPC detection status, clear before enter low power */
	usdataOTUTstat = usBMICReadReg(OTUTSTAT_ADDR);
	if((usdataOTUTstat & (VPC_L_F|VPC_H_F)) != 0u){													/* check VPC detection status */
		vBMICWriteReg_Mask(OTUTSTAT_ADDR, usdataOTUTstat, usdataOTUTstat, BMIC_DATA_INPUT_NEED);	/* clear VPC detection status */
	}
#else
	USHORT usdataStat5 = 0u;

	/* check VPC, LDM detection status, clear before enter low power */
	usdataStat5 = usBMICReadReg(STAT5_ADDR);
	if((usdataStat5 & (VPC_L_F|VPC_H_F)) != 0u){							/* check VPC, LDM detection status */
		vBMICWriteReg_Mask(STAT5_ADDR, usdataStat5, usdataStat5, BMIC_DATA_INPUT_NEED);		/* clear VPC, LDM detection status */
	}
#endif /* BMIC_KA49702A */
#endif	/* !BMS_ERRSTS_MANUALCLR */

	if((usBMICReferRegData(PWR_CTRL_ADDR) & ADC_CONT) == 0u){								/* ADC_CONT "0" (1-shot mode)? */
		vBMICWriteReg_Mask(PWR_CTRL_ADDR, ADC_CONT, ADC_CONT, BMIC_DATA_INPUT_NEED);		/* set ADC_CONT "1" (continuous mode) */
		Wait_msec(1u);																		/* wait 1ms */
	}

	vBMIC_Set_GPIO_PortSel(BMIC_GPIO3, GPIO_SEL_LPST);										/* Pre-set GPIO to Low Power mode state output */

	vBMICWriteReg_Mask(PWR_CTRL_ADDR, MSET_LP, MSET_MODE_MASK, BMIC_DATA_INPUT_NEED);		/* set MSET_SLP */
	Wait_msec(2u);		/* Wait 2ms to enter Low Power mode */

	BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_LOWPOWER;
}

/****************************************************************************
FUNCTION	: vBMIC_Ctrl_Active
DESCRIPTION	: Control to transit to BMIC active mode via register setting
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		: 2023/05/19
*****************************************************************************/
void vBMIC_Ctrl_Active(void)
{
	vBMICWriteReg_Mask(PWR_CTRL_ADDR, ~MSET_MODE_MASK, MSET_MODE_MASK, BMIC_DATA_INPUT_NEED);	/* set active mode */
	Wait_msec(2u);		/* Wait 2ms to enter active mode */

	BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_NORMAL;
}

/****************************************************************************
FUNCTION	: vBMIC_Ctrl_WakeupWait
DESCRIPTION	: Monitor control to restart or return to BMIC active mode
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		: 2022/06/07
*****************************************************************************/
void vBMIC_Ctrl_WakeupWait(void)
{
	UCHAR ucWakeup = NG;

	if(((usBMICReferRegData(PWR_CTRL_ADDR) & MSET_SHDN_MASK) == 0u)					/* BMIC not in SHDN mode? */
	&& (GPIO_PORT_BMIC_GPIO4 == GPIO_PIN_RESET)										/* GPIO4 (MCU INT) "L" detected? */
	){
		ucWakeup = OK;
	}

	if(ucWakeup == OK){
		UCHAR i;

		for(i=0u; i < (UCHAR)5u; i++){
#if(BMIC_IC_TYPE == BMIC_KA49702A)
			usBMICReadReg(MODESTAT_ADDR);				/* update CHG/DIS FET Status */
			usBMICReadReg(OTUTSTAT_ADDR);
			usBMICReadReg(STAT_ADDR);
#else
			usBMICReadReg(STAT1_ADDR);					/* update CHG/DIS FET Status */
			usBMICReadReg(STAT5_ADDR);
			usBMICReadReg(OTHSTAT_ADDR);
#endif	/* BMIC_KA49702A */
		}

		if(BMIC_Drv.ucBMIC_SPI_status == 1u){
			#if(0)		/* stay at WakeupWait if SPI error */
			BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_RESTART;
			BMIC_Drv.ucBMIC_ComOffCount = BMS_CTL_TM_500MSEC;
			#endif
		} else{

			usBMICReadReg(PWR_CTRL_ADDR);						/* Update PWR_CTRL_ADDR */

			BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_NORMAL;
			BMIC_Drv.ucBMIC_SPI_err_detail = 0u;
		}
	}
}


/****************************************************************************
FUNCTION	: vBMIC_Ctrl_ShdnWakeupWait
DESCRIPTION	: Monitor SDO to return to BMIC active mode
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		:
*****************************************************************************/
void vBMIC_Ctrl_ShdnWakeupWait(void)
{
	if(ucGetBMIC_SDO_In() == HIGH){				/* SDO "H"? BMIC wake-up */

		BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_RESTART;					/* BMIC shutdown wake-up, all registers default settings */
		BMIC_Drv.ucBMIC_ComOffCount = BMS_CTL_TM_500MSEC;
#if(BMS_FETSTATE_CTRL)
		if(ucGetFETCtrlMode() == 1u){								/* FET SW control mode? */
			vTskInit_sys();
		}
#endif	/* BMS_FETSTATE_CTRL */
		vBMIC_ChgOpeMode((UCHAR)BMIC_OPEMODE_ACTIVE);

	}
}

/****************************************************************************
FUNCTION	: vBMIC_ChgOpeMode
DESCRIPTION	: Set to change Operation mode of BMIC
INPUT		: UCHAR ucOpeMode - 0: BMIC_OPEMODE_SHUTDOWN
			  					1: BMIC_OPEMODE_ACTIVE
			  					2: BMIC_OPEMODE_LOWPOWER
			 					3: BMIC_OPEMODE_STANDBY
			  					4: BMIC_OPEMODE_SLEEP
OUTPUT		: None
UPDATE		:
DATE		: 2022/06/09
*****************************************************************************/
void vBMIC_ChgOpeMode(UCHAR ucOpeMode)
{
	BMIC_Drv.ucBMIC_OpeMode = ucOpeMode;
}


/****************************************************************************
FUNCTION	: ucGet_BMICOpeMode
DESCRIPTION	: Return BMIC_Drv.ucBMIC_OpeMode
INPUT		: None
OUTPUT		: UCHAR
UPDATE		:
DATE		: 2022/06/20
*****************************************************************************/
UCHAR ucGet_BMICOpeMode(void)
{
	return(BMIC_Drv.ucBMIC_OpeMode);
}


/****************************************************************************
FUNCTION	: vBMIC_Set_OpeMode_Req
DESCRIPTION	: Set to change Operation mode request from Ext Signal (GUI)
INPUT		: 1: Request to change, 0: No change
OUTPUT		: None
UPDATE		:
DATE		: 2023/05/19
*****************************************************************************/
void vBMIC_Set_OpeMode_Req(UCHAR req_flg)
{
	BMIC_Drv.ucBMIC_OpeMode_Req = req_flg;
}

#endif	/* BMS_STANDBYMODE_SUPPORT */


/****************************************************************************
FUNCTION	: vBMIC_SetCtrlStatus
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMIC_SetCtrlStatus(void)
{
	/*SPI Err	*/
	if(BMIC_Drv.ucBMIC_SPI_status == 1u){
		BMIC_Drv.ucBMIC_SPI_status = 0u;
#if(BMS_STANDBYMODE_SUPPORT)
		if(BMIC_Drv.ucBMIC_OpeMode == BMIC_OPEMODE_ACTIVE)
#endif	/* BMS_STANDBYMODE_SUPPORT */
		{
			BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_SPIERR;
			BMIC_Drv.ucBMIC_ComOffCount = BMS_CTL_TM_500MSEC;
		}
		BMIC_Info.BMICMeasured = false;
	}
#if(0)
	if(BMIC_Drv.ucBMIC_ShutdownReq == 1u){
		BMIC_Drv.ucBMIC_ShutdownReq = 0u;
		BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_SHUTDOWN;
		BMIC_Drv.ucBMIC_ComOffCount = BMS_CTL_TM_500MSEC;
		BMIC_Info.BMICMeasured = false;
	}
#endif
#if(BMS_DIAGNOSTIC_SUPPORT)
	if(BMIC_Drv.ucBMIC_DiagNReq == 1u){
		BMIC_Drv.ucBMIC_Ctrl_Status = BMIC_DIAGNOSTIC;
		BMIC_Drv.ucBMIC_ComOffCount = BMS_CTL_TM_500MSEC;
		BMIC_Info.BMICMeasured = false;
	}
#endif /* BMS_DIAGNOSTIC_SUPPORT */
}

/****************************************************************************
FUNCTION	: vBMIC_UpdateCtrlStatus
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/06/16
*****************************************************************************/
void vBMIC_UpdateCtrlStatus(UCHAR ctrlsts)
{
	BMIC_Drv.ucBMIC_Ctrl_Status = ctrlsts;

	BMIC_Info.BMICMeasured = false;

}

/****************************************************************************
FUNCTION	: getBMIC_Ctrl_Status
DESCRIPTION	: Get BMIC control state
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
UCHAR getBMIC_Ctrl_Status(void)
{
	return	BMIC_Drv.ucBMIC_Ctrl_Status;
}

/****************************************************************************
FUNCTION	: vBMIC_ADC_ctrl
DESCRIPTION	: Check BMIC VAD_DONE, IADS_DONE flag to latch VAD and IADS
INPUT		: None
OUTPUT		: None
UPDATE		: 2024/08/15
DATE		: 2024/05/14
*****************************************************************************/
void vBMIC_ADC_ctrl(void)
{
	USHORT usdata;
	volatile bool spi_result = true;
#if(1/*BMIC_IC_TYPE == BMIC_KA49702A*/)
	static UCHAR ucVADCChk = 0;						/* Counter to set ADC_TRG every 100ms for 1-shot mode */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	UCHAR	ucChkCnt = 0u;
	USHORT usADDONE_Sts = 0u;
	USHORT usADLatchFlg = 0u;

	adc_complete = 0u;
	iads_complete = 0u;

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	if(((usBMICReferRegData(PWR_CTRL_ADDR) & (ADC_CONT | MSET_LP)) == 0u)				/* PWR_CTRL_ADDR bit15: ADC_CONT, if 0 (Oneshot mode), and bit3: MSET_LP "0" (not LP mode), set OP_MODE_ADDR bit4 ADC_TRG to start ADC */
	 && (ucVADCChk == 0u)
	 ){
		ucBMIC_Send_Req(MODESTAT_ADDR, VAD_DONE, VAD_DONE, BMIC_DATA_INPUT_NONE);		/* Clr VAD_DONE */ /* NOT INPUT */

		ucBMIC_Send_Req(OP_MODE_ADDR, ADC_TRG_ON, ADC_TRG_ON, BMIC_DATA_INPUT_NONE);	/* NOT INPUT */

		Wait_msec(5u);															/* wait 5ms before check status */

	}
#else
/*	if((usBMICReferRegData(PWR_CTRL_ADDR) & ADC_CONT) == 0u){	*/						/* PWR_CTRL_ADDR bit15: ADC_CONT, if 0 (Oneshot mode), set OP_MODE_ADDR bit4 ADC_TRG to start ADC */
	if(((usBMICReferRegData(PWR_CTRL_ADDR) & (ADC_CONT | MSET_LP)) == 0u)				/* PWR_CTRL_ADDR bit15: ADC_CONT, if 0 (Oneshot mode), and bit3: MSET_LP "0" (not LP mode), set OP_MODE_ADDR bit4 ADC_TRG to start ADC */
	 && (ucVADCChk == 0u)
	 ){
		ucBMIC_Send_Req(STAT1_ADDR, VAD_DONE, VAD_DONE, BMIC_DATA_INPUT_NONE);		    /* Clr VAD_DONE */ /* NOT INPUT */

		ucBMIC_Send_Req(OP_MODE_ADDR, ADC_TRG_ON, ADC_TRG_ON, BMIC_DATA_INPUT_NONE);	/* NOT INPUT */

		Wait_msec(5u);															/* wait 5ms before check status */

	}
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	while(ucChkCnt < (UCHAR)20){												/* maximum check 20 times, ~ 2ms */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
		usdata = usBMICReadReg(MODESTAT_ADDR);
#else
		usdata = usBMICReadReg(STAT1_ADDR);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
		spi_result = bBMICCheckSpiResult();
		if(spi_result){

			if((usdata & VAD_DONE) == VAD_DONE){	/* Check VAD_DONE flg */
				adc_complete = 1u;
				usADDONE_Sts |= VAD_DONE;
				usADLatchFlg |= ADV_LATCH_ON;
			}
			if((usdata & IADS_DONE) == IADS_DONE){	/* Check IADS_DONE flg */
				iads_complete = 1u;
				usADDONE_Sts |= IADS_DONE;
				usADLatchFlg |= ADIL_LATCH_ON;
			}
			if((adc_complete == 1u) && (iads_complete == 1u)){
				break;
			}

#if(1/*BMIC_IC_TYPE == BMIC_KA49702A*/)
			wait100us();
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

		}else{
			break;
		}
		ucChkCnt ++;
	}

	if((adc_complete==1u) || (iads_complete == 1u)){

#if(BMIC_IC_TYPE == BMIC_KA49702A)
		ucBMIC_Send_Req(MODESTAT_ADDR, usADDONE_Sts, usADDONE_Sts, BMIC_DATA_INPUT_NONE);	/* Clr VAD_DONE, IADS_DONE */ /* NOT INPUT */

		usdata = usBMICReadReg(OP_MODE_ADDR);												/* Readback OP_MODE */
#else
		ucBMIC_Send_Req(STAT1_ADDR, usADDONE_Sts, usADDONE_Sts, BMIC_DATA_INPUT_NONE);		/* Clr VAD_DONE, IADS_DONE */ /* NOT INPUT */
		usBMICReadReg(OP_MODE_ADDR);												/* Readback OP_MODE */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

		ucBMIC_Send_Req(OP_MODE_ADDR, usADLatchFlg, usADLatchFlg, BMIC_DATA_INPUT_NONE);	/* Latch ADV, ADIL */ /* NOT INPUT */

	}

#if(1/*BMIC_IC_TYPE == BMIC_KA49702A*/)
	ucVADCChk ++;
	if(ucVADCChk >= BMS_CTL_TM_100MSEC){
		ucVADCChk = 0u;
	}
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

}

/****************************************************************************
FUNCTION	: vBMIC_VolADCRead
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		: 2024/03/01
DATE		: 2023/07/04
*****************************************************************************/
void vBMIC_VolADCRead(void)
{
	USHORT usdata;
	UCHAR i;
	volatile bool spi_result = true;
	UCHAR ad_stat = OK;

	usdata = usBMICReadReg(OP_MODE_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	if((usdata & ADV_LATCH_ON) != 0u){
		BMIC_Drv.ucBMIC_AdState |= NOT_FIN_ADV_LATCH;
	}

	/* Read Cell voltage measurement result */
	for (i=0u; i < BMICCellConf.ucSeriesCount; i++) {
		usdata = usBMICReadReg(BMIC_Drv.ucCellList[i]+CV01_AD_ADDR);
		spi_result = bBMICCheckSpiResult();
		ad_stat &= (UCHAR)spi_result;
		if((bBMIC_ChkCellbalance() == false)								/* not in CB? */
		||((usBMICReferRegData(CBSEL_17_ADDR)&EN_MSOCB) == EN_MSOCB)		/* or CB with EN_MSOCB "1"? - measurment-oriented CB enabled */
		){
			BMIC_Drv.usCVAD[i] = usdata;
		}
	}
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	/* Read VPACK voltage measurement result */
	usdata = usBMICReadReg(VPACK_AD_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	BMIC_Drv.usVPACKAD = usdata;
#else
	/* Read C17S voltage measurement result */
	usdata = usBMICReadReg(C17S_AD_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	BMIC_Drv.usCV17SAD = usdata;
#endif /* BMIC_KA49702A */

	/* Read VDD50 voltage measurement result */
	usdata = usBMICReadReg(VDD50_AD_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	BMIC_Drv.usVdd50AD = usdata;

	/* Read VDD15 voltage measurement result */
	usdata = usBMICReadReg(VDD15_AD_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	BMIC_Drv.usVdd15AD = usdata;

	/* Read REGEXT voltage measurement result */
	usdata = usBMICReadReg(REGEXT_AD_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	BMIC_Drv.usVREGEXTAD = usdata;

	/* Read VREF2 voltage measurement result */
	usdata = usBMICReadReg(VREF2_AD_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	BMIC_Drv.usVREF2AD = usdata;

	#if(0)	/* VREF1 not used */
	/* Read VREF1 voltage measurement result */
	usdata = usBMICReadReg(VREF1_AD_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	BMIC_Drv.usVREF1AD = usdata;
	#endif

	/* Read TMONIn voltage measurement result */
	for (i=0u; i < THERMISTOR_NUM; i++) {
		usdata = usBMICReadReg(i+TMONI1_AD_ADDR);
		spi_result = bBMICCheckSpiResult();
		ad_stat &= (UCHAR)spi_result;
		BMIC_Drv.usTmoniAD[i] = usdata;
	}

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	/* Read GPIOH1 voltage measurement result */
	usdata = usBMICReadReg(GPIOH1_AD_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	BMIC_Drv.usGPIOH1AD = usdata;

	/* Read GPIOH2 voltage measurement result */
	usdata = usBMICReadReg(GPIOH2_AD_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	BMIC_Drv.usGPIOH2AD = usdata;
#else
	/* Read GPIOH1 voltage measurement result */
	usdata = usBMICReadReg(GPIO1_AD_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	BMIC_Drv.usGPIO1AD = usdata;

	/* Read GPIOH2 voltage measurement result */
	usdata = usBMICReadReg(GPIO2_AD_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	BMIC_Drv.usGPIO2AD = usdata;

#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	if(ad_stat == NG){
		BMIC_Drv.ucBMIC_AdState |= AD_AVE_DATA_NG;
	}else{
		if((BMIC_Drv.ucBMIC_AdState & NOT_FIN_ADV_LATCH) == 0u){
			if((bBMIC_ChkCellbalance() == false)								/* not in CB? */
			||((usBMICReferRegData(CBSEL_17_ADDR)&EN_MSOCB) == EN_MSOCB)		/* or CB with EN_MSOCB "1"? - measurment-oriented CB enabled */
			){
				BMIC_Drv.usSPI_ComAtLeastOnceFlg |= COMM_AD_CELLV;
			}
			BMIC_Drv.usSPI_ComAtLeastOnceFlg |= COMM_AD_TMONI;

			BMIC_Drv.usSPI_ComAtLeastOnceFlg |= COMM_AD_OTHER;
		}
	}
}


/****************************************************************************
FUNCTION	: vBMIC_Error_Ctrl
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		: 2023/08/21
DATE		: 2019/11/01
*****************************************************************************/
void vBMIC_Error_Ctrl(void)
{
	USHORT err1_data = 0u, err2_data = 0u, err_data = 0u;
	ULONG ul_tmp = BMIC_Info.ulBatPackErrLog;		/* get previous error info */
	USHORT tmp_data = 0u;
	USHORT chk_data = 0u;
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	err1_data = usBMICReferRegData(OTUTSTAT_ADDR) & (ST_OVUV_MASK | ST_OTUT_MASK);	/* OTUTSTAT bit1~0: ST_OV,ST_UV, bit7~4: ST_OTD,ST_OTC,ST_UTD,ST_UTC */
	err2_data |= usBMICReferRegData(STAT_ADDR) & STAT_SCD_OCD_OCC_MASK;				/* STAT bit15~13: ST_SCD,ST_OCD,ST_OCC */
	err_data = (USHORT)(err1_data << 8u) | (USHORT)(err2_data >> 9u);				/* OTUTSTAT bit1~0: ST_OV,ST_UV => err_data bit 9~8, OTHSTAT bit15~13: ST_SCD,ST_OCD,ST_OCC => err_data bit 6~4  */
#else
	err1_data = usBMICReferRegData(STAT5_ADDR) & (STAT5_OVUV_MASK | STAT5_OTUT_MASK);	/* STAT5 bit1~0: ST_OV,ST_UV, bit7~4: ST_OTD,ST_OTC,ST_UTD,ST_UTC */
	err2_data |= usBMICReferRegData(OTHSTAT_ADDR) & OTHSTAT_SCD_OCD_OCC_MASK;	/* OTHSTAT bit15~13: ST_SCD,ST_OCD,ST_OCC */
	err_data = (USHORT)(err1_data << 8u) | (USHORT)(err2_data >> 9u);		/* STAT5 bit1~0: ST_OV,ST_UV => err_data bit 9~8, OTHSTAT bit15~13: ST_SCD,ST_OCD,ST_OCC => err_data bit 6~4  */
#endif /* BMIC_KA49702A */

	tmp_data = err_data & MASK_TEMP_VOL_CUR_ERR;
	err_data &= MASK_TEMP_VOL_CUR_ERR;			/* keep temperature, voltage & current error flags	*/

#if(!BMS_ERRSTS_MANUALCLR)
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	chk_data = (err2_data & STAT_SCD_OCD_OCC_MASK);		/* bit15~13	*/
	if(chk_data != 0u){
		vBMICWriteReg(STAT_ADDR,chk_data);				/* clear STAT register bit15~13: ST_SCD, ST_OCD, ST_OCC	*/
	}
#else
	chk_data = (err2_data & OTHSTAT_SCD_OCD_OCC_MASK);	/* bit15~13	*/
	if(chk_data != 0u){
		vBMICWriteReg(OTHSTAT_ADDR,chk_data);			/* clear OTHSTAT register bit15~13: ST_SCD, ST_OCD, ST_OCC	*/
	}
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	/* clear UV/OV latch flags by write "1" to respective bits */
	chk_data = err1_data & ST_UV_MASK;					/* bit0 ST_UV	*/
	if(chk_data != 0u){
		vBMICWriteReg(UVL_STAT1_ADDR,0xFFFFu);			/* clear UVL_STAT1 register	*/
		vBMICWriteReg(UVL_STAT2_ADDR,UV17_LF_MASK);		/* clear UVL_STAT2 - UV17_LF register */
	}
	else{
		/* When ST_UV is clear */
		err2_data = usBMICReferRegData(UVL_STAT1_ADDR);
		if(err2_data != 0u){
			vBMICWriteReg(UVL_STAT1_ADDR,err2_data);		/* clear UVL_STAT1 register	*/
		}
		err2_data = usBMICReferRegData(UVL_STAT2_ADDR) & UV17_LF_MASK;
		if(err2_data != 0u){
			vBMICWriteReg(UVL_STAT2_ADDR,err2_data);		/* clear UVL_STAT2 register	*/
		}
	}

	chk_data = err1_data & ST_OV_MASK;					/* bit1 ST_OV	*/
	if(chk_data != 0u){
		vBMICWriteReg(OVL_STAT1_ADDR,0xFFFFu);			/* clear OVL_STAT1 register */
		vBMICWriteReg(OVL_STAT2_ADDR, OV17_LF_MASK);	/* clear OVL_STAT2 - OV17_LF register */
	}
	else{
		/* When ST_OV is clear */
		err2_data = usBMICReferRegData(OVL_STAT1_ADDR);
		if(err2_data != 0u){
			vBMICWriteReg(OVL_STAT1_ADDR,err2_data);		/* clear OVL_STAT1 register	if any */
		}
		err2_data = usBMICReferRegData(OVL_STAT2_ADDR) & OV17_LF_MASK;
		if(err2_data != 0u){
			vBMICWriteReg(OVL_STAT2_ADDR,err2_data);		/* clear OVL_STAT2 register if any */
		}
	}

	chk_data = err1_data & (ST_UTC | ST_UTD);			/* bit4 ST_UTC, bit5 ST_UTD	*/
	if(chk_data != 0u){
		vBMICWriteReg(UVL_STAT2_ADDR,(UTC_LF_MASK|UTD_LF_MASK));	/* clear UVL_STAT2 register for UTC/UTD detected flag */
	}else{
		err2_data = (usBMICReferRegData(UVL_STAT2_ADDR) & (UTC_LF_MASK|UTD_LF_MASK));
		if(err2_data != 0u){
			vBMICWriteReg(UVL_STAT2_ADDR,err2_data);		/* clear UVL_STAT2 register	for UTC/UTD detected flag */
		}
	}

	chk_data = err1_data & (ST_OTC | ST_OTD);			/* bit6 ST_OTC, bit7 ST_OTD	*/
	if(chk_data != 0u){
		vBMICWriteReg(OVL_STAT2_ADDR,(OTC_LF_MASK|OTD_LF_MASK));	/* clear OVL_STAT2 register for OTC/OTD detected flag */
	}else{
		err2_data = (usBMICReferRegData(OVL_STAT2_ADDR) & (OTC_LF_MASK|OTD_LF_MASK));
		if(err2_data != 0u){
			vBMICWriteReg(OVL_STAT2_ADDR, err2_data);		/* clear OVL_STAT2 register	for OTC/OTD detected flag */
		}
	}

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	chk_data = usBMICReferRegData(OTUTSTAT_ADDR) & OTUTSTAT_VPC_CUR_WDT_MASK;		/* OTUTSTAT_ADDR bit13~12: WDT_F, CUR_H_F, bit9~8: VPC_H_F, VPC_L_F */
	if(chk_data != 0u){
		vBMICWriteReg(OTUTSTAT_ADDR,chk_data);			/* clear OTUTSTAT_ADDR bit13~12: WDT_F, CUR_H_F, bit9~8: VPC_H_F, VPC_L_F	*/
	}
#else
	chk_data = usBMICReferRegData(STAT5_ADDR) & STAT5_VPC_CUR_WDT_MASK;		/* STAT5 bit13~12: WDT_F, CUR_H_F, bit9~8: VPC_H_F, VPC_L_F */
	if(chk_data != 0u){
		vBMICWriteReg(STAT5_ADDR,chk_data);			/* clear STAT5 bit13~8: WDT_F, CUR_H_F, LDM_H_F, LDM_L_H, VPC_H_F, VPC_L_F	*/
	}
#endif /* BMIC_KA49702A) */

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	if((usBMICReferRegData(STAT_ADDR) & SPI_F_MASK) == SPI_F_MASK){							/* SPI_F "1"? */
		vBMICWriteReg_Mask(STAT_ADDR, SPI_F_MASK, SPI_F_MASK, BMIC_DATA_INPUT_NONE);		/* Write SPI_F "1" to clear SPI error flg */
	}
#else
	if((usBMICReferRegData(OTHSTAT_ADDR) & SPI_F_MASK) == SPI_F_MASK){
		vBMICWriteReg_Mask(OTHSTAT_ADDR, SPI_F_MASK, SPI_F_MASK, BMIC_DATA_INPUT_NONE);		/* Write SPI_F "1" to clear SPI error flg */
	}
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

#endif	/* !BMS_ERRSTS_MANUALCLR */

	/* MODE_STAT	*/
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	chk_data = usBMICReferRegData(MODESTAT_ADDR);
#else
	chk_data = usBMICReferRegData(STAT1_ADDR);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
	chk_data &= ERR_IC_SHUTDOWN;				/* STAT1 bit2 ST_SDWN */
	err_data = (err_data | chk_data);						/* set bp2	*/

	BMIC_Info.ulBatPackErr = (ULONG)err_data;

	if((err_data & MASK_CURRENT_ERR) != 0u) {
		ucCurErr_ClrTime = BMS_CTL_TM_2SEC;					/* Current fault error clear time: 2sec */
	}

	err_data &= (USHORT)(~(USHORT)MASK_CURRENT_ERR);
	err_data |= (USHORT)(ul_tmp & MASK_CURRENT_ERR) | (tmp_data & MASK_CURRENT_ERR);

	if(ucCurErr_ClrTime > 0u){								/* Current fault error clear time counter down */
		ucCurErr_ClrTime --;
	}else{
		err_data &= (USHORT)(~(USHORT)MASK_CURRENT_ERR);	/* clear current error for log after 2sec */
	}

	BMIC_Info.ulBatPackErrLog = (ULONG)err_data;

}

/****************************************************************************
FUNCTION	: ulBMIC_GetBatPackErr
DESCRIPTION	: Get BMS Error such as ST_UV,ST_OV,ST_SCD,ST_OCD,ST_OCC,ST_OTC,ST_OTD,ST_UTC,ST_UTD status
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/07/14
*****************************************************************************/
ULONG ulBMIC_GetBatPackErr(void){
	ULONG ret;

	ret = BMIC_Info.ulBatPackErr;

	return(ret);
}

/****************************************************************************
FUNCTION	: vBMIC_CalcMeasuredVol
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		: 2024/03/01
DATE		: 2019/11/01
*****************************************************************************/
static void vBMIC_CalcMeasuredVol(void)
{
	ULLONG ulltemp = 0u;
	ULONG ulsum_uV = 0u;
	USHORT usmin = 0xFFFFu;
	USHORT usmax = 0u;
	ULONG ulmax_uV = 0u;
	ULONG ulmin_uV = 0u;
	UCHAR i = 0u;

#if(BMS_FETSTATE_CTRL)	/* CVSEL1&2 can change directly from GUI, if uncheck from GUI, the cell shall not update for minimum AD of block */
	ULONG ulCVSEL = 0u;
	ULONG ulChk_bit;
#endif	/* BMS_FETSTATE_CTRL */

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	/*	VPACK_AD voltage	*/
	ulltemp = BMIC_Drv.usVPACKAD;
	ulltemp *= 85000000u;												/* VPACK max: 85V	*/
	ulltemp /= 11141u;
	BMIC_Info.ulVPACKAD_uV = (ULONG)ulltemp;		/* Vin = AD * 85000000uV / 11141	*/
#else
	/*	CV17S_AD voltage	*/
	ulltemp = BMIC_Drv.usCV17SAD;
	ulltemp *= 85000000u;												/* C17S max: 85V	*/
	ulltemp /= 11141u;
	BMIC_Info.ulCV17SAD_uV = (ULONG)ulltemp;		/* Vin = AD * 85000000uV / 11141	*/
#endif /* BMIC_KA49702A */
	/* VDD50 voltage	*/
	ulltemp = BMIC_Drv.usVdd50AD;
	ulltemp *= 7500000u;													/* VDD50 max: 7.5V	*/
	ulltemp /= 16384u;
	BMIC_Info.ulVdd50V_uV = (ULONG)ulltemp;		/* Vin = AD * 7500000uV / 16384	*/

	/* VDD15 voltage	*/
	ulltemp = BMIC_Drv.usVdd15AD;
	ulltemp *= 5000000u;													/* VDD15 max: 5.0V	*/
	ulltemp /= 16384u;
	BMIC_Info.ulVdd15V_uV = (ULONG)ulltemp;		/* Vin = AD * 5000000uV / 16384	*/

	/* REGEXT voltage	*/
	ulltemp = BMIC_Drv.usVREGEXTAD;
	ulltemp *= 7500000u;													/* REGEXT max: 7.5V	*/
	ulltemp /= 16384u;
	BMIC_Info.ulVRegextV_uV = (ULONG)ulltemp;	/* Vin = AD * 7500000uV / 16384	*/

	/* VREF2 voltage	*/
	ulltemp = BMIC_Drv.usVREF2AD;
	ulltemp *= 5000000u;													/* VREF2 max: 5.0V	*/
	ulltemp /= 16384u;
	BMIC_Info.ulVref2V_uV = (ULONG)ulltemp;		/* Vin = AD * 5000000uV / 16384	*/

	#if(0)	/* VREF1 not used */
	/* VREF1 voltage	*/
	ulltemp = BMIC_Drv.usVREF1AD;
	ulltemp *= 5000000u;													/* VREF1 max: 5.0V	*/
	ulltemp /= 16384u;
	BMIC_Info.ulVref1V_uV = (ULONG)ulltemp;		/* Vin = AD * 5000000uV / 16384	*/
	#endif

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	/*	GPIOH1_AD voltage	*/
	ulltemp = BMIC_Drv.usGPIOH1AD;
	ulltemp *= 85000000u;												/* GPIOH1 max: 85V	*/
	ulltemp /= 11141u;
	BMIC_Info.ulGPIOH1V_uV = (ULONG)ulltemp;								/* Vin = AD * 85000000uV / 11141	*/

	/*	GPIOH2_AD voltage	*/
	ulltemp = BMIC_Drv.usGPIOH2AD;
	ulltemp *= 85000000u;												/* GPIOH2 max: 85V	*/
	ulltemp /= 11141u;
	BMIC_Info.ulGPIOH2V_uV = (ULONG)ulltemp;								/* Vin = AD * 85000000uV / 11141	*/
#else
	/*	GPIO1_AD voltage	*/
	ulltemp = BMIC_Drv.usGPIO1AD;
	ulltemp *= 5000000u;												/* GPIO1 max: 5V	*/
	ulltemp /= 16384u;
	BMIC_Info.ulGPIO1V_uV = (ULONG)ulltemp;								/* Vin = AD * 5000000uV / 16384	*/

	/*	GPIO2_AD voltage	*/
	ulltemp = BMIC_Drv.usGPIO2AD;
	ulltemp *= 5000000u;												/* GPIO2 max: 5V	*/
	ulltemp /= 16384u;
	BMIC_Info.ulGPIO2V_uV = (ULONG)ulltemp;								/* Vin = AD * 5000000uV / 16384	*/

#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

#if(BMS_FETSTATE_CTRL)	/* CVSEL1&2 can change directly from GUI, if uncheck from GUI, the cell shall not update for minimum AD of block */
	ulCVSEL = ((ULONG)usBMICReferRegData(CVSEL1_ADDR) & (ULONG)0x0000FFFFu) | ((((ULONG)usBMICReferRegData(CVSEL2_ADDR)) & (ULONG)0x0000FFFFu) << 16u);
#endif	/* BMS_FETSTATE_CTRL */

	for(i=0u; i<BMICCellConf.ucSeriesCount; i++){
		ulltemp = BMIC_Drv.usCVAD[i];
		ulltemp *= 5000000u;
		ulltemp /= 16384u;
		BMIC_Info.ulBlkVol_uV[i] = (ULONG)ulltemp;

#if(BMS_FETSTATE_CTRL)	/* CVSEL1&2 can change directly from GUI, if uncheck from GUI, the cell shall not update for minimum AD of block */
		ulChk_bit = (ULONG)0x00000001u << BMIC_Drv.ucCellList[i];
		if(ulChk_bit & ulCVSEL){
#endif	/* BMS_FETSTATE_CTRL */
		if(usmin > BMIC_Drv.usCVAD[i]){					/* calc Minimum AD of Block voltage	*/
			usmin = BMIC_Drv.usCVAD[i];
			ulmin_uV = (ULONG)ulltemp;
		}
#if(BMS_FETSTATE_CTRL) /* CVSEL1&2 can change directly from GUI, if uncheck from GUI, the cell shall not update for minimum AD of block */
		}
#endif	/* BMS_FETSTATE_CTRL */
		if(usmax < BMIC_Drv.usCVAD[i]){					/* calc Max AD of Block voltage	*/
			usmax = BMIC_Drv.usCVAD[i];
			ulmax_uV = (ULONG)ulltemp;
		}
		ulsum_uV += (ULONG)ulltemp;
	}

	/* Update Pack Total voltage, Pack lowest cell voltage, Pack highest cell voltage */
	BMIC_Info.ulVpackSumV_uV = ulsum_uV;					/* Vbat(sum)[mV] = 1000x AD Sum(All cell) * 5V/2^14 [mV]	*/
	BMIC_Info.ulBatPackMinBlkVol_uV = ulmin_uV;		/* Vin = AD * 5000000uV / 16384	*/
	BMIC_Info.ulBatPackMaxBlkVol_uV = ulmax_uV;
}

/****************************************************************************
FUNCTION	: vBMIC_CalcMeasuredTemp
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		: 2023/08/21
DATE		: 2019/11/01
*****************************************************************************/
static void vBMIC_CalcMeasuredTemp(void)
{
	/* thermistor AD -> Celsisus temperature conversion	*/
	USHORT cnt = 0u;
	UCHAR i = 0u;
	SHORT stemp_01C;
	for (i=0u; i<THERMISTOR_NUM; i++) {
		if ((BMICCellConf.ulTmoniTempPos & ((ULONG)1 << i)) != 0u) {
			stemp_01C = sCalcTemperature_01deg(BMIC_Drv.usTmoniAD[i], i);
			if(stemp_01C != 0x7FFF){
				BMIC_Info.sTemp_01Cdeg[i] = stemp_01C;
			}
			cnt++;
			if (cnt >= BMICCellConf.ucTmoniTempCount) {
				break;
			}
		}
	}
}

/****************************************************************************
FUNCTION	: vBMIC_CalcMeasuredCur
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		: 2023/07/04
DATE		: 2019/11/01
*****************************************************************************/
static void vBMIC_CalcMeasuredCur(void)
{
	float ftmp;
	SHORT sSlowIAD;
	bool spi_result;

/*	BMIC_Info.lBatPackCur_100uA = (sSlowIAD * 360) / 65536 / SHUNT_mohm; */	/* Low Speed Current AD	*/
	sSlowIAD = (SHORT)usBMICReadReg(CVIL_AD_ADDR);				/* Low Speed Current AD	*/
	BMIC_Drv.sCVIL_AD = sSlowIAD;
	spi_result = bBMICCheckSpiResult();
	if(spi_result == true){
		LONG lCurrent_10mA;
		BMIC_Drv.usSPI_ComAtLeastOnceFlg |= COMM_AD_ILOW;
		ftmp = fBMIC_CurClbGain;
/*		ftmp *= 6.103515625;		*/
/*		ftmp *= SHUNT_mohm;     */
/*	 	ftmp *= 54.931640625;	*/									/* 360 * 10000 / 65536 / 1 = 54.931640625 */
/*	 	ftmp *= 54.931640625 / (float)SHUNT_mohm;*/					/* 360 * 10000 / 65536 / SHUNT_mohm = 54.931640625/SHUNT_mohm */
		ftmp *= (float)54931.640625 / (float)SHUNT_uohm;					/* 360 * 10000 * 1000 / 65536 / SHUNT_uohm = 54931.640625 / SHUNT_uohm */
		ftmp *= (float)sSlowIAD;
		BMIC_Info.lBatPackCur_100uA = (LONG)ftmp;				/* slow AD */

		lCurrent_10mA = BMIC_Info.lBatPackCur_100uA / 100;			/* slow AD */
		BMIC_Info.usBatPackCur_10mA_300A = (USHORT)(lCurrent_10mA + 30000);	/* Pack current[10mA] =Pack current[10mA] + offset(300A * 100[10mA])	*/

		if(iads_complete){
			iads_complete = 0u;
			vLogBMIC_ADIL_Data((USHORT)sSlowIAD);
		}
	}

}


/****************************************************************************
FUNCTION	: vBMIC_Register_ReadCtrl
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMIC_Register_ReadCtrl(void)
{
	vBMICReadReg_Multi(PWR_CTRL_ADDR, BMIC_REG_TOTNUM);				/* Read register 0x01 ~ 0x59 (89) */

	if(BMIC_Drv.usSPI_ComAtLeastOnceFlg == COMM_RECEIVE_ALL) {
		BMIC_Info.BMICMeasured = true;
	}
}


#if(ESS_DEMO_CB)
/****************************************************************************
FUNCTION	: vBMIC_CBL_Control
DESCRIPTION	: Cell balancing control of ESS demo
			: Adjacent cell selection not allowed
			: EN_MSOCB ON: CB on / off (1sec ~ 15sec)
			: EN_MSOCB OFF: CB on
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2025/08/06
*****************************************************************************/
void vBMIC_CBL_Control(void){
	ULONG req_state;
	UCHAR next_cell_balancer = BMIC_Drv.ucBMIC_Cell_Balancer;
	UCHAR cbl_counter = BMIC_Drv.ucCellBalancingCounter;

	static UCHAR ucCBL_OnTime;
	static UCHAR ucCBL_OffTime;
	static USHORT usOPMODE_OVUVsetting;

	req_state = BMIC_Drv.ulBMIC_Cell_Balancetgt;

	switch(BMIC_Drv.ucBMIC_Cell_Balancer){
	case NON_CELL_BALANCE:
		if((cbl_counter == 0u) && (req_state != 0u)){
			BMIC_Drv.ulBMIC_Cell_Balancetgt_set = req_state;

			/* Update required CB On/Off Time when new cycle of CB start */
			ucCBL_OnTime = BMIC_Drv.ucCellBalancingOnTime;
			ucCBL_OffTime = BMIC_Drv.ucCellBalancingOffTime;

			next_cell_balancer = CELL_BALANCE_ON;
			cbl_counter = ucCBL_OnTime;
		}
		break;

	case CELL_BALANCE_ON:
		if((cbl_counter == 0u)
		&&((usBMICReferRegData(CBSEL_17_ADDR)&EN_MSOCB) == EN_MSOCB)	/* EN_MSOCB ON? */
		){
			next_cell_balancer = NON_CELL_BALANCE;
			cbl_counter = ucCBL_OffTime;
		}
		break;
	}
	#if(1)	/* CB allowed when there is error */
/*	if (BMIC_Info.ulBatPackErrLog != 0u){*/	/* check err status of UV/OV/SCD/OCD/OCC  */
	if ((BMIC_Info.ulBatPackErrLog & MASK_TEMP_CUR_ERR) != 0u){	/* check err status of UV/OV/SCD/OCD/OCC  */
		next_cell_balancer = NON_CELL_BALANCE;
		cbl_counter = 0u;
	}
	#endif

	/* During CB on-going, if CB setting (target, ON/OFF time) change, stop CB immediately so to apply new settings */
	if(next_cell_balancer != NON_CELL_BALANCE){
		if((BMIC_Drv.ulBMIC_Cell_Balancetgt_set != BMIC_Drv.ulBMIC_Cell_Balancetgt)	/* CB target change? */
		|| (BMIC_Drv.ucCellBalancingOnTime != ucCBL_OnTime)							/* CB on time change? */
		|| (BMIC_Drv.ucCellBalancingOffTime != ucCBL_OffTime)						/* CB off time change? */
		){
			next_cell_balancer = NON_CELL_BALANCE;
			cbl_counter = 0u;
		}
	}

	if(ucLoop1secFlg){
		if(cbl_counter > 0u){
			cbl_counter--;
		} else {
			cbl_counter = 0u;
		}
	}

	if(BMIC_Drv.ucBMIC_Cell_Balancer != next_cell_balancer){
		USHORT send_data1;
		USHORT send_data2;
		ULONG cell_balance_target = BMIC_Drv.ulBMIC_Cell_Balancetgt_set;
		volatile UCHAR spi_result;
		UCHAR stat = OK;

		if(next_cell_balancer == CELL_BALANCE_ON){
			send_data1 = (USHORT)(cell_balance_target & 0x0000FFFF);
			send_data2 = (USHORT)((cell_balance_target >> 16) & 0x00000001);
		} else {
			send_data1 = 0u;
			send_data2 = 0u;
		}

		if(next_cell_balancer == CELL_BALANCE_ON){
			usOPMODE_OVUVsetting = usBMICReferRegData(OP_MODE_ADDR)&(OVMSK_OFF|UVMSK_OFF);
			if((usBMICReferRegData(CBSEL_17_ADDR)&EN_MSOCB) == (USHORT)0x0000u){		/* EN_MSOCB "0"? - measurment-oriented CB disabled */
				spi_result = ucBMIC_Send_Req(OP_MODE_ADDR, OVMSK_OFF|UVMSK_OFF, OVMSK_OFF|UVMSK_OFF, BMIC_DATA_INPUT_NEED);				/* OV/UV detection off  */
				stat &= spi_result;
			}

#if(BMIC_IC_TYPE == BMIC_KA49702A)
			spi_result = ucBMIC_Send_Req(ADCTL1_ADDR, NPD_CB_NORMAL, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);							/* ADCTL1: NPD_CB ON */
#else
			spi_result = ucBMIC_Send_Req(OTHCTL_ADDR, NPD_CB_NORMAL, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);							/* OTHCTL: NPD_CB ON */
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */
			stat &= spi_result;
			spi_result = ucBMIC_Send_Req(CBSEL_ADDR, send_data1, 0xFFFFu, BMIC_DATA_INPUT_NEED);									/* Select cell for CB1~16 */
			stat &= spi_result;
			spi_result = ucBMIC_Send_Req(CBSEL_17_ADDR, send_data2, 0x0001u, BMIC_DATA_INPUT_NEED);									/* Select cell for CB17 */
			stat &= spi_result;
			if(stat == OK){
				ucBMIC_Send_Req(OP_MODE_ADDR, CB_SET_ON, CB_SET_ON, BMIC_DATA_INPUT_NEED);											/* CB on  */
			} else {
				ucBMIC_Send_Req(CBSEL_ADDR, 0x0000u, 0xFFFFu, BMIC_DATA_INPUT_NEED);												/* Deselect cell for CB1~16 */
				ucBMIC_Send_Req(CBSEL_17_ADDR, 0x0000u, 0x0001u, BMIC_DATA_INPUT_NEED);												/* Deselect cell for CB17 */
				#if(1)
				ucBMIC_Send_Req(OP_MODE_ADDR, CB_SET_OFF|usOPMODE_OVUVsetting, CB_SET_ON|OVMSK_OFF|UVMSK_OFF, BMIC_DATA_INPUT_NEED);	/* CB off, OV/UV detection on */
				#else
				ucBMIC_Send_Req(OP_MODE_ADDR, CB_SET_OFF|OVMSK_ON|UVMSK_ON, CB_SET_ON|OVMSK_OFF|UVMSK_OFF, BMIC_DATA_INPUT_NEED);	/* CB off, OV/UV detection on */
				#endif
#if(BMIC_IC_TYPE == BMIC_KA49702A)
				ucBMIC_Send_Req(ADCTL1_ADDR, NPD_CB_POWERDOWN, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);									/* ADCTL1: NPD_CB OFF */
#else
				ucBMIC_Send_Req(OTHCTL_ADDR, NPD_CB_POWERDOWN, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);									/* OTHCTL: NPD_CB OFF */
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */
				next_cell_balancer = NON_CELL_BALANCE;
				cbl_counter = 0u;
			}
		}else{
			ucBMIC_Send_Req(OP_MODE_ADDR, CB_SET_OFF, CB_SET_ON, BMIC_DATA_INPUT_NEED);												/* CB off */
			ucBMIC_Send_Req(CBSEL_ADDR, send_data1, 0xFFFFu, BMIC_DATA_INPUT_NEED);													/* Deselect cell for CB1~16 */
			ucBMIC_Send_Req(CBSEL_17_ADDR, send_data2, 0x0001u, BMIC_DATA_INPUT_NEED);												/* Deselect cell for CB17 */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
			ucBMIC_Send_Req(ADCTL1_ADDR, NPD_CB_POWERDOWN, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);										/* ADCTL1: NPD_CB OFF */
#else
			ucBMIC_Send_Req(OTHCTL_ADDR, NPD_CB_POWERDOWN, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);										/* OTHCTL: NPD_CB OFF */
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */
			#if(1)
			ucBMIC_Send_Req(OP_MODE_ADDR, usOPMODE_OVUVsetting, OVMSK_OFF|UVMSK_OFF, BMIC_DATA_INPUT_NEED);							/* OV/UV detection on */
			#else
			ucBMIC_Send_Req(OP_MODE_ADDR, OVMSK_ON|UVMSK_ON, OVMSK_OFF|UVMSK_OFF, BMIC_DATA_INPUT_NEED);							/* OV/UV detection on */
			#endif
		}
	}
	BMIC_Drv.ucCellBalancingCounter = cbl_counter;
	BMIC_Drv.ucBMIC_Cell_Balancer = next_cell_balancer;
}


#else
/****************************************************************************
FUNCTION	: vBMIC_CBL_Control
DESCRIPTION	: Cell balancing control of EVEN/ODD cell
			  Both ODD & EVEN cell selected: ODD CELL CB (OnTime) -> CB OFF (OffTime) -> EVEN CELL CB (OnTime) -> NON CB (CB OFF) (OffTime) -> ODD CELL CB (OnTime) ...-> NON CB (CB OFF) (OffTime) (CB End)
			  Only ODD cell selected: ODD CELL CB (OnTime) -> NON CB (CB OFF) (OffTime) ->ODD CELL CB (OnTime) ... -> NON CB (CB OFF) (OffTime) (CB End)
			  Only EVEN cell selected: EVEN CELL CB (OnTime) -> NON CB (CB OFF) (OffTime) -> EVEN CELL CB (OnTime) ... -> NON CB (CB OFF) (OffTime) (CB End)
INPUT		:
OUTPUT		:
UPDATE		: 2023/07/06
DATE		: 2020/12/01
*****************************************************************************/
void vBMIC_CBL_Control(void){
	ULONG req_state;
	UCHAR next_cell_balancer = BMIC_Drv.ucBMIC_Cell_Balancer;
	UCHAR cbl_counter = BMIC_Drv.ucCellBalancingCounter;

	static ULONG ulCBtgt_oddcell = 0ul;
	static ULONG ulCBtgt_evencell = 0ul;
	static UCHAR ucCBL_OnTime;
	static UCHAR ucCBL_OffTime;

	req_state = BMIC_Drv.ulBMIC_Cell_Balancetgt;

	switch(BMIC_Drv.ucBMIC_Cell_Balancer){
	case NON_CELL_BALANCE:
		if((cbl_counter == 0u) && (req_state != 0u)){
			BMIC_Drv.ulBMIC_Cell_Balancetgt_set = req_state;

			/* Update required CB target & On/Off Time when new cycle of CB start */
			ulCBtgt_oddcell = req_state & BMIC_Drv.ulBMIC_CBL_Odd_Mask;
			ulCBtgt_evencell =	req_state & (~BMIC_Drv.ulBMIC_CBL_Odd_Mask);

			ucCBL_OnTime = BMIC_Drv.ucCellBalancingOnTime;
			ucCBL_OffTime = BMIC_Drv.ucCellBalancingOffTime;

			if(ulCBtgt_oddcell != 0ul){
				next_cell_balancer = ODD_CELL_BALANCE;
			}else{
				next_cell_balancer = EVEN_CELL_BALANCE;
			}
			cbl_counter = ucCBL_OnTime;
		}
		break;

	case ODD_CELL_BALANCE:
		if(cbl_counter == 0u){
			if(ulCBtgt_evencell != 0u){
				next_cell_balancer = CELL_BALANCE_OFF;
			}else{
				next_cell_balancer = NON_CELL_BALANCE;
			}
			cbl_counter = ucCBL_OffTime;
		}
		break;

	case CELL_BALANCE_OFF:
		if(cbl_counter == 0u){
			next_cell_balancer = EVEN_CELL_BALANCE;
			cbl_counter = ucCBL_OnTime;
		}
		break;

	case EVEN_CELL_BALANCE:
		if(cbl_counter == 0u){
			next_cell_balancer = NON_CELL_BALANCE;
			cbl_counter = ucCBL_OffTime;
		}
		break;
	}

	if (BMIC_Info.ulBatPackErrLog != 0u){	/* check err status of UV/OV/SCD/OCD/OCC  */
		next_cell_balancer = NON_CELL_BALANCE;
		cbl_counter = 0u;
	}

	if(cbl_counter > 0u){
		cbl_counter--;
	} else {
		cbl_counter = 0u;
	}

	if(BMIC_Drv.ucBMIC_Cell_Balancer != next_cell_balancer){
		USHORT send_data1;
		USHORT send_data2;
		ULONG cell_balance_target = BMIC_Drv.ulBMIC_Cell_Balancetgt_set;
		volatile UCHAR spi_result;
		UCHAR stat = OK;

		if(next_cell_balancer == ODD_CELL_BALANCE){
			send_data1 = (USHORT)((cell_balance_target & BMIC_Drv.ulBMIC_CBL_Odd_Mask) & 0x0000FFFF);
			send_data2 = (USHORT)(((cell_balance_target & BMIC_Drv.ulBMIC_CBL_Odd_Mask) >> 16) & 0x0000FFFF);
		} else if(next_cell_balancer == EVEN_CELL_BALANCE){
			send_data1 = (USHORT)((cell_balance_target & (~BMIC_Drv.ulBMIC_CBL_Odd_Mask)) & 0x0000FFFF);
			send_data2 = (USHORT)(((cell_balance_target & (~BMIC_Drv.ulBMIC_CBL_Odd_Mask)) >> 16) & 0x0000FFFF);
		} else {
			send_data1 = 0u;
			send_data2 = 0u;
		}

		if((next_cell_balancer == ODD_CELL_BALANCE) || (next_cell_balancer == EVEN_CELL_BALANCE)){
			if((usBMICReferRegData(CBSEL_17_ADDR)&EN_MSOCB) == (USHORT)0x0000u){		/* EN_MSOCB "0"? - measurment-oriented CB disabled */
				spi_result = ucBMIC_Send_Req(OP_MODE_ADDR, OVMSK_OFF|UVMSK_OFF, OVMSK_OFF|UVMSK_OFF, BMIC_DATA_INPUT_NEED);				/* OV/UV detection off  */
				stat &= spi_result;
			}

#if(BMIC_IC_TYPE == BMIC_KA49702A)
			spi_result = ucBMIC_Send_Req(ADCTL1_ADDR, NPD_CB_NORMAL, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);							/* ADCTL1: NPD_CB ON */
#else
			spi_result = ucBMIC_Send_Req(OTHCTL_ADDR, NPD_CB_NORMAL, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);							/* OTHCTL: NPD_CB ON */
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */
			stat &= spi_result;
			spi_result = ucBMIC_Send_Req(CBSEL_ADDR, send_data1, 0xFFFFu, BMIC_DATA_INPUT_NEED);									/* Select cell for CB1~16 */
			stat &= spi_result;
			spi_result = ucBMIC_Send_Req(CBSEL_17_ADDR, send_data2, 0x0001u, BMIC_DATA_INPUT_NEED);									/* Select cell for CB17 */
			stat &= spi_result;
			if(stat == OK){
				ucBMIC_Send_Req(OP_MODE_ADDR, CB_SET_ON, CB_SET_ON, BMIC_DATA_INPUT_NEED);											/* CB on  */
			} else {
				ucBMIC_Send_Req(CBSEL_ADDR, 0x0000u, 0xFFFFu, BMIC_DATA_INPUT_NEED);												/* Deselect cell for CB1~16 */
				ucBMIC_Send_Req(CBSEL_17_ADDR, 0x0000u, 0x0001u, BMIC_DATA_INPUT_NEED);												/* Deselect cell for CB17 */
				ucBMIC_Send_Req(OP_MODE_ADDR, CB_SET_OFF|OVMSK_ON|UVMSK_ON, CB_SET_ON|OVMSK_OFF|UVMSK_OFF, BMIC_DATA_INPUT_NEED);	/* CB off, OV/UV detection on */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
				ucBMIC_Send_Req(ADCTL1_ADDR, NPD_CB_POWERDOWN, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);									/* ADCTL1: NPD_CB OFF */
#else
				ucBMIC_Send_Req(OTHCTL_ADDR, NPD_CB_POWERDOWN, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);									/* OTHCTL: NPD_CB OFF */
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */
				next_cell_balancer = NON_CELL_BALANCE;
				cbl_counter = 0u;
			}
		}else{
			ucBMIC_Send_Req(OP_MODE_ADDR, CB_SET_OFF, CB_SET_ON, BMIC_DATA_INPUT_NEED);												/* CB off */
			ucBMIC_Send_Req(CBSEL_ADDR, send_data1, 0xFFFFu, BMIC_DATA_INPUT_NEED);													/* Deselect cell for CB1~16 */
			ucBMIC_Send_Req(CBSEL_17_ADDR, send_data2, 0x0001u, BMIC_DATA_INPUT_NEED);												/* Deselect cell for CB17 */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
			ucBMIC_Send_Req(ADCTL1_ADDR, NPD_CB_POWERDOWN, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);										/* ADCTL1: NPD_CB OFF */
#else
			ucBMIC_Send_Req(OTHCTL_ADDR, NPD_CB_POWERDOWN, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);										/* OTHCTL: NPD_CB OFF */
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */
			ucBMIC_Send_Req(OP_MODE_ADDR, OVMSK_ON|UVMSK_ON, OVMSK_OFF|UVMSK_OFF, BMIC_DATA_INPUT_NEED);							/* OV/UV detection on */
		}
	}
	BMIC_Drv.ucCellBalancingCounter = cbl_counter;
	BMIC_Drv.ucBMIC_Cell_Balancer = next_cell_balancer;
}
#endif	/* ESS_DEMO_CB */

/****************************************************************************
FUNCTION	: vBMIC_CBL_Init
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/2/19
*****************************************************************************/
void vBMIC_CBL_Init(void)
{
	BMIC_Drv.ucBMIC_Cell_Balancer = NON_CELL_BALANCE;
	BMIC_Drv.ucCellBalancingCounter = 0u;
	BMIC_Drv.ulBMIC_Cell_Balancetgt = 0u;

	BMIC_Drv.ulBMIC_Cell_Balancetgt_set = 0u;

	if((BMICCellConf.ucSeriesCount % (UCHAR)2) == (UCHAR)0) {
		BMIC_Drv.ulBMIC_CBL_Odd_Mask = CELL_ODD_MASK_EVENCELL;
	} else {
		BMIC_Drv.ulBMIC_CBL_Odd_Mask = CELL_ODD_MASK_ODDCELL;
	}
}


/****************************************************************************
FUNCTION	: vBMIC_SetCellbalanceReq
DESCRIPTION	: Set cell numbers for Cell Balancing, and the cell balance control sequence ON & OFF timing
INPUT		: ULONG target - selected cells for cell balancing
              UCHAR cb_on_time - minimum suport ON time is 500ms - BMS_CTL_TM_500MSEC
              UCHAR cb_off_time - minimum suport OFF time is 500ms - BMS_CTL_TM_500MSEC
OUTPUT		: None
UPDATE		:
DATE		: 2023/07/05
*****************************************************************************/
void vBMIC_SetCellbalanceReq(ULONG target, UCHAR cb_on_time, UCHAR cb_off_time)
{
	ULONG target_tmp = 0u;
/*	if (BMIC_Info.ulBatPackErrLog == 0u) {	*/	/* CB allowed when there is error */
	if ((BMIC_Info.ulBatPackErrLog & MASK_TEMP_CUR_ERR) == 0u) {	/* CB not allowed when there is current or temperature error, OV/UV error allowed */
		UCHAR all_bit_set = 1u;
		ULONG chk_bit = 0u;
		UCHAR shift = 0u;
		UCHAR i;

		for (i = 0u; i < BMICCellConf.ucSeriesCount; i++) {
			chk_bit = ((ULONG)0x00000001 << i);
			if ((target & chk_bit) != 0u) {
				shift = BMIC_Drv.ucCellList[i];
				target_tmp |= (ULONG)((ULONG)0x00000001u << shift);
			} else {
				all_bit_set = 0u;
			}
		}
		if(all_bit_set == 1u){
			target_tmp = 0u;
		} else {
#if(ESS_DEMO_CB)
			if((target_tmp != 0) 							/* CB cell select not 0? */
			&& ((target_tmp & (target_tmp >> 1)) != 0)		/* adjacent cell selected for CB? */
			){
				target_tmp = 0u;
			}
#else
			;
#endif	/* ESS_DEMO_CB */
		}
	}
	BMIC_Drv.ulBMIC_Cell_Balancetgt = target_tmp;

	if(cb_on_time < CELL_BALANCE_ONOFF_MIN_TIME){
		BMIC_Drv.ucCellBalancingOnTime = CELL_BALANCE_ONOFF_MIN_TIME;
	}else{
		BMIC_Drv.ucCellBalancingOnTime = cb_on_time;
	}

	if(cb_off_time < CELL_BALANCE_ONOFF_MIN_TIME){
		BMIC_Drv.ucCellBalancingOffTime = CELL_BALANCE_ONOFF_MIN_TIME;
	}else{
		BMIC_Drv.ucCellBalancingOffTime = cb_off_time;
	}
}

/****************************************************************************
FUNCTION	: ulBMIC_GetCellbalanceReqPack
DESCRIPTION	: Get cell numbers under Cell Balancing
INPUT		: None
OUTPUT		: ULONG - Cell numbers under cell balancing
UPDATE		: 2020/12/01
DATE		: 2019/11/01
*****************************************************************************/
ULONG ulBMIC_GetCellbalanceReqPack(void){
	ULONG ret = 0u;
	ULONG cellbal;
	UCHAR i = 0u;
	ULONG chk_bit = 0u;
	CHAR skip_shift = 0u;

	cellbal = BMIC_Drv.ulBMIC_Cell_Balancetgt;

	for(i=0; i<BMICCellConf.ucSeriesCount; i++) {
		chk_bit = (ULONG)((ULONG)0x1u << BMIC_Drv.ucCellList[i]);
		skip_shift = (CHAR)(BMIC_Drv.ucCellList[i] - i);
		if(skip_shift < 0) {
			skip_shift = 0u;
		}
		if((chk_bit & cellbal) != 0u) {
			ret |= (chk_bit >> (UCHAR)skip_shift);
		}
	}
	return ret;
}

/****************************************************************************
FUNCTION	: ulBMIC_GetCellbalanceReq
DESCRIPTION	: Get cell positions under Cell Balancing
INPUT		: None
OUTPUT		: ULONG - Cell positions under cell balancing
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
ULONG ulBMIC_GetCellbalanceReq(void)
{
	ULONG ret = 0u;

	ret = BMIC_Drv.ulBMIC_Cell_Balancetgt;

	return ret;
}

/****************************************************************************
FUNCTION	: vBMIC_GetCellbalanceONOFFtime
DESCRIPTION	: Get Cell balance Setting
INPUT		: UCHAR *cb_on_time, UCHAR *cb_off_time (Cell Balancing ON & OFF time)
OUTPUT		:
UPDATE		:
DATE		: 2023/07/14
*****************************************************************************/
void vBMIC_GetCellbalanceONOFFtime(UCHAR *cb_on_time, UCHAR *cb_off_time)
{
	*(cb_on_time)= BMIC_Drv.ucCellBalancingOnTime;
	*(cb_off_time) = BMIC_Drv.ucCellBalancingOffTime;
}


/****************************************************************************
FUNCTION	: bBMIC_ChkCellbalance
DESCRIPTION	: Check Cell Balancing status
INPUT		: None
OUTPUT		: true: in CB operation, false: not in CB operation
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
bool bBMIC_ChkCellbalance(void){
	bool ret = false;

	if((BMIC_Drv.ucBMIC_Cell_Balancer != NON_CELL_BALANCE)
#if(ESS_DEMO_CB)
#else
	&& (BMIC_Drv.ucBMIC_Cell_Balancer != CELL_BALANCE_OFF)
#endif	/* ESS_DEMO_CB */
	){
		ret = true;
	}

	return ret;
}


/****************************************************************************
FUNCTION	: vBMIC_Discharge_FET_Out
DESCRIPTION	: Set BMIC discharge MOSFET on / off
INPUT		: UCHAR output 0: FET_OFF, 1: FET_ON
OUTPUT		:
UPDATE		: 2024/06/26
DATE		: 2023/10/20
*****************************************************************************/
void vBMIC_Discharge_FET_Out(UCHAR output)
{
	USHORT snd_data = FDRV_DIS_FET_OFF;
	UCHAR fet_alarm_clr_req = 0u;
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	USHORT data = usBMICReferRegData(MODESTAT_ADDR);
#else
	USHORT data = usBMICReferRegData(STAT1_ADDR);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	if(output == 1u){
		snd_data = FDRV_DIS_FET_ON;
		if((data & FDRV_DIS_ST_MASK) == 0u){
			fet_alarm_clr_req = 1u;
		}
	}
	if(fet_alarm_clr_req == 1u){
		ucBMIC_Send_Req(FDRV_CTRL_ADDR, FDRV_ALM_CLR, FDRV_ALM_CLR, BMIC_DATA_INPUT_NONE);
		ucBMIC_Send_Req(FDRV_CTRL_ADDR, (USHORT)~FDRV_ALM_CLR, FDRV_ALM_CLR, BMIC_DATA_INPUT_NEED);

#if(BMIC_IC_TYPE == BMIC_KA49702A)
		/* Check CHG/DIS FET setting for Alarm(OTC/OTD/UTC/UTD) response & recover when Alarm release */
		data = usBMICReferRegData(OTUT_CTRL_ADDR)&(FDRV_ALM_SD2 | FDRV_ALM_RCV2);
		if(data==(FDRV_ALM_SD2 | FDRV_ALM_RCV2)){			/* CHG/DIS FET response to Alarm(OTC/OTC/UTC/UTD) & not auto recover */
			ucBMIC_Send_Req(OTUT_CTRL_ADDR, FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NONE);
			ucBMIC_Send_Req(OTUT_CTRL_ADDR, (USHORT)~FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NEED);
		}
#else
		/* Check CHG/DIS FET setting for Alarm(OTC/OTD/UTC/UTD) response & recover when Alarm release */
		data = usBMICReferRegData(FDRV_CTRL2_ADDR)&(FDRV_ALM_SD2 | FDRV_ALM_RCV2);
		if(data==(FDRV_ALM_SD2 | FDRV_ALM_RCV2)){			/* CHG/DIS FET response to Alarm(OTC/OTC/UTC/UTD) & not auto recover */
			ucBMIC_Send_Req(FDRV_CTRL2_ADDR, FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NONE);
			ucBMIC_Send_Req(FDRV_CTRL2_ADDR, (USHORT)~FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NEED);
		}
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
	}
	ucBMIC_Send_Req(FDRV_CTRL_ADDR, snd_data, FDRV_DIS_FET_MASK, BMIC_DATA_INPUT_NEED);

}


/****************************************************************************
FUNCTION	: vBMIC_Charge_FET_Out
DESCRIPTION	: Set BMIC charge MOSFET on / off
INPUT		: UCHAR output 0: FET_OFF, 1: FET_ON
OUTPUT		:
UPDATE		: 2024/06/26
DATE		: 2023/10/20
*****************************************************************************/
void vBMIC_Charge_FET_Out(UCHAR output)
{
	USHORT snd_data = FDRV_CHG_FET_OFF;
	UCHAR fet_alarm_clr_req = 0u;
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	USHORT data = usBMICReferRegData(MODESTAT_ADDR);
#else
	USHORT data = usBMICReferRegData(STAT1_ADDR);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	if(output == 1u){
		snd_data = FDRV_CHG_FET_ON;
		if((data & FDRV_CHG_ST_MASK) == 0u){
			fet_alarm_clr_req = 1u;
		}
	}
	if(fet_alarm_clr_req == 1u){
		ucBMIC_Send_Req(FDRV_CTRL_ADDR, FDRV_ALM_CLR, FDRV_ALM_CLR, BMIC_DATA_INPUT_NONE);
		ucBMIC_Send_Req(FDRV_CTRL_ADDR, (USHORT)~FDRV_ALM_CLR, FDRV_ALM_CLR, BMIC_DATA_INPUT_NEED);

#if(BMIC_IC_TYPE == BMIC_KA49702A)
		/* Check CHG/DIS FET setting for Alarm(OTC/OTD/UTC/UTD) response & recover when Alarm release */
		data = usBMICReferRegData(OTUT_CTRL_ADDR)&(FDRV_ALM_SD2 | FDRV_ALM_RCV2);
		if(data==(FDRV_ALM_SD2 | FDRV_ALM_RCV2)){			/* CHG/DIS FET response to Alarm(OTC/OTC/UTC/UTD) & not auto recover */
			ucBMIC_Send_Req(OTUT_CTRL_ADDR, FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NONE);
			ucBMIC_Send_Req(OTUT_CTRL_ADDR, (USHORT)~FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NEED);
		}
#else
		/* Check CHG/DIS FET setting for Alarm(OTC/OTD/UTC/UTD) response & recover when Alarm release */
		data = usBMICReferRegData(FDRV_CTRL2_ADDR)&(FDRV_ALM_SD2 | FDRV_ALM_RCV2);
		if(data==(FDRV_ALM_SD2 | FDRV_ALM_RCV2)){			/* CHG/DIS FET response to Alarm(OTC/OTC/UTC/UTD) & not auto recover */
			ucBMIC_Send_Req(FDRV_CTRL2_ADDR, FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NONE);
			ucBMIC_Send_Req(FDRV_CTRL2_ADDR, (USHORT)~FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NEED);
		}
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	}
	ucBMIC_Send_Req(FDRV_CTRL_ADDR, snd_data, FDRV_CHG_FET_MASK, BMIC_DATA_INPUT_NEED);

}

#if(BMIC_IC_TYPE == BMIC_KA49702A)
/****************************************************************************
FUNCTION	: vBMIC_PreDischarge_FET_Out
DESCRIPTION	: Set BMIC pre discharge MOSFET on / off via GPOH2
INPUT		: UCHAR output (1: output ON, 0: output OFF (Hi-Z, default)
INPUT		: UCHAR fet_setting (1: FET control setting of GPOHx - FET control use, 0: FET control not in use (default)
OUTPUT		:
UPDATE		: 2024/06/26
DATE		: 2024/03/05
*****************************************************************************/
void vBMIC_PreDischarge_FET_Out(UCHAR output, UCHAR fet_setting)
{
	USHORT snd_data = GPOH2_HIZ;
	UCHAR fet_alarm_clr_req = 0u;
	USHORT data = usBMICReferRegData(MODESTAT_ADDR);

	if(output == 1u){
		snd_data = GPOH2_LOW;
		if((data & GPOH2_ST_MASK) == 0u){
			fet_alarm_clr_req = 1u;
		}
	}

	if(fet_setting == USE_GPOH_FET){
		snd_data |= GPOH_FET_FET;
	}

	if(fet_alarm_clr_req == 1u){
		ucBMIC_Send_Req(FDRV_CTRL_ADDR, FDRV_ALM_CLR, FDRV_ALM_CLR, BMIC_DATA_INPUT_NONE);
		ucBMIC_Send_Req(FDRV_CTRL_ADDR, (USHORT)~FDRV_ALM_CLR, FDRV_ALM_CLR, BMIC_DATA_INPUT_NEED);

		/* Check CHG/DIS FET setting for Alarm(OTC/OTD/UTC/UTD) response & recover when Alarm release */
		data = usBMICReferRegData(OTUT_CTRL_ADDR)&(FDRV_ALM_SD2 | FDRV_ALM_RCV2);
		if(data==(FDRV_ALM_SD2 | FDRV_ALM_RCV2)){			/* CHG/DIS FET response to Alarm(OTC/OTC/UTC/UTD) & not auto recover */
			ucBMIC_Send_Req(OTUT_CTRL_ADDR, FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NONE);
			ucBMIC_Send_Req(OTUT_CTRL_ADDR, (USHORT)~FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NEED);
		}
	}
	ucBMIC_Send_Req(GPOH_CTL_ADDR, snd_data, GPOH_FET_MASK | GPOH2_MASK, BMIC_DATA_INPUT_NEED);
}

/****************************************************************************
FUNCTION	: vBMIC_PreCharge_FET_Out
DESCRIPTION	: Set BMIC pre charge MOSFET on / off via GPOH1
INPUT		: UCHAR output (1: output ON, 0: output OFF (Hi-Z, default)
INPUT		: UCHAR fet_setting (1: FET control setting of GPOHx - FET control use, 0: FET control not in use (default)
OUTPUT		:
UPDATE		: 2024/06/26
DATE		: 2024/03/05
*****************************************************************************/
void vBMIC_PreCharge_FET_Out(UCHAR output, UCHAR fet_setting)
{
	USHORT snd_data = GPOH1_HIZ;
	UCHAR fet_alarm_clr_req = 0u;
	USHORT data = usBMICReferRegData(MODESTAT_ADDR);

	if(output == 1u){
		snd_data = GPOH1_LOW;
		if((data & GPOH1_ST_MASK) == 0u){
			fet_alarm_clr_req = 1u;
		}
	}
	if(fet_setting == USE_GPOH_FET){
		snd_data |= GPOH_FET_FET;
	}

	if(fet_alarm_clr_req == 1u){
		ucBMIC_Send_Req(FDRV_CTRL_ADDR, FDRV_ALM_CLR, FDRV_ALM_CLR, BMIC_DATA_INPUT_NONE);
		ucBMIC_Send_Req(FDRV_CTRL_ADDR, (USHORT)~FDRV_ALM_CLR, FDRV_ALM_CLR, BMIC_DATA_INPUT_NEED);

		/* Check CHG/DIS FET setting for Alarm(OTC/OTD/UTC/UTD) response & recover when Alarm release */
		data = usBMICReferRegData(OTUT_CTRL_ADDR)&(FDRV_ALM_SD2 | FDRV_ALM_RCV2);
		if(data==(FDRV_ALM_SD2 | FDRV_ALM_RCV2)){			/* CHG/DIS FET response to Alarm(OTC/OTC/UTC/UTD) & not auto recover */
			ucBMIC_Send_Req(OTUT_CTRL_ADDR, FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NONE);
			ucBMIC_Send_Req(OTUT_CTRL_ADDR, (USHORT)~FDRV_ALM_CLR2, FDRV_ALM_CLR2, BMIC_DATA_INPUT_NEED);
		}
	}
	ucBMIC_Send_Req(GPOH_CTL_ADDR, snd_data, GPOH_FET_MASK | GPOH1_MASK, BMIC_DATA_INPUT_NEED);
}
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */


/****************************************************************************
FUNCTION	: vBMIC_SHDN_Out
DESCRIPTION	: set BMIC SHDN
INPUT		: output GPIO_PIN_RESET(Low) - normal, GPIO_PIN_SET(High) - force BMIC to enter Shutdown mode
OUTPUT		: None
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMIC_SHDN_Out(UCHAR output)
{
	UCHAR state = GPIO_PIN_RESET;
	if(output == HIGH){
		state = GPIO_PIN_SET;
	}
	GPIO_PORT_BMIC_SHDN = state;
}

/****************************************************************************
FUNCTION	: vBMIC_FETOFF_Out
DESCRIPTION	: set BMIC FETOFF
INPUT		: output GPIO_PIN_RESET(Low) - FET normal, GPIO_PIN_SET(High) - FET forced off
OUTPUT		: None
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMIC_FETOFF_Out(UCHAR output)
{
	UCHAR state = GPIO_PIN_RESET;
	if(output == HIGH){						/* High : Force swith off	*/
		state = GPIO_PIN_SET;
	}
	GPIO_PORT_BMIC_FETOFF = state;
}

/****************************************************************************
FUNCTION	: ucGetBMIC_ALARM1_In
DESCRIPTION	: Check ALARM1
			: (ALARM_CTL1 & ALARM_CTL2 to set which errors to output ALARM1 )
INPUT		: None
OUTPUT		: HIGH - no error, LOW - has error
UPDATE		:
DATE		: 2023/10/19
*****************************************************************************/
UCHAR ucGetBMIC_ALARM1_In(void)
{
	UCHAR in = LOW;
	if(GPIO_PORT_BMIC_ALARM1 == GPIO_PIN_SET){
		in = HIGH;
	}
	return in;
}

/****************************************************************************
FUNCTION	: ucGetBMIC_SDO_In
DESCRIPTION	: Get SDO port input
INPUT		: None
OUTPUT		: HIGH or LOW
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
UCHAR ucGetBMIC_SDO_In(void)
{
	UCHAR in = LOW;
#if(ESS_DEMO_EVB)
	SYS->GPA_MFPH &= ~SYS_GPA_MFPH_PA9MFP_Msk;
#else
	SYS->GPC_MFPL &= ~SYS_GPC_MFPL_PC7MFP_Msk;
#endif /* ESS_DEMO_EVB */

	if(GPIO_PORT_BMIC_SDO == GPIO_PIN_SET){
		in = HIGH;
	}

#if(ESS_DEMO_EVB)
	SYS->GPA_MFPH |= SYS_GPA_MFPH_PA9MFP_SPI2_MISO;
#else
	SYS->GPC_MFPL |= SYS_GPC_MFPL_PC7MFP_SPI1_MISO;
#endif /* ESS_DEMO_EVB */

	return in;

}

#if(0)	/* BMIC GPIO port need to select ADIRQ2 output */
/****************************************************************************
FUNCTION	: ucGetBMIC_ADIRQ2_In
DESCRIPTION	: Check ADIRQ2 for Low Speed current measurement completion status
			: GPIO_CTRL1 init GPIO1 output sel ADIRQ2
INPUT		: None
OUTPUT		: High - Low Speed current measurement complete, Low - Low Speed current measurement in progress
UPDATE		:
DATE		: 2020/10/14
*****************************************************************************/
UCHAR ucGetBMIC_ADIRQ2_In(void)
{
	UCHAR in = LOW;
	if(GPIO_PORT_BMIC_GPIO3 == GPIO_PIN_SET){
		in = HIGH;
	}
	return in;
}
#endif

/****************************************************************************
FUNCTION	: ucGetBMICcrc
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
UCHAR ucGetBMICcrc(UCHAR *buf, UCHAR size)
{
	static const UCHAR ucCRC8_tCalc[] = {
		0x00u,0xd5u,0x7fu,0xaau,0xfeu,0x2bu,0x81u,0x54u,0x29u,0xfcu,0x56u,0x83u,0xd7u,0x02u,0xa8u,0x7du,
		0x52u,0x87u,0x2du,0xf8u,0xacu,0x79u,0xd3u,0x06u,0x7bu,0xaeu,0x04u,0xd1u,0x85u,0x50u,0xfau,0x2fu,
		0xa4u,0x71u,0xdbu,0x0eu,0x5au,0x8fu,0x25u,0xf0u,0x8du,0x58u,0xf2u,0x27u,0x73u,0xa6u,0x0cu,0xd9u,
		0xf6u,0x23u,0x89u,0x5cu,0x08u,0xddu,0x77u,0xa2u,0xdfu,0x0au,0xa0u,0x75u,0x21u,0xf4u,0x5eu,0x8bu,
		0x9du,0x48u,0xe2u,0x37u,0x63u,0xb6u,0x1cu,0xc9u,0xb4u,0x61u,0xcbu,0x1eu,0x4au,0x9fu,0x35u,0xe0u,
		0xcfu,0x1au,0xb0u,0x65u,0x31u,0xe4u,0x4eu,0x9bu,0xe6u,0x33u,0x99u,0x4cu,0x18u,0xcdu,0x67u,0xb2u,
		0x39u,0xecu,0x46u,0x93u,0xc7u,0x12u,0xb8u,0x6du,0x10u,0xc5u,0x6fu,0xbau,0xeeu,0x3bu,0x91u,0x44u,
		0x6bu,0xbeu,0x14u,0xc1u,0x95u,0x40u,0xeau,0x3fu,0x42u,0x97u,0x3du,0xe8u,0xbcu,0x69u,0xc3u,0x16u,
		0xefu,0x3au,0x90u,0x45u,0x11u,0xc4u,0x6eu,0xbbu,0xc6u,0x13u,0xb9u,0x6cu,0x38u,0xedu,0x47u,0x92u,
		0xbdu,0x68u,0xc2u,0x17u,0x43u,0x96u,0x3cu,0xe9u,0x94u,0x41u,0xebu,0x3eu,0x6au,0xbfu,0x15u,0xc0u,
		0x4bu,0x9eu,0x34u,0xe1u,0xb5u,0x60u,0xcau,0x1fu,0x62u,0xb7u,0x1du,0xc8u,0x9cu,0x49u,0xe3u,0x36u,
		0x19u,0xccu,0x66u,0xb3u,0xe7u,0x32u,0x98u,0x4du,0x30u,0xe5u,0x4fu,0x9au,0xceu,0x1bu,0xb1u,0x64u,
		0x72u,0xa7u,0x0du,0xd8u,0x8cu,0x59u,0xf3u,0x26u,0x5bu,0x8eu,0x24u,0xf1u,0xa5u,0x70u,0xdau,0x0fu,
		0x20u,0xf5u,0x5fu,0x8au,0xdeu,0x0bu,0xa1u,0x74u,0x09u,0xdcu,0x76u,0xa3u,0xf7u,0x22u,0x88u,0x5du,
		0xd6u,0x03u,0xa9u,0x7cu,0x28u,0xfdu,0x57u,0x82u,0xffu,0x2au,0x80u,0x55u,0x01u,0xd4u,0x7eu,0xabu,
		0x84u,0x51u,0xfbu,0x2eu,0x7au,0xafu,0x05u,0xd0u,0xadu,0x78u,0xd2u,0x07u,0x53u,0x86u,0x2cu,0xf9u
	};

	UCHAR	uccrc,uci;

	uccrc = 0xD5u;							/* CRC initial: 0xD5*/

	for( uci = 0u; uci < size; uci++) {
		uccrc = ucCRC8_tCalc[uccrc ^ buf[uci]];
	}

	return uccrc;

}

/****************************************************************************
FUNCTION	: vBMICWriteReg
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMICWriteReg(UCHAR addr, USHORT data)
{
	if(bBMIC_SpiTake(BMIC_SPIWAIT_TIMEOUT)){
		BMIC_Drv.ucTxBuf[0u] = 0xe0u;
		BMIC_Drv.ucTxBuf[1u] = (UCHAR)(addr << 1u);
		BMIC_Drv.ucTxBuf[2u] = (UCHAR)(data >> 8u);
		BMIC_Drv.ucTxBuf[3u] = (UCHAR)(data & 0xFFu);
		BMIC_Drv.ucTxBuf[4u] = ucGetBMICcrc(BMIC_Drv.ucTxBuf, 4u);

		SPI_BMIC_SEN_H();

		bSPI_BMIC_Tx(BMIC_Drv.ucTxBuf, 5);

		SPI_BMIC_SEN_L();

		vBMIC_Wait(BMIC_WAIT_1US);	/* 1uS Wait for next request */
		BMIC_Drv.ucBMIC_SPI_status = ucBMIC_Check_SPI_status();
		BMIC_SpiRelease();
	}
}

/****************************************************************************
FUNCTION	: vBMICWriteReg_Mask
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMICWriteReg_Mask(UCHAR addr, USHORT usdata, USHORT usMask, UCHAR ucdata)
{
	USHORT us_tmp;
	bool spi_result;

	us_tmp = usBMICReferRegData(addr);
	us_tmp = us_tmp & (usMask ^ 0xFFFFu);
	us_tmp = us_tmp | (usdata & usMask);

	vBMICWriteReg(addr, us_tmp);
	spi_result = bBMICCheckSpiResult();

	if ((ucdata == BMIC_DATA_INPUT_NEED) && (spi_result == true)){
		vBMICInputRecvData(addr, us_tmp);
	} else {
		;
	}
}

/****************************************************************************
FUNCTION	: usBMICReadReg
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
USHORT usBMICReadReg(UCHAR addr)
{
	USHORT	ret = usBMICReferRegData(addr);
	UCHAR	crc;
	UCHAR crc_err = 0u;
	UCHAR spi_miso = 0u;

	if(bBMIC_SpiTake(BMIC_SPIWAIT_TIMEOUT)){
		BMIC_Drv.ucTxBuf[0u] = 0xe1u;
		BMIC_Drv.ucTxBuf[1u] = (UCHAR)(addr << 1u);
		BMIC_Drv.ucTxBuf[2u] = ucGetBMICcrc(BMIC_Drv.ucTxBuf, 2u);
		BMIC_Drv.ucTxBuf[3u] = 0xFFu;
		BMIC_Drv.ucTxBuf[4u] = 0xFFu;
		BMIC_Drv.ucTxBuf[5u] = 0xFFu;

		SPI_BMIC_SEN_H();

		bSPI_BMIC_Rx(BMIC_Drv.ucTxBuf, BMIC_Drv.ucRxBuf, 6u);	/* 5byte=3byte(send)+3byte(receive)	*/

		SPI_BMIC_SEN_L();

		vBMIC_Wait(BMIC_WAIT_1US);	/* 1uS Wait for next request */
		crc = ucGetBMICcrc(&BMIC_Drv.ucRxBuf[3u], 2u);
		spi_miso = ucGetBMIC_SDO_In();
		if ((crc == BMIC_Drv.ucRxBuf[5u]) && (spi_miso == HIGH)) {
			ret = (USHORT)BMIC_Drv.ucRxBuf[3u] << 8u;
			ret += (USHORT)BMIC_Drv.ucRxBuf[4u];
			vBMICInputRecvData(addr, ret);
		} else {
			crc_err = 1u;
		}
		BMIC_Drv.ucBMIC_SPI_status = ucBMIC_Check_SPI_status_crc(crc_err);
		BMIC_SpiRelease();
	}
	return ret;
}

/****************************************************************************
FUNCTION	: vBMICReadReg_Multi
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMICReadReg_Multi(UCHAR addr, UCHAR num)
{
	UCHAR byte_num = (UCHAR)(num << 1u);
	UCHAR crc_error = 0u;
	UCHAR crc = 0u;
	UCHAR spi_miso = 0u;
	UCHAR i = 0u;

	if(bBMIC_SpiTake(BMIC_SPIWAIT_TIMEOUT)){
		BMIC_Drv.ucTxBuf[0u] = 0xe1u;
		BMIC_Drv.ucTxBuf[1u] = ((UCHAR)(addr << 1u) | 0x01u);
		BMIC_Drv.ucTxBuf[2u] = num-(UCHAR)1;
		BMIC_Drv.ucTxBuf[3u] = ucGetBMICcrc(&BMIC_Drv.ucTxBuf[0], 3u);
		for(i=4u; i< BMIC_PACKET_BUF_SIZE; i++){
			BMIC_Drv.ucTxBuf[i] = 0xFFu;
		}

		SPI_BMIC_SEN_H();

		bSPI_BMIC_Rx(BMIC_Drv.ucTxBuf, BMIC_Drv.ucRxBuf, byte_num+4u+1u);	/* 4byte(send)+byte_num(receive)+1byte CRC(receive)	*/

		SPI_BMIC_SEN_L();

		vBMIC_Wait(BMIC_WAIT_1US);	/* 1uS Wait for next request */
		crc = ucGetBMICcrc(&BMIC_Drv.ucRxBuf[4], byte_num);
		spi_miso = ucGetBMIC_SDO_In();
		if ((crc == BMIC_Drv.ucRxBuf[byte_num+4u]) && (spi_miso == HIGH)) {
			BMIC_Drv.usSPI_ComAtLeastOnceFlg |= COMM_MULTI_READ;
			for(i = 0; i < num; i++){
				UCHAR addr_index = i + addr;
				UCHAR buff_index = (UCHAR)(i << 1) + 4u;
				USHORT ret = (USHORT)BMIC_Drv.ucRxBuf[buff_index] << 8u;
				ret += (USHORT)BMIC_Drv.ucRxBuf[buff_index + 1u];
				vBMICInputRecvData(addr_index, ret);
			}
		} else {
			crc_error = 1u;
		}
		BMIC_Drv.ucBMIC_SPI_status = ucBMIC_Check_SPI_status_crc(crc_error);
		BMIC_SpiRelease();
	}
}

/****************************************************************************
FUNCTION	: usBMIC_ReadReg
DESCRIPTION	: Read BMIC register data from specified address
INPUT		: UCHAR addr - address of BMIC register to be read
OUTPUT		: return (USHORT)data of BMIC register from specified address
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
USHORT usBMIC_ReadReg(UCHAR addr)
{
	return usBMICReadReg(addr);
}

/****************************************************************************
FUNCTION	: ucBMIC_Send_Req
DESCRIPTION	: Change BMIC register data with mask bits at specified address and save
              to received register data buffer if required
INPUT		: UCHAR addr - address of BMIC register to be written
			  USHORT data - data to be written to BMIC register
			  USHORT mask - data mask of register bits to be changed
			  UCHAR mask_req - 1: to update register data in received register data buffer, 0: no update
OUTPUT		: true - write OK, false - write NG
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
UCHAR ucBMIC_Send_Req(UCHAR addr, USHORT data, USHORT mask, UCHAR mask_req)
{
	UCHAR ret = (UCHAR)false;
	volatile bool spi_result;
	UCHAR send_stat = OK;

	if((addr <= BMIC_REG_MAX_ADDR) && (addr != 0u)){
		vBMICWriteReg_Mask(addr, data, mask, mask_req);
		spi_result = bBMICCheckSpiResult();
		send_stat &= (UCHAR)spi_result;
	} else {
		send_stat &= 0u;
	}
	if(send_stat == OK){
		ret = (UCHAR)true;
	}
	return ret;
}


/****************************************************************************
FUNCTION	: usBMICReferRegData
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
USHORT usBMICReferRegData(UCHAR addr)
{
	return	BMIC_Drv.usRegData[addr];
}

/****************************************************************************
FUNCTION	: vBMICInputRecvData
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		: 2023/08/07
DATE		: 2019/11/01
*****************************************************************************/
void vBMICInputRecvData(UCHAR addr, USHORT usdata)
{
#if(BMS_TESTMODE)
	if(addr <= BMIC_REG_MAX_ADDR){
		BMIC_Drv.usRegData[addr] = usdata;
	}
#else
	BMIC_Drv.usRegData[addr] = usdata;
#endif /* BMS_TESTMODE */
}

/****************************************************************************
FUNCTION	: ucBMIC_Check_SPI_status
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
UCHAR ucBMIC_Check_SPI_status(void)
{
	UCHAR spi_miso = ucGetBMIC_SDO_In();
	UCHAR ret = 0u;

	if(spi_miso == LOW){
		BMIC_Drv.ucBMIC_SPI_err_count++;
		BMIC_Drv.ucBMIC_SPI_err_detail |= 0x01u;				/* bp0: write error - SDO low */
	} else {
		BMIC_Drv.ucBMIC_SPI_err_count = 0;
		BMIC_Drv.ucBMIC_SPI_err_detail &= 0xFEu;				/* bp0: write error clear */
	}

	if(BMIC_Drv.ucBMIC_SPI_err_count >= 5u){
		BMIC_Drv.ucBMIC_SPI_err_count = 5u;
		ret = 1u;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: ucBMIC_Check_SPI_status_crc
DESCRIPTION	:
INPUT		: UCHAR crc_chk
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
UCHAR ucBMIC_Check_SPI_status_crc(UCHAR crc_chk)
{
	UCHAR spi_miso = ucGetBMIC_SDO_In();
	UCHAR ret = 0u;
	if((spi_miso == LOW) || (crc_chk == 1u)){
		BMIC_Drv.ucBMIC_SPI_err_count++;

		BMIC_Drv.ucBMIC_SPI_err_detail |= 0x02u;				/* bp1: read error - SDO low or CRC */
	} else {
		BMIC_Drv.ucBMIC_SPI_err_count = 0;
		BMIC_Drv.ucBMIC_SPI_err_detail &= 0xFDu;			/* bp1: read erro clear */
	}

	if(BMIC_Drv.ucBMIC_SPI_err_count >= 5u){
		BMIC_Drv.ucBMIC_SPI_err_count = 5u;
		ret = 1u;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: bBMICCheckSpiResult
DESCRIPTION	: Check if there is any error in BMIC SPI communication
INPUT		: None
OUTPUT		: true - BMIC SPI no error, false - BMIC SPI has error
UPDATE		:
DATE		: 2020/01/15
*****************************************************************************/
bool bBMICCheckSpiResult(void)
{
	bool ret = true;
	if(BMIC_Drv.ucBMIC_SPI_err_count != 0u){
		ret = false;
	}
	return ret;
}


/****************************************************************************
FUNCTION	: ucGetBMIC_SpiErrDetail
DESCRIPTION	:
INPUT		:
OUTPUT		: UCHAR
UPDATE		:
DATE		: 2020/11/09
*****************************************************************************/
UCHAR ucGetBMIC_SpiErrDetail(void)
{
	return(BMIC_Drv.ucBMIC_SPI_err_detail);
}


/****************************************************************************
FUNCTION	: vBMIC_Clear_Spi_Err_counter
DESCRIPTION	: Clear BMIC SPI communication error count
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		: 2020/01/15
*****************************************************************************/
void vBMIC_Clear_Spi_Err_counter(void)
{
	BMIC_Drv.ucBMIC_SPI_err_count = 0u;
}


/****************************************************************************
FUNCTION	: vBMICRegInitRead
DESCRIPTION	: Read all registers
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMICRegInitRead(void)
{
	vBMICReadReg_Multi(PWR_CTRL_ADDR, BMIC_REG_TOTNUM);
}

/****************************************************************************
FUNCTION	: ucBMICRegInitChk
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
UCHAR	ucBMICRegInitChk(void)
{
	UCHAR ucjdg = OK;
	UCHAR ucret = ucBMICChk_CtrlReg();

	if(ucret != OK){
		ucjdg = NG;
	}
	return ucjdg;
}

/****************************************************************************
FUNCTION	: ucBMICChk_CtrlReg
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		: 2023/08/24
DATE		: 2019/11/01
*****************************************************************************/
UCHAR	ucBMICChk_CtrlReg(void)
{
	UCHAR   ucjdg = OK;
	UCHAR ucCnt = 0u;
	USHORT usregdata = 0u;
	USHORT usexpectdata = 0u;

	for (ucCnt=0u; ucCnt < BMIC_CTRL_INITTBL_NUM; ucCnt++) {
		usregdata = usBMICReferRegData(stCtrlReg_Init_BMIC[ucCnt].m_ucreg);
		usexpectdata = stCtrlReg_Init_BMIC[ucCnt].m_usdata;
		if ( usregdata != usexpectdata ) {
			ucjdg = NG;
			break;
		}
	}

	return ucjdg;
}

/****************************************************************************
FUNCTION	: ucBMICReadFuse
DESCRIPTION	: Read BMIC Internal pull-up resistance register and get pull-up resistance value
INPUT		: None
OUTPUT		:
UPDATE		: 2020/10/13
DATE		: 2019/11/01
*****************************************************************************/
UCHAR	ucBMICReadFuse(void)
{
	SHORT sfuse[MAX_THERMISTOR_NUM];
	USHORT usdata;
	CHAR data;
	volatile bool spi_result;
	UCHAR read_fuse_stat = (UCHAR)true;
	UCHAR i = 0u;

	usdata = usBMICReadReg(TMONI1_ADDR);
	spi_result = bBMICCheckSpiResult();
	read_fuse_stat &= (UCHAR)spi_result;
	usdata = usdata & (USHORT)0x03FF;						/* b9~0: TMONI1 pin pull-up resistance value */
	if((usdata & (USHORT)0x0200u) != (USHORT)0){
		usdata = ((USHORT)0xFE00 | usdata);
	}
	sfuse[0] = (SHORT)usdata;

	usdata = usBMICReadReg(TMONI23_ADDR);
	spi_result = bBMICCheckSpiResult();
	read_fuse_stat &= (UCHAR)spi_result;
	data = (CHAR)(usdata & 0x00FFu);						/*b7~0: TMONI2 pin pull-up resistance difference value */
	sfuse[1] = data + sfuse[0];
	data = (CHAR)((usdata & 0xFF00u) >> 8u);				/*b15~8: TMONI3 pin pull-up resistance difference value */
	sfuse[2] = data + sfuse[0];

	usdata = usBMICReadReg(TMONI45_ADDR);
	spi_result = bBMICCheckSpiResult();
	read_fuse_stat &= (UCHAR)spi_result;
	data = (CHAR)(usdata & 0x00FFu);						/*b7~0: TMONI4 pin pull-up resistance difference value */
	sfuse[3] = data + sfuse[0];
	data = (CHAR)((usdata & 0xFF00u) >> 8u);				/*b15~8: TMONI5 pin pull-up resistance difference value */
	sfuse[4] = data + sfuse[0];

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	usdata = usBMICReadReg(TMONI6_ADDR);
	spi_result = bBMICCheckSpiResult();
	read_fuse_stat &= (UCHAR)spi_result;
	data = (CHAR)(usdata & 0x00FFu);						/*b7~0: TMONI6 pin pull-up resistance difference value */
	sfuse[5] = data + sfuse[0];
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	if(read_fuse_stat == (UCHAR)true){
		for(i=0u; i < MAX_THERMISTOR_NUM; i++){
			BMIC_Drv.ulRfuse[i] = ulBMICCalcRfuse(sfuse[i]);
		}
	}
	return read_fuse_stat;
}

/****************************************************************************
FUNCTION	: ulBMICCalcRfuse
DESCRIPTION	: Calculate TMONIn internal pull-up resistance value
INPUT		: SHORT sfuse
OUTPUT		: ULONG rfuse
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
ULONG ulBMICCalcRfuse(SHORT sfuse)
{
	ULONG rfuse;
	if(sfuse > 511){
		sfuse = 511;
	} else if(sfuse < -512){
		sfuse = -512;
	} else {;}

	rfuse = (ULONG)((((6000 * sfuse) << 8) / 1024 + (10000 << 8)) >> 8);	/* usfuse(register) * 6K[ohm]/2^10 + 10K[ohm]	*/
	return rfuse;
}

/****************************************************************************
FUNCTION	: sCalcTemperature_01deg
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		: 2023/07/04
DATE		: 2019/11/01
*****************************************************************************/
SHORT sCalcTemperature_01deg(USHORT vtm_ad, UCHAR num)
{
	ULONG vdd_mV = ((ULONG)BMIC_Drv.usVdd50AD * 7500u) / 16384u;		/* VDD50 max 7.5V	*/
	ULONG vtm_mV = ((ULONG)vtm_ad * 5000u) / 16384u;					/* VTOMIn max 5V	*/

	SHORT ret;
	ULONG rth;

	if(vdd_mV <= vtm_mV){				/* When Vdd_mV <= Vtm_mV */
		rth = 0x3FFFF;
		ret = iLookupTemp_01deg(rth);
	}
	 else {
		rth = (vtm_mV * BMIC_Drv.ulRfuse[num]) / (vdd_mV - vtm_mV); 	/*Rth = (Vtm*Rfuse)/(Vdd-Vtm) */
		ret = iLookupTemp_01deg(rth);
	}

	return (ret);
}

#if(1)
#define	TC_TABLE_NUM (34u)
	typedef struct {
		SHORT		temp;
		ULONG	resistance;
	}TTemp_Characteristic;

	static const TTemp_Characteristic TC[TC_TABLE_NUM]= {
#if(1)
	/* Thermistor: NCU18XH103F60RB */
		{ -40,	195652 },
		{ -35,	148171 },
		{ -30,	113347 },
		{ -25,	87559  },
		{ -20,	68237  },
		{ -15,	53650  },
		{ -10,	42506  },
		{  -5,	33892  },
		{   0,	27219  },
		{   5,	22021  },
		{  10,	17926  },
		{  15,	14674  },
		{  20,	12081  },
		{  25,	10000  },
		{  30,	8315   },
		{  35,	6948   },
		{  40,	5834   },
		{  45,	4917   },
		{  50,	4161   },
		{  55,	3535   },
		{  60,	3014   },
		{  65,	2586   },
		{  70,	2228   },
		{  75,	1925   },
		{  80,	1669   },
		{  85,	1452   },
		{  90,	1268   },
		{  95,	1110   },
		{ 100,	974    },
		{ 105,	858    },
		{ 110,	758    },
		{ 115,	672    },
		{ 120,	596    },
		{ 125,	531    }
	};
#else
	/* NTC Thermistor: JOYIN JSNB103F338FABXG */
		{ -40,	178764 },
		{ -35,	137502 },
		{ -30,	106073 },
		{ -25,	 82329 },
		{ -20,	 64403 },
		{ -15,	 50814 },
		{ -10,	 40442 },
		{  -5,	 32458 },
		{   0,	 26256 },
		{   5,	 21392 },
		{  10,	 17544 },
		{  15,	 14472 },
		{  20,	 12002 },
		{  25,	 10000 },
		{  30,	  8367 },
		{  35,	  7028 },
		{  40,	  5924 },
		{  45,	  5010 },
		{  50,	  4249 },
		{  55,	  3615 },
		{  60,	  3084 },
		{  65,	  2638 },
		{  70,	  2262 },
		{  75,	  1946 },
		{  80,	  1678 },
		{  85,	  1451 },
		{  90,	  1258 },
		{  95,	  1095 },
		{ 100,	   955 },
		{ 105,	   836 },
		{ 110,	   734 },
		{ 115,	   646 },
		{ 120,	   571 },
		{ 125,	   506 }
	};
#endif
#else

#define	TC_TABLE_NUM (141u)
	typedef struct {
		SHORT		temp;
		ULONG	resistance;
	}TTemp_Characteristic;

	static const TTemp_Characteristic TC[TC_TABLE_NUM]= {
		/*NCP15XH103F03RC*/
		{ -40,	195652 },	{ -39,	184917 },	{ -38,	174845 },	{ -37,	165391 },	{ -36,	156512 },
		{ -35,	148171 },	{ -34,	140330 },	{ -33,	132957 },	{ -32,	126021 },	{ -31,	119493 },
		{ -30,	113347 },	{ -29,	107564 },	{ -28,	102115 },	{ -27,	96977 },	{ -26,	92131 },
		{ -25,	87558 },	{ -24,	83242 },	{ -23,	79166 },	{ -22,	75315 },	{ -21,	71676 },
		{ -20,	68236 },	{ -19,	64990 },	{ -18,	61919 },	{ -17,	59011 },	{ -16,	56257 },
		{ -15,	53649 },	{ -14,	51177 },	{ -13,	48834 },	{ -12,	46613 },	{ -11,	44505 },
		{ -10,	42506 },	{ -9,	40599 },	{ -8,	38790 },	{ -7,	37072 },	{ -6,	35441 },
		{ -5,	33892 },	{ -4,	32419 },	{ -3,	31020 },	{ -2,	29689 },	{ -1,	28423 },
		{ 0,	27218 },	{ 1,	26076 },	{ 2,	24987 },	{ 3,	23950 },	{ 4,	22962 },
		{ 5,	22021 },	{ 6,	21123 },	{ 7,	20266 },	{ 8,	19449 },	{ 9,	18669 },
		{ 10,	17925 },	{ 11,	17213 },	{ 12,	16534 },	{ 13,	15885 },	{ 14,	15265 },
		{ 15,	14673 },	{ 16,	14107 },	{ 17,	13566 },	{ 18,	13048 },	{ 19,	12554 },
		{ 20,	12080 },	{ 21,	11628 },	{ 22,	11194 },	{ 23,	10779 },	{ 24,	10381 },
		{ 25,	10000 },	{ 26,	9634 },		{ 27,	9283 },		{ 28,	8947 },		{ 29,	8624 },
		{ 30,	8314 },		{ 31,	8018 },		{ 32,	7733 },		{ 33,	7460 },		{ 34,	7199 },
		{ 35,	6947 },		{ 36,	6706 },		{ 37,	6475 },		{ 38,	6252 },		{ 39,	6039 },
		{ 40,	5833 },		{ 41,	5635 },		{ 42,	5445 },		{ 43,	5262 },		{ 44,	5086 },
		{ 45,	4916 },		{ 46,	4753 },		{ 47,	4597 },		{ 48,	4446 },		{ 49,	4300 },
		{ 50,	4160 },		{ 51,	4026 },		{ 52,	3896 },		{ 53,	3771 },		{ 54,	3651 },
		{ 55,	3535 },		{ 56,	3423 },		{ 57,	3315 },		{ 58,	3211 },		{ 59,	3111 },
		{ 60,	3014 },		{ 61,	2922 },		{ 62,	2833 },		{ 63,	2748 },		{ 64,	2665 },
		{ 65,	2586 },		{ 66,	2509 },		{ 67,	2435 },		{ 68,	2363 },		{ 69,	2294 },
		{ 70,	2227 },		{ 71,	2162 },		{ 72,	2100 },		{ 73,	2039 },		{ 74,	1981 },
		{ 75,	1924 },		{ 76,	1869 },		{ 77,	1817 },		{ 78,	1765 },		{ 79,	1716 },
		{ 80,	1668 },		{ 81,	1622 },		{ 82,	1577 },		{ 83,	1534 },		{ 84,	1492 },
		{ 85,	1452 },		{ 86,	1412 },		{ 87,	1374 },		{ 88,	1338 },		{ 89,	1302 },
		{ 90,	1268 },		{ 91,	1234 },		{ 92,	1201 },		{ 93,	1170 },		{ 94,	1139 },
		{ 95,	1109 },		{ 96,	1080 },		{ 97,	1052 },		{ 98,	1025 },		{ 99,	999 },
		{ 100,	973 }
	};
#endif

/****************************************************************************
FUNCTION	: iLookupTemp_01deg
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
SHORT iLookupTemp_01deg(ULONG rth)
{
	USHORT uiLeft;
	USHORT uiRight;
	float frac;
	UCHAR size = TC_TABLE_NUM - 1u;
	float temp;

	if(rth > TC[0].resistance){
		uiLeft = 0u;
		frac = 0.0;
	} else if(rth > TC[size].resistance) {
		USHORT index = (USHORT)size >> 1u;
		uiLeft = 0u;
		uiRight = size;
		while(uiRight - uiLeft > 1u){
			if(rth > TC[index].resistance){
				uiRight = index;
			} else {
				uiLeft = index;
			}
			index = (uiRight + uiLeft) >> 1u;
		}
		frac = (float)(TC[index].resistance - rth) / (float)(TC[index].resistance - TC[index+(USHORT)1].resistance);
	} else {
		uiLeft = size;
		frac = 0.0;
	}

	if(uiLeft == size){
		temp = (float)TC[uiLeft].temp;
	} else {
		temp = (TC[uiLeft+(USHORT)1].temp - TC[uiLeft].temp) * frac + (float)TC[uiLeft].temp;
	}
#if 0
	if(temp > 0.0){
		temp += 0.5;
	} else {
		temp = ((0.0 - temp) + 0.5);
		temp *= -1.0;
	}
#else
	temp *= (float)10.0;
#endif
	SHORT ret = (SHORT)temp;
	return (ret);
}

/****************************************************************************
FUNCTION	: ulLookupTemp_Resistance
DESCRIPTION	: Get thermistor resistance based on temperature
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/10/27
*****************************************************************************/
ULONG ulLookupTemp_Resistance(short stemp)
{

	USHORT uiLeft;
	USHORT uiRight;
	UCHAR size = TC_TABLE_NUM - 1u;
	USHORT index;
	LONG temp;

	ULONG ntcresistance;

	if(stemp < TC[0].temp){
		ntcresistance = TC[0].resistance;
	}else if(stemp < TC[size].temp){
		index = (USHORT)size >> 1u;
		uiLeft = 0u;
		uiRight = size;
		while(uiRight - uiLeft > 1u){
			if(stemp > TC[index].temp){
				uiLeft = index;
			} else {
				uiRight = index;
			}
			index = (uiRight + uiLeft) >> 1u;
		}
		if(stemp == TC[uiRight].temp){
			ntcresistance = TC[uiRight].resistance;
		}else if(stemp == TC[uiLeft].temp){
			ntcresistance = TC[uiLeft].resistance;
		}else{
			temp = (LONG)((TC[uiRight].resistance - TC[uiLeft].resistance))*((LONG)(stemp-TC[uiLeft].temp))/((LONG)(TC[uiRight].temp - TC[uiLeft].temp));
			ntcresistance = (ULONG)((LONG)(TC[uiLeft].resistance) + temp);
		}
	}else{
		ntcresistance = TC[size].resistance;
	}
	return(ntcresistance);

}

/****************************************************************************
FUNCTION	: ulGetTmoniMaxRfuse
DESCRIPTION	: Get TMONI group max Rfuse (internal pull-up resistance)
INPUT		: UCHAR ucgrp
OUTPUT		: ULONG	ulTmoniMaxRfuse
UPDATE		: 2024/04/08
DATE		: 2023/10/30
*****************************************************************************/
ULONG ulGetTmoniMaxRfuse(UCHAR ucgrp)
{
#if(1)
	UCHAR	ucCnt;
	UCHAR 	ucChkBit;
	UCHAR	ucTmoniGrpMask;
	ULONG	ulTmoniMaxRfuse = TMONI_RFUSE_MIN;		/* init as min pull-up resistance */

	if((usBMICReferRegData(OP_MODE_ADDR)&TMONISEL_MSK) == TMONISEL_MSK){		/* TMONISEL setting "1"? */
		if(ucgrp == TMONI_GROUP1){
			ucTmoniGrpMask = TMONISEL1_GRP1_MSK & (UCHAR)BMICCellConf.ulTmoniTempPos;
		}else{
			ucTmoniGrpMask = TMONISEL1_GRP2_MSK & (UCHAR)BMICCellConf.ulTmoniTempPos;
		}
	}else{																		/* TMONISEL setting "0" */
		if(ucgrp == TMONI_GROUP1){
			ucTmoniGrpMask = TMONISEL0_GRP1_MSK & (UCHAR)BMICCellConf.ulTmoniTempPos;
		}else{
			ucTmoniGrpMask = TMONISEL0_GRP2_MSK & (UCHAR)BMICCellConf.ulTmoniTempPos;
		}
	}

	for(ucCnt = 0; ucCnt < MAX_THERMISTOR_NUM; ucCnt ++){
		ucChkBit = ((UCHAR)0x01 << ucCnt);

		if((ucTmoniGrpMask & ucChkBit) != 0u){
			if(ulTmoniMaxRfuse < BMIC_Drv.ulRfuse[ucCnt]){
				ulTmoniMaxRfuse = BMIC_Drv.ulRfuse[ucCnt];
			}
		}

	}

	return(ulTmoniMaxRfuse);

#else

	UCHAR ucGrp1MaxCnt;
	UCHAR ucGrp2MaxCnt;
	ULONG ulTmoniMaxRfuse;
	UCHAR i;

	if((usBMICReferRegData(OP_MODE_ADDR)&TMONISEL_MSK) == TMONISEL_MSK){
		ucGrp1MaxCnt = 3u;
		ucGrp2MaxCnt = 2u;
	}else{
		ucGrp1MaxCnt = 4u;
		ucGrp2MaxCnt = 1u;
	}

	if(ucgrp == TMONI_GROUP1){
		ulTmoniMaxRfuse = BMIC_Drv.ulRfuse[0];
		for(i=1; i<ucGrp1MaxCnt; i++){
			if(BMIC_Drv.ulRfuse[i] > ulTmoniMaxRfuse){
				ulTmoniMaxRfuse	= BMIC_Drv.ulRfuse[i];
			}
		}
	}else{
		if(ucGrp2MaxCnt == 1){
			ulTmoniMaxRfuse = BMIC_Drv.ulRfuse[MAX_THERMISTOR_NUM-1];
		}else{
			ulTmoniMaxRfuse = BMIC_Drv.ulRfuse[3];
			if(BMIC_Drv.ulRfuse[MAX_THERMISTOR_NUM-1] > ulTmoniMaxRfuse){
				ulTmoniMaxRfuse = BMIC_Drv.ulRfuse[MAX_THERMISTOR_NUM-1];
			}
		}
	}
	return(ulTmoniMaxRfuse);
#endif
}

/****************************************************************************
FUNCTION	: ulGetTmoniMinRfuse
DESCRIPTION	: Get TMONI group min Rfuse (internal pull-up resistance)
INPUT		: UCHAR ucgrp
OUTPUT		: ULONG	ulTmoniMinRfuse
UPDATE		: 2024/04/08
DATE		: 2023/10/30
*****************************************************************************/
ULONG ulGetTmoniMinRfuse(UCHAR ucgrp)
{
#if(1)
	UCHAR	ucCnt;
	UCHAR 	ucChkBit;
	UCHAR	ucTmoniGrpMask;
	ULONG	ulTmoniMinRfuse = TMONI_RFUSE_MAX;		/* init as max pull-up resistance */

	if((usBMICReferRegData(OP_MODE_ADDR)&TMONISEL_MSK) == TMONISEL_MSK){		/* TMONISEL setting "1"? */
		if(ucgrp == TMONI_GROUP1){
			ucTmoniGrpMask = TMONISEL1_GRP1_MSK & (UCHAR)BMICCellConf.ulTmoniTempPos;
		}else{
			ucTmoniGrpMask = TMONISEL1_GRP2_MSK & (UCHAR)BMICCellConf.ulTmoniTempPos;
		}
	}else{																		/* TMONISEL setting "0" */
		if(ucgrp == TMONI_GROUP1){
			ucTmoniGrpMask = TMONISEL0_GRP1_MSK & (UCHAR)BMICCellConf.ulTmoniTempPos;
		}else{
			ucTmoniGrpMask = TMONISEL0_GRP2_MSK & (UCHAR)BMICCellConf.ulTmoniTempPos;
		}
	}

	for(ucCnt = 0; ucCnt < MAX_THERMISTOR_NUM; ucCnt ++){
		ucChkBit = ((UCHAR)0x01 << ucCnt);

		if((ucTmoniGrpMask & ucChkBit) != 0u){
			if(ulTmoniMinRfuse > BMIC_Drv.ulRfuse[ucCnt]){
				ulTmoniMinRfuse = BMIC_Drv.ulRfuse[ucCnt];
			}
		}
	}

	return(ulTmoniMinRfuse);

#else

	UCHAR ucGrp1MaxCnt;
	UCHAR ucGrp2MaxCnt;
	ULONG ulTmoniMinRfuse;
	UCHAR i;

	if((usBMICReferRegData(OP_MODE_ADDR)&TMONISEL_MSK) == TMONISEL_MSK){
		ucGrp1MaxCnt = 3u;
		ucGrp2MaxCnt = 2u;
	}else{
		ucGrp1MaxCnt = 4u;
		ucGrp2MaxCnt = 1u;
	}

	if(ucgrp == TMONI_GROUP1){
		ulTmoniMinRfuse = BMIC_Drv.ulRfuse[0];
		for(i=1; i<ucGrp1MaxCnt; i++){
			if(BMIC_Drv.ulRfuse[i] < ulTmoniMinRfuse){
				ulTmoniMinRfuse	= BMIC_Drv.ulRfuse[i];
			}
		}
	}else{
		if(ucGrp2MaxCnt == 1){
			ulTmoniMinRfuse = BMIC_Drv.ulRfuse[MAX_THERMISTOR_NUM-1];
		}else{
			ulTmoniMinRfuse = BMIC_Drv.ulRfuse[3];
			if(BMIC_Drv.ulRfuse[MAX_THERMISTOR_NUM-1] < ulTmoniMinRfuse){
				ulTmoniMinRfuse = BMIC_Drv.ulRfuse[MAX_THERMISTOR_NUM-1];
			}
		}
	}
	return(ulTmoniMinRfuse);
#endif
}

/****************************************************************************
FUNCTION	: vBMIC_Wait
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/11/01
*****************************************************************************/
void vBMIC_Wait(USHORT usdata)
{
	/* 500ns * 50MHz / 1(temp) need to check step size = 25 loop */
	volatile USHORT usdummy;
	for (usdummy = 0u; usdummy < usdata; usdummy++){	/* temp */
		;
	}
}

/****************************************************************************
FUNCTION	: bBMIC_ChkSpiMiso
DESCRIPTION	: Get BMIC SDO checking result during BMIC startup
INPUT		: None
OUTPUT		: true - BMIC startup, SDO checking NG, false - BMIC startup, SDO checking OK
UPDATE		:
DATE		: 2020/1/21
*****************************************************************************/
bool bBMIC_ChkSpiMiso(void)
{
	bool ret = false;
	if(BMIC_Drv.bBMIC_NgSpiMiso == true) {
		ret = true;
	}

	return ret;
}

/****************************************************************************
FUNCTION	: vBMIC_Send_PDREG50en
DESCRIPTION	: Enable/disable BMIC PDREG50 output
INPUT		: UCHAR pdreg50en - 1 : PD_REG50_ON, 0 : PD_REG50_OFF
OUTPUT		: None
UPDATE		:
DATE		: 2023/10/19
*****************************************************************************/
void vBMIC_Send_PDREG50en(UCHAR pdreg50en)
{
	USHORT data = PD_REG50_OFF;
	if(pdreg50en == ON) {
		data = PD_REG50_ON;
	}
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	ucBMIC_Send_Req(ADCTL1_ADDR, data, PD_REG50_MASK, BMIC_DATA_INPUT_NEED);
#else
	ucBMIC_Send_Req(OTHCTL_ADDR, data, PD_REG50_MASK, BMIC_DATA_INPUT_NEED);
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */

}


/****************************************************************************
FUNCTION	: wait100us
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		:2020/10/12
*****************************************************************************/
void	wait100us(void)
{
	USHORT usCnt;
	for(usCnt =0; usCnt < (USHORT)800; usCnt++){
		;
	}
}


/****************************************************************************
FUNCTION	: Wait_msec
DESCRIPTION	:
INPUT		: USHORT time_inms
OUTPUT		:
UPDATE		:
DATE		:2020/10/12
*****************************************************************************/
void Wait_msec(USHORT time_inms)
{
	USHORT delay = time_inms * MS_100US;
	USHORT usCnt;
	for(usCnt =0; usCnt < delay; usCnt++){
		wait100us();
	}
}

/****************************************************************************
FUNCTION	: BMIC_SpiRelease
DESCRIPTION	: clear BMIC SPI busy flag
INPUT		:
OUTPUT		:
UPDATE		:
DATE		:2020/10/12
*****************************************************************************/
void BMIC_SpiRelease(void)
{
	BMIC_SpiBusy = 0;
}

/****************************************************************************
FUNCTION	: bBMIC_SpiTake
DESCRIPTION	: Check/wait BMIC SPI free & set BMIC SPI busy flag
INPUT		: USHORT timeout
OUTPUT		: true: BMIC SPI not in use, false: BMIC SPIN in use
UPDATE		:
DATE		:2020/10/12
*****************************************************************************/
bool bBMIC_SpiTake(USHORT timeout)
{
	bool bRet = false;
	USHORT wait_t = 0;

	for(; wait_t < timeout; wait_t++){
		if(!BMIC_SpiBusy){
			BMIC_SpiBusy = 1;
			bRet = true;
			break;
		}
	}
	return bRet;
}

/****************************************************************************
FUNCTION	: vBMIC_Set_GPIO_PortSel
DESCRIPTION	: Set BMIC GPIO port function selection
			  BMIC KA49702 TMONIx/GPIOx shared ports need use Nch Open Drain port
			  M483SGCAE is 3.3V MCU, input pin with external or internal pull-up
INPUT		: ucgpio -BMIC_GPIOx
			  ucport - GPIOx port selection
OUTPUT		:
UPDATE		: 2024/05/09
DATE		: 2023/10/23
*****************************************************************************/
void vBMIC_Set_GPIO_PortSel(UCHAR ucgpio, UCHAR ucport)
{
	UCHAR ucgpioreg;
	USHORT usportsel;

	if(ucgpio <= BMIC_GPIO4){
		ucgpioreg = GPIO_CTL1_ADDR + ucgpio;
		usportsel = ((USHORT)ucport << 8u);

		switch((usportsel & GPIOSEL_MASK)){
			case GPIOSEL_HOSC:
				/* Set the Pins function to High Speed Oscillator */
				ucBMIC_Send_Req(ucgpioreg, GPIOSEL_HOSC, GPIOSEL_MASK, BMIC_DATA_INPUT_NEED);

#if(BMIC_IC_TYPE == BMIC_KA49702A)
				/* Set Clock Divider 40kHz */
				ucBMIC_Send_Req(OSC_CTL_ADDR, OSCH_DIV_MASK, OSCH_DIV_MASK, BMIC_DATA_INPUT_NEED);

				/* Set GPIO*_NOE flag to "0" enable output & set GPIO*_OD to set Nch Open Drain type */
				ucBMIC_Send_Req(ucgpioreg, (~GPIO_NOE)|GPIO_OD, GPIO_NOE|GPIO_OD, BMIC_DATA_INPUT_NEED);

#else
				/* Set Clock Divider 40kHz */
				ucBMIC_Send_Req(GPIO_CTL5_ADDR, OSCH_DIV_MASK, OSCH_DIV_MASK, BMIC_DATA_INPUT_NEED);

				/* Set GPIO*_NOE flag to "0" enable output */
				ucBMIC_Send_Req(ucgpioreg, ~GPIO_NOE, GPIO_NOE, BMIC_DATA_INPUT_NEED);

#endif /* BMIC_KA49702A */

				/* Set GPIO output drivability "1" 4mA */
		/*		ucBMIC_Send_Req(ucgpioreg, GPIO_CHDRV, GPIO_CHDRV, BMIC_DATA_INPUT_NEED); */
				break;

			case GPIOSEL_LOSC:
				/* Set the Pins function to Low Speed Oscillator */
				ucBMIC_Send_Req(ucgpioreg, GPIOSEL_LOSC, GPIOSEL_MASK, BMIC_DATA_INPUT_NEED);

#if(BMIC_IC_TYPE == BMIC_KA49702A)
				/* Set Clock Divider 4kHz */
				ucBMIC_Send_Req(OSC_CTL_ADDR, OSCL_DIV_MASK, OSCL_DIV_MASK, BMIC_DATA_INPUT_NEED);

				/* Set GPIO*_NOE flag to "0" enable output & set GPIO*_OD to set Nch Open Drain type */
				ucBMIC_Send_Req(ucgpioreg, (~GPIO_NOE)|GPIO_OD, GPIO_NOE|GPIO_OD, BMIC_DATA_INPUT_NEED);

#else
				/* Set Clock Divider 4kHz */
				ucBMIC_Send_Req(GPIO_CTL5_ADDR, OSCL_DIV_MASK, OSCL_DIV_MASK, BMIC_DATA_INPUT_NEED);

				/* Set GPIO*_NOE flag to "0" enable output */
				ucBMIC_Send_Req(ucgpioreg, ~GPIO_NOE, GPIO_NOE, BMIC_DATA_INPUT_NEED);

#endif /* BMIC_KA49702A) */

				/* Set GPIO output drivability "1" 4mA */
		/*		ucBMIC_Send_Req(ucgpioreg, GPIO_CHDRV, GPIO_CHDRV, BMIC_DATA_INPUT_NEED); */
				break;

#if(BMIC_IC_TYPE == BMIC_KA49702A)
			case GPIOSEL_GPOH1:
			case GPIOSEL_GPOH2:
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

			case GPIOSEL_ADIRQ1:
			case GPIOSEL_ADIRQ2:

			case GPIOSEL_ACT:
			case GPIOSEL_STB:
			case GPIOSEL_LP:
			case GPIOSEL_FUSEFET:
			case GPIOSEL_ALARM2:
			case GPIOSEL_MCUINTOR:
#if(BMIC_IC_TYPE == BMIC_KA49701A)
			case GPIOSEL_FET_OUTPUT:
#endif	/* BMIC_IC_TYPE == BMIC_KA49701A */
				/* Set the Pins function to selected output */
				ucBMIC_Send_Req(ucgpioreg, (usportsel & GPIOSEL_MASK), GPIOSEL_MASK, BMIC_DATA_INPUT_NEED);

#if(BMIC_IC_TYPE == BMIC_KA49702A)
				/* Set GPIO*_NOE flag to "0" enable output & set GPIO*_OD to set Nch Open Drain type */
				ucBMIC_Send_Req(ucgpioreg, (~GPIO_NOE)|GPIO_OD, GPIO_NOE|GPIO_OD, BMIC_DATA_INPUT_NEED);
#else
				/* Set GPIO*_NOE flag to "0" enable output */
				ucBMIC_Send_Req(ucgpioreg, ~GPIO_NOE, GPIO_NOE, BMIC_DATA_INPUT_NEED);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
				/* Set GPIO output drivability "1" 4mA */
		/*		ucBMIC_Send_Req(ucgpioreg, GPIO_CHDRV, GPIO_CHDRV, BMIC_DATA_INPUT_NEED); */
				break;

			case GPIO_SEL_0E:
				if(ucgpio == BMIC_GPIO1){
#if(1 /* BMIC_IC_TYPE == BMIC_KA49702A */)
					/* GPIO1 - 1110 Not used */
#else
					/* Set the GPIO1 function to FETOFF2 Input */
					ucBMIC_Send_Req(ucgpioreg, GPIOSEL_FETOFF2IN, GPIOSEL_MASK, BMIC_DATA_INPUT_NEED);

					/* Set GPIO1_NOE "1" to disable output and GPIO1_IE "1" to enable input */
					ucBMIC_Send_Req(ucgpioreg, (GPIO_NOE | GPIO_IE), (GPIO_NOE | GPIO_IE), BMIC_DATA_INPUT_NEED);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

				}else{
					/* Set the Pins(GPIO2/3/4) function to CHG fall_Time boost */
					ucBMIC_Send_Req(ucgpioreg, GPIOSEL_CHGOFFBOOST, GPIOSEL_MASK, BMIC_DATA_INPUT_NEED);

#if(BMIC_IC_TYPE == BMIC_KA49702A)
					/* Set GPIO*_NOE flag to "0" enable output & set GPIO*_OD to set Nch Open Drain type */
					ucBMIC_Send_Req(ucgpioreg, (~GPIO_NOE)|GPIO_OD, GPIO_NOE|GPIO_OD, BMIC_DATA_INPUT_NEED);
#else
					/* Set GPIO*_NOE flag to "0" enable output */
					ucBMIC_Send_Req(ucgpioreg, ~GPIO_NOE, GPIO_NOE, BMIC_DATA_INPUT_NEED);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
					/* Set GPIO output drivability "1" 4mA */
			/*		ucBMIC_Send_Req(ucgpioreg, GPIO_CHDRV, GPIO_CHDRV, BMIC_DATA_INPUT_NEED); */
				}
				break;

			case GPIOSEL_GPIO:
			default:
				/* Set the Pins function to GPIO output (default) */
				ucBMIC_Send_Req(ucgpioreg, GPIOSEL_GPIO, GPIOSEL_MASK, BMIC_DATA_INPUT_NEED);

#if(BMIC_IC_TYPE == BMIC_KA49702A)
				/* Set GPIO*_NOE flag to "0" enable output & set GPIO*_OD to set Nch Open Drain type */
				ucBMIC_Send_Req(ucgpioreg, (~GPIO_NOE)|GPIO_OD, GPIO_NOE|GPIO_OD, BMIC_DATA_INPUT_NEED);
#else
				/* Set GPIO*_NOE flag to "0" enable output */
				ucBMIC_Send_Req(ucgpioreg, ~GPIO_NOE, GPIO_NOE, BMIC_DATA_INPUT_NEED);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
				/* Set GPIO output drivability "1" 4mA */
		/*		ucBMIC_Send_Req(ucgpioreg, GPIO_CHDRV, GPIO_CHDRV, BMIC_DATA_INPUT_NEED); */
				break;

#if(BMIC_IC_TYPE == BMIC_KA49702A)
			case GPIO_SEL_TMONI:
				/* Set the Pins function to TMONIx */
				ucBMIC_Send_Req(ucgpioreg, GPIOSEL_TMONI, GPIOSEL_MASK, BMIC_DATA_INPUT_NEED);

				/* GPIOx pin configured as Anglog Input, flag GPIO_IE shall be set to "0" *//* To confirm */
				/* Set GPIO_NOE "1" to disable output and GPIO_IE "0" to disable input */
				ucBMIC_Send_Req(ucgpioreg, (GPIO_NOE&(~GPIO_OD)), (GPIO_NOE | GPIO_IE| GPIO_OD), BMIC_DATA_INPUT_NEED);
				break;
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */


		}

	}

}

#if(BMS_STANDBYMODE_SUPPORT)
/****************************************************************************
#ifdef DOC
FUNCTION		: vBMIC_SetOpeModeExtChk
DESCRIPTION		: Check to set BM-IC operation mode from external request
INPUT			: None
OUTPUT			: None
UPDATE			:
DATE			: 2023/05/19
#endif
*****************************************************************************/
void vBMIC_SetOpeModeExtChk(void){

	UCHAR ucChgOpeMode = ucGet_BMICOpeMode();

	if(BMIC_Drv.ucBMIC_OpeMode_Req == 1u){
		switch(ucChgOpeMode){
			case(BMIC_OPEMODE_ACTIVE):
				if(BMIC_Drv.ucBMIC_Ctrl_Status == BMIC_STANDBY){
					SPI_BMIC_SEN_H();
					Wait_msec(4u);											/* SEN "H" for >3msec to wake up BMIC from Standby mode */

					Wait_msec(2u);											/* wait 2msec for BMIC to return to Active mode */
				}

				if(BMIC_Drv.ucBMIC_Ctrl_Status == BMIC_LOWPOWER){
					vBMIC_Ctrl_Active();
				}

				vBMIC_UpdateCtrlStatus((UCHAR)BMIC_NORMAL);			/* Active mode */
				vBMIC_Set_GPIO_PortSel(BMIC_GPIO3, GPIO3_SEL_INI);	/* return BMIC's GPIO to GPIO INIT */

				break;
			case(BMIC_OPEMODE_STANDBY):
				vBMIC_Ctrl_Standby();
				break;
			case(BMIC_OPEMODE_LOWPOWER):
				vBMIC_Ctrl_LowPower();
#if(0/*BMS_STANDBYMODE_SUPPORT*/)
				usActiveComm_cnt = 0;
#endif /* BMS_STANDBYMODE_SUPPORT */
				break;
			case(BMIC_OPEMODE_SLEEP):
				vBMIC_Ctrl_Sleep();
				break;
			case(BMIC_OPEMODE_SHUTDOWN):
				vBMIC_Ctrl_Shutdown();
				break;
			default:
				break;
		}
		BMIC_Drv.ucBMIC_OpeMode_Req = 0;
	}
}
#endif	/* BMS_STANDBYMODE_SUPPORT */


/****************************************************************************
FUNCTION	: vLogBMIC_ADIL_Data
DESCRIPTION	: Log ADIL data to buffer
INPUT		: USHORT usdata
OUTPUT		: None
UPDATE		: 2023/11/03
DATE		: 2023/10/11
*****************************************************************************/
void vLogBMIC_ADIL_Data(USHORT usdata)
{
	vSetADIL_LogCycle();

	usADIL_Data[usADIL_Log_WrPnt] = usdata;

	if(ucADILLogReadStart){									/* ADIL data continue sending? */
		if(usADIL_Log_WrPnt == usADIL_Log_RdPnt){			/* WrPnt overlap RdPnt, new ADIL data sending */
			ucADIL_LogStatus |= ADIL_DATA_OVERLAP_MASK;			/* b0: 1 (overlap occur) */
		}
	}

	usADIL_Log_WrPnt ++;
	if(usADIL_Log_WrPnt >= MAX_ADIL_LOG_NUM){
		usADIL_Log_WrPnt = 0;
	}
}


/****************************************************************************
FUNCTION	: ucGetBMIC_ADIL_LogData
DESCRIPTION	: Get 2, 8 or 16 ADIL data from buffer
INPUT		: UCHAR *bufadr, UCHAR ucLog
OUTPUT		: UCHAR - number of byte updated
UPDATE		:
DATE		: 2023/10/11
*****************************************************************************/
UCHAR ucGetBMIC_ADIL_LogData(UCHAR *bufadr, UCHAR ucLog)
{
	UCHAR ucCnt;

	UCHAR ucDataNum;
	USHORT usData;

#if(1 /*BMIC_IC_TYPE == BMIC_KA49702A*/)
	switch(ucADIL_LogStatus & ADIL_DATA_FAST_MASK){
		case ADIL_DATA_31_25MS:
			ucDataNum = ADIL_DATA_NUM_31_25MS;							/* fast conversion cycle 31.25ms: 16 per 500ms */
			break;
		case ADIL_DATA_62_5MS:
			ucDataNum = ADIL_DATA_NUM_62_50MS;							/* fast conversion cycle 62.5ms: 8 per 500ms */
			break;
		default:
			ucDataNum = ADIL_DATA_NUM_250MS;							/* slow conversion cycle: 250ms: 2 per 500ms */
			break;
	}
#else
	if((ucADIL_LogStatus & ADIL_DATA_FAST_MASK) == ADIL_DATA_FAST_MASK){
		ucDataNum = ADIL_FAST_CYCLE_500MS;							/* fast conversion cycle 31.25ms: 16 per 500ms */
	}else{
		ucDataNum = ADIL_SLOW_CYCLE_500ms;							/* slow conversion cycle: 250ms: 2 per 500ms */
	}
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	if(ucLog){
		if((ucADILLogReadStart == 0)								/* New log read? */
		|| ((ucADIL_LogStatus & ADIL_DATA_OVERLAP_MASK) == ADIL_DATA_OVERLAP_MASK)	/* ADIL data overlap occurred? */
		){
			/* New start of ADIL data from data buffer? RdPnt based on latest WrPnt */
			if(usADIL_Log_WrPnt >= (ucDataNum << 1)){
				usADIL_Log_RdPnt = usADIL_Log_WrPnt - (ucDataNum << 1);
			}else{
				usADIL_Log_RdPnt = usADIL_Log_WrPnt + MAX_ADIL_LOG_NUM - (ucDataNum << 1);
			}

			ucADIL_LogStatus &= ~ADIL_DATA_OVERLAP_MASK;			/* b0: 0 - ADIL data continue */
			ucADILLogReadStart = 1;
		}
	}else{
		ucADILLogReadStart = 0;
		ucADIL_LogStatus &= ~ADIL_DATA_OVERLAP_MASK;			/* b0: 0 - ADIL data continue */
	}

	/* copy ADIL data from data buffer to send buffer */
	for(ucCnt=0; ucCnt<(ADIL_FAST_CYCLE_500MS * 2); ){
		if((ucLog)
		&& ((ucCnt/2) < ucDataNum)
		){
			usData = usADIL_Data[usADIL_Log_RdPnt];					/* Get ADIL data from log buffer */

			usADIL_Log_RdPnt ++;
			if(usADIL_Log_RdPnt >= MAX_ADIL_LOG_NUM){				/* RdPnt limit check */
				usADIL_Log_RdPnt = 0;
			}

		}else{
			/* not request ADIL log data or beyond valid data - fill up 0000 */
			usData = 0x0000u;
		}

		*(bufadr+ucCnt) = (UCHAR)((USHORT)usData& (USHORT)0x00FF);
		ucCnt ++;
		*(bufadr+ucCnt) = (UCHAR)(((USHORT)usData >> 8)& (USHORT)0x00FF);
		ucCnt ++;
	}

	return(ucCnt);
}


/****************************************************************************
FUNCTION	: ucGetADIL_LogDataStatus
DESCRIPTION	: Get current ADC log data status
INPUT		: None
OUTPUT		: UCHAR
UPDATE		:
DATE		: 2023/10/13
*****************************************************************************/
UCHAR ucGetADIL_DataLogStatus(void)
{
	return(ucADIL_LogStatus);

}

/****************************************************************************
FUNCTION	: vSetADIL_LogCycle
DESCRIPTION	: Set current ADC log cycle status & reset log buffer WrPnt & RdPnt.
INPUT		: None
OUTPUT		: None
UPDATE		: 2023/11/03
DATE		: 2023/10/13
*****************************************************************************/
void vSetADIL_LogCycle(void)
{
	UCHAR ucNew = 0u;
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	switch((UCHAR)((usBMICReferRegData(ADCTL2_ADDR) & ADILSEL_MASK) >> 13u)){
#else
	switch((UCHAR)((usBMICReferRegData(ADCTL_ADDR) & ADILSEL_MASK) >> 13u)){
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
        case 0x00u:					/* b00: 250ms */
			ucNew = ADIL_DATA_250MS;
			break;
		case 0x02u:					/* b10: 62.5ms */
			ucNew = ADIL_DATA_62_5MS;
			break;
		default:					/* bX1: 31.25ms */
			ucNew = ADIL_DATA_31_25MS;
			break;
	}
	if((ucADIL_LogStatus & ADIL_DATA_FAST_MASK) != (ucNew & ADIL_DATA_FAST_MASK)){
		ucADIL_LogStatus = 	ucNew & ADIL_DATA_FAST_MASK;			/* b1: current ADC cycle flag, b0: 0 (continue) */

		ucADILLogReadStart = 0;
	}

}

