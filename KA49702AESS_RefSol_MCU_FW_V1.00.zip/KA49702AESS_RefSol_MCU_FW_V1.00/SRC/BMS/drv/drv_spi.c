/****************************************************************************
#ifdef DOC
File Name		:drv_spi.c
Description		:
Remark			:
Date			:2020/10/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/
#include "NuMicro.h"
#include <stdbool.h>
#include "sys_type.h"
#include "drv_spi.h"
#include "main.h"


/****************************************************************************
 define macro
*****************************************************************************/

/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/

/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/

/****************************************************************************
 Variable declaration
*****************************************************************************/


/****************************************************************************
 Prototype declaration
*****************************************************************************/

/****************************************************************************
 define data table
*****************************************************************************/

/****************************************************************************
FUNCTION	: vSPI_Init
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/04/28
*****************************************************************************/
void vSPI_Init(void)
{
#if(ESS_DEMO_EVB)
	/* ++SPI2 Init start++ */
	/* Select SPI2 clock source from PCLK0 */
	CLK_SetModuleClock(SPI2_MODULE, CLK_CLKSEL2_SPI2SEL_PCLK1, MODULE_NoMsk);
	/* Enable SPI2 clock */
	CLK_EnableModuleClock(SPI2_MODULE);
	
	/* Configure SPI2 */
	/* Configure SPI2 as a master, clock 1MHz, 8-bit transaction, drive output on rising clock edge and latch input on falling edge. */
	/* Configure SPI2 SPI_MODE_1: CLKPOL 0, RXNEG 1, TXNEG 0 */
	SPI_Open(SPI2, SPI_MASTER, SPI_MODE_1, 8u, 1000000u);
	/* ++SPI2 Init end++ */
#else
	/* ++SPI1 Init start++ */
	/* Select SPI1 clock source from PCLK0 */
	CLK_SetModuleClock(SPI1_MODULE, CLK_CLKSEL2_SPI1SEL_PCLK0, MODULE_NoMsk);
	/* Enable SPI1 clock */
	CLK_EnableModuleClock(SPI1_MODULE);

	/* Configure SPI1 */
	/* Configure SPI1 as a master, clock 1MHz, 8-bit transaction, drive output on rising clock edge and latch input on falling edge. */
	/* Configure SPI1 SPI_MODE_1: CLKPOL 0, RXNEG 1, TXNEG 0 */
	SPI_Open(SPI1, SPI_MASTER, SPI_MODE_1, 8u, 1000000u);
	/* ++SPI1 Init end++ */
#endif /* ESS_DEMO_EVB */	
}

/****************************************************************************
FUNCTION	: bSPI_BMIC_Rx
DESCRIPTION	: BMIC SPI Receive
INPUT		: UCHAR *txBuf, UCHAR *rxBuf, UCHAR sendSize
OUTPUT		: bool
UPDATE		:
DATE		: 2020/10/12
*****************************************************************************/
bool bSPI_BMIC_Rx(UCHAR *txBuf, UCHAR *rxBuf, UCHAR sendSize)
{
	bool ret = false;
	UCHAR cnt=0u;

#if(ESS_DEMO_EVB)
	SPI_ClearRxFIFO(SPI2);									/* Clear Rx FIFO before Rx start	*/

	for(cnt=0u;cnt < sendSize; cnt++){

		SPI_WRITE_TX(SPI2, (*(txBuf+cnt) & (ULONG)0x000000FF));
		while(SPI_IS_BUSY(SPI2)){
			;
		}
		*(rxBuf+cnt) = (UCHAR)SPI_READ_RX(SPI2);

	}
#else
	SPI_ClearRxFIFO(SPI1);									/* Clear Rx FIFO before Rx start	*/

	for(cnt=0u;cnt < sendSize; cnt++){

		SPI_WRITE_TX(SPI1, (*(txBuf+cnt) & (ULONG)0x000000FF));
		while(SPI_IS_BUSY(SPI1)){
			;
		}
		*(rxBuf+cnt) = (UCHAR)SPI_READ_RX(SPI1);

	}
#endif /* ESS_DEMO_EVB */
	ret = true;

	return ret;
}


/****************************************************************************
FUNCTION	: bSPI_BMIC_Tx
DESCRIPTION	: BMIC SPI transmission
INPUT		: UCHAR *txBuf, UCHAR sendSize
OUTPUT		: bool
UPDATE		:
DATE		: 2020/10/12
*****************************************************************************/
bool bSPI_BMIC_Tx(UCHAR *txBuf, UCHAR sendSize)
{
	bool ret = false;
	UCHAR cnt = 0u;

	for(cnt=0u; cnt < sendSize; cnt++){

#if(ESS_DEMO_EVB)
		SPI_WRITE_TX(SPI2, (*(txBuf+cnt) & (ULONG)0x000000FF));
		while(SPI_IS_BUSY(SPI2)){
			;
		}
#else
		SPI_WRITE_TX(SPI1, (*(txBuf+cnt) & (ULONG)0x000000FF));
		while(SPI_IS_BUSY(SPI1)){
			;
		}
#endif /* ESS_DEMO_EVB */
	}

	ret = true;

	return ret;
}

