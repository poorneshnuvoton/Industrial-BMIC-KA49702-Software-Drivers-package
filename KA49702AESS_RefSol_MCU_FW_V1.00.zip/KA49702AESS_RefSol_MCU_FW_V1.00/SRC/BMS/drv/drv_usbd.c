/****************************************************************************
#ifdef DOC
File Name		:drv_usbd.c
Description		:
Remark			:
Date			:2025/01/21
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/
#include "NuMicro.h"
#include <stdbool.h>
#include "sys_type.h"
#include "main.h"
#include "vcom_serial.h"
#include "tsk_gui_if.h"

#if(PCGUI_IF_USB)
/****************************************************************************
 define macro
*****************************************************************************/
#define RXBUFSIZE         		(512u) 			/* RX buffer size */
#define TXBUFSIZE         		(512u) 			/* RX buffer size */



/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/

/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/

/****************************************************************************
 Variable declaration
*****************************************************************************/
volatile uint8_t comRbuf[RXBUFSIZE];
volatile uint16_t comRbytes = 0;
volatile uint16_t comRhead = 0;
volatile uint16_t comRtail = 0;

volatile uint8_t comTbuf[TXBUFSIZE];
volatile uint16_t comTbytes = 0;
volatile uint16_t comThead = 0;
volatile uint16_t comTtail = 0;

uint8_t gRxBuf[64] = {0};
uint8_t *gpu8RxBuf = 0;
uint32_t gu32RxSize = 0;
uint32_t gu32TxSize = 0;

uint32_t u32TrimInit;

/****************************************************************************
 Prototype declaration
*****************************************************************************/

/****************************************************************************
 define data table
*****************************************************************************/

/****************************************************************************
FUNCTION	: vUSBD_Init
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2025/01/21
*****************************************************************************/
void vUSBD_Init(void)
{
	USBD_Open(&gsInfo, VCOM_ClassRequest, NULL);

	/* Endpoint configuration */
	VCOM_Init();
	USBD_Start();

	if (((SYS->CSERVER & SYS_CSERVER_VERSION_Msk) == 0x1) && (CRYSTAL_LESS))
	{
		/* Start USB trim */
		USBD->INTSTS = USBD_INTSTS_SOFIF_Msk;
		while((USBD->INTSTS & USBD_INTSTS_SOFIF_Msk) == 0);
		SYS->HIRCTCTL = 0x1;
		SYS->HIRCTCTL |= SYS_HIRCTCTL_REFCKSEL_Msk;
		/* Backup default trim */
		u32TrimInit = M32(TRIM_INIT);
	}
}



/****************************************************************************
FUNCTION	: vUSBD_main
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2025/01/21
*****************************************************************************/
void vUSBD_main(void)
{
	if (((SYS->CSERVER & SYS_CSERVER_VERSION_Msk) == 0x1) && (CRYSTAL_LESS))
	{
		/* Start USB trim if it is not enabled. */
		if ((SYS->HIRCTCTL & SYS_HIRCTCTL_FREQSEL_Msk) != 1)
		{
			if(USBD->INTSTS & USBD_INTSTS_SOFIF_Msk)
			{
				/* Clear SOF */
				USBD->INTSTS = USBD_INTSTS_SOFIF_Msk;

				/* Re-enable crystal-less */
				SYS->HIRCTCTL = 0x1;
				SYS->HIRCTCTL |= SYS_HIRCTCTL_REFCKSEL_Msk;
			}
		}

		/* Disable USB Trim when error */
		if (SYS->HIRCTISTS & (SYS_HIRCTISTS_CLKERRIF_Msk | SYS_HIRCTISTS_TFAILIF_Msk))
		{
			/* Init TRIM */
			M32(TRIM_INIT) = u32TrimInit;

			/* Disable crystal-less */
			SYS->HIRCTCTL = 0;

			/* Clear error flags */
			SYS->HIRCTISTS = SYS_HIRCTISTS_CLKERRIF_Msk | SYS_HIRCTISTS_TFAILIF_Msk;

			/* Clear SOF */
			USBD->INTSTS = USBD_INTSTS_SOFIF_Msk;
		}
	}

	VCOM_TransferData();

}

/****************************************************************************
FUNCTION	: VCOM_TransferData
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		:
*****************************************************************************/
void VCOM_TransferData(void)
{
	int32_t i, i32Len;

	/* Check whether USB is ready for next packet or not*/
	if(gu32TxSize == 0)
	{
		/* Check whether we have new COM Rx data to send to USB or not */
		if(comRbytes)
		{
			i32Len = comRbytes;
			if(i32Len > EP2_MAX_PKT_SIZE){
				i32Len = EP2_MAX_PKT_SIZE;
			}

			for(i = 0; i < i32Len; i++)
			{
				gRxBuf[i] = comRbuf[comRhead++];
				if(comRhead >= RXBUFSIZE)
					comRhead = 0;
			}

			__set_PRIMASK(1);
			comRbytes -= i32Len;
			__set_PRIMASK(0);

			gu32TxSize = i32Len;
			USBD_MemCopy((uint8_t *)(USBD_BUF_BASE + USBD_GET_EP_BUF_ADDR(EP2)), (uint8_t *)gRxBuf, i32Len);
			USBD_SET_PAYLOAD_LEN(EP2, i32Len);
		}
		else
		{
			/* Prepare a zero packet if previous packet size is EP2_MAX_PKT_SIZE and
				no more data to send at this moment to note Host the transfer has been done */
			i32Len = USBD_GET_PAYLOAD_LEN(EP2);
			if(i32Len == EP2_MAX_PKT_SIZE){
				USBD_SET_PAYLOAD_LEN(EP2, 0);
			}
			vClearTxData();
        }
    }

	/* Process the Bulk out data when bulk out data is ready. */
	if(gi8BulkOutReady && (gu32RxSize <= TXBUFSIZE - comTbytes))
	{
		for(i = 0; i < gu32RxSize; i++)
		{
			comTbuf[comTtail++] = gpu8RxBuf[i];
			if(comTtail >= TXBUFSIZE){
				comTtail = 0;
			}
		}

		__set_PRIMASK(1);
		comTbytes += gu32RxSize;
		__set_PRIMASK(0);

		gu32RxSize = 0;
		gi8BulkOutReady = 0; /* Clear bulk out ready flag */

		/* Ready to get next BULK out */
		USBD_SET_PAYLOAD_LEN(EP3, EP3_MAX_PKT_SIZE);
    }

	/* Process the software Tx FIFO */
	if(comTbytes)
	{
#if(0)
        /* Check if Tx is working */
        if((UART0->INTEN & UART_INTEN_THREIEN_Msk) == 0)
        {
            /* Send one bytes out */
            UART_WRITE(UART0, comTbuf[comThead++]);
            if(comThead >= TXBUFSIZE){
                comThead = 0;
			}
            comTbytes--;

            /* Enable Tx Empty Interrupt. (Trigger first one) */
            UART0->INTEN |= UART_INTEN_THREIEN_Msk;
        }
#endif

		for(i=0; i<comTbytes; i++){
			vUartCmdRx(comTbuf[comThead++]);
			if(comThead >= TXBUFSIZE){
				comThead = 0;
			}
		}
		comTbytes = 0;
    }

}

/****************************************************************************
FUNCTION	: VCOM_USBDTransferOutData
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		:
*****************************************************************************/
void VCOM_USBDTransferOutData(UCHAR data)
{

	/* Check if buffer full */
	if(comRbytes < RXBUFSIZE)
	{
		/* Enqueue the send data */
		comRbuf[comRtail++] = data;
		if(comRtail >= RXBUFSIZE){
		    comRtail = 0;
		}
		comRbytes++;
	}
	else
	{
		/* FIFO over run */
	}

}
#endif	/* PCGUI_IF_USB */
