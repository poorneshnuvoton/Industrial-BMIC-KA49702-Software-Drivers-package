/****************************************************************************
#ifdef DOC
File Name		:tsk_sys.c
Description		:
Remark			:
Date			:2020/10/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/
#include "NuMicro.h"
#include <stdbool.h>
#include "sys_type.h"
#include "main.h"
#include "drv_bmic.h"
#include "drv_timer.h"
#include "tsk_bmic.h"
#include "portio.h"
#include "tsk_diagn.h"
#if(BMIC_IC_TYPE == BMIC_KA49702A)
#include "bmic_reg_702.h"
#else
#include "bmic_reg_701.h"
#endif /* BMIC_KA49702A */

#if(BMS_DIAGNOSTIC_SUPPORT)
/****************************************************************************
 define macro
*****************************************************************************/
/*#define BMS_DIAGN_MAX 		(7u)*/
#define BEFORE_DSCN			(0u)
#define AFTER_DSCN			(1u)
#define DIAGN_CVIL_MIN		(0x4001u)			/* Current diagnostic check min value = (90mV/360mV * 2^16) + 1 = 16385 */
#define DIAGN_CVIL_MAX		(0x4E39u)			/* Current diagnostic check max value = (110mV/360mV * 2^16) + 1 = 20025 */
#define DIAGN_CMPL_CYCLE	(4u)				/* Completion cycle */
#define	DIAGN_CMPL_CYCLE_OSC	(6u)			/* OSC H/L Diagnostic Completion cycle */

#define DIAG_DSCN_JGVAL1	(100000)			/* Open detection Judgement value of 100mV (in uV) */
#define DIAG_DSCN_CELLMASK	(0x0003FFFFu)		/* Disconnection detection cell position mask C0~C17 */
#define DIAG_DSCN_ODDMASK	(0x0002AAABu)		/* Disconnection detection odd cell number position mask C0~C17, eg. c0,c1,c3,c5, .. ~c17 */
#define DIAG_DSCN_EVENMASK	(0x00015554u)		/* Disconnection detection even cell number position mask C0~C17 eg. c2,c4,c6, .. ~c16 */

#define COMP_MAX(val, max)		do {\
									if((val)>(max)){\
										(max) = (val);\
									}\
								}while(0)
#define COMP_MIN(val, min)		do {\
									if((min)>(val)){\
										(min) = (val);\
									}\
								}while(0)

#if(DIAGNOSTIC_SRPSRN)
#define	SRPSRN_NUM			(2u)
#endif	/* DIAGNOSTIC_SRPSRN */
/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/
typedef struct {
	LONG	lCurADC_LS_uV;									/* Current (CVIL) in uV */
	ULONG	ulCV_DSCNBef_uV[MAX_CELL_NUM];					/* Cell voltage in uV (data before CB perform to check DSCN)	*/
	ULONG	ulCV_DSCNAft_EvenCB_uV[MAX_CELL_NUM];			/* Cell voltage in uV (data after even CB perform to check DSCN)	*/
	ULONG	ulCV_DSCNAft_OddCB_uV[MAX_CELL_NUM];			/* Cell voltage in uV (data after odd CB perform to check DSCN)	*/
	LONG	lCV_DSCNCmpResult_EvenCB_uV[MAX_CELL_NUM + 1];	/* Cell voltage in uV (comparison data of before and after even CB */
	LONG	lCV_DSCNCmpResult_OddCB_uV[MAX_CELL_NUM + 1];	/* Cell voltage in uV (comparison data of before and after odd CB  */
	ULONG	ulDSCN_results_sts;								/* bit0~bit17 represent C0~C17 judgment results status. "0" - Opened, "1" - normal. */
	USHORT	usOSCH_pulseCnt;								/* count per 100ms (40kHz +/- 2.5%) */
	USHORT	usOSCL_pulseCnt;								/* count per 100ms (4.096kH +/- 2.5%)*/
	USHORT	usRegulator;									/* Regulator bit0: VDD50 UV det flg(<4.7V), bit1: VDD50 digital OV flg(>5.3V), bit2: VDD50 analog OV flg(>5.75V),
																bit3: REGEXT UV flg(<4.7V/3V), bit4: REGEXT digital OV flg(>5.3V/3.6V), bit5: REGEXT analog UV flg (<2.65V)
																bit6: VDD15 UV det flg(<1.435V), bit7:VDD15 OV det flg(>1.565V), bit8 VDD15 OV det flg(>1.85V) bit 9~15:Unused --> flag "1" detected, "0" not detected*/
	USHORT	usVref;											/* Vref2 bit0: VREF2 UV det flag(<0.48V), bit1: VREF OV det flag(>0.96V), bit 2~15: Unused --> flag "1" detected, "0" not detected*/
	USHORT	usMeasSeq;										/* Measurement sequence check results, 0x0000: Normal, 0x0001: Abnormal*/
#if(DIAGNOSTIC_SRPSRN)
	LONG	lSRPSRN_DiagCurADC_uV[SRPSRN_NUM];				/* Current(IADC) Reading in uV for SRP/SRN open & short diagnostic check */
#endif	/* DIAGNOSTIC_SRPSRN */
}stDIAG_Info;
/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/
typedef enum{
	DSCN_NONE = 0,
	DSCN_ODD_CB,
	DSCN_EVEN_CB,
	DSCN_END
}eDIAGN_DSCN_STATE;

#if(DIAGNOSTIC_SRPSRN)
typedef	enum{
	DIAGN_SRPSRN_NONE = 0,
	DIAGN_SRN_START,
	DIAGN_SRN_CHECK,
	DIAGN_SRP_START,
	DIAGN_SRP_CHECK,
	DIAGN_SRPSRN_END
}eDIAGN_SRPSRN_STATE;
#endif	/* DIAGNOSTIC_SRPSRN */
/****************************************************************************
 Variable declaration
*****************************************************************************/
static ULONG ulBms_diagn_reqdetail = DIAGN_INVALID;
static ULONG ulBms_diagn_results = DIAGN_INVALID;

UCHAR ucdiag_ret_result_flg = 0u;
static UCHAR ucdiag_curADC_flg = 0u;
static UCHAR ucdiag_dscn_err_flg = 0u;
/*static UCHAR ucdiag_dscn_flg = 0u;*/

SHORT sCurADC_buff[DIAGN_CMPL_CYCLE];
static UCHAR ucCVIL_cnt = 0u;
static USHORT usdiag_pwrctrl;
#if(BMIC_IC_TYPE == BMIC_KA49702A)
static USHORT usdiag_adctl2;
#else
static USHORT usdiag_adctl;
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */
static USHORT usdiag_alarmctl1;
static USHORT usdiag_cbsel17;

static ULONG ulCVAD_DSCNBef_buff[MAX_CELL_NUM];
static ULONG ulCVAD_DSCNAft_buff[MAX_CELL_NUM];

static USHORT usOSC_pulseCnt_buff[DIAGN_CMPL_CYCLE_OSC];
static USHORT usOSC_pulseCnt_min;
static USHORT usOSC_pulseCnt_max;
static ULONG ulOSC_CurrentCnt = 0u;
static ULONG ulOSC_LastCnt = 0u;
static UCHAR ucOSC_cnt= 0u;
static UCHAR ucOSC_100ms_flg = 0u;

static UCHAR ucDSCN_cnt= 0u;
static ULONG uldscn_Oddcell_req = 0u;
static ULONG uldscn_Evencell_req = 0u;

eBMS_DIAGN_REQ eBMS_Diagn_Req = eBMS_DIAGN_NO_REQ;		/* Diagnostic function request */
eBMS_DIAGN_STS eBMS_Diagn_Sts = eBMS_DIAGN_NONE;		/* Diagnostic function request status */
stDIAG_Info stDiag_info;

eDIAGN_DSCN_STATE eDiagn_dscn_state = DSCN_NONE;

#if(DIAGNOSTIC_SRPSRN)
eDIAGN_SRPSRN_STATE eDiagn_SRPSRN_state = DIAGN_SRPSRN_NONE;
#endif	/* DIAGNOSTIC_SRPSRN */
/****************************************************************************
 Prototype declaration
*****************************************************************************/
static bool bDiag_Check_CurADC(void);
static void vDiag_Read_CurADC(SHORT *sadr);
static void vDiag_Start_CurADC_chk(void);
static void vDiag_End_CurADC_chk(void);
static void vDiag_Read_Regulator(void);
static void vDiag_Read_VREF2(void);
static void vDiag_Read_MUX(void);
static void vDiag_Start_OSC(void);
static void vDiag_CalcCVReadSum(UCHAR stage);
static void vDiag_Start_ADC(void);
static void vDiag_Start_DSCN_chk(void);
static void vDiag_DSCN_data_comp(ULONG target);
static void vDiag_DSCN_CBctrl(UCHAR ctrl,USHORT data1, USHORT data2);
static void vDiag_DSCN_judgement(ULONG target);
void vDiag_DSCN_state(void);
#if(DIAGNOSTIC_SRPSRN)
void vDiag_SRPSRN_start(void);
void vDiag_SRPSPN_ctrl(void);
#endif	/* DIAGNOSTIC_SRPSRN */
/****************************************************************************
 define data table
*****************************************************************************/


/****************************************************************************
FUNCTION	: bSetDiag_req
DESCRIPTION	: Set safety diagnostic request selection
INPUT		: UCHAR ucReq: 	0x00: Reserved
							0x01: eBMS_DIAGN_CUR_ADC
							0x02: eBMS_DIAGN_REGULATOR
							0x03: eBMS_DIAGN_VREF2
							0x04: eBMS_DIAGN_MEASUREMENT_SEQ
							0x05: eBMS_DIAGN_OSC_CLOCK
							0x06: eBMS_DIAGN_OPEN_DETECTION
							0x07: eBMS_DIAGN_SRPSRN_OPENSHORT
							0xFF: eBMS_DIAGN_NO_REQ
			: USHORT ulDetail: 	0x00000001: REQ_HS_CUR_ADC	(Not support)
								0x00000002: REQ_LS_CUR_ADC

								0x00000000: REQ_DIAGN_OSCH
								0x00000001: REQ_DIAGN_OSCL
OUTPUT		: bool
UPDATE		:
DATE		: 2022/06/08
*****************************************************************************/
bool bSetDiag_req(UCHAR ucReq, ULONG ulDetail)
{
	bool bRet = true;

	if(ucReq >= /*BMS_DIAGN_MAX*/eBMS_DIAGN_MAX){
		eBMS_Diagn_Req = eBMS_DIAGN_NO_REQ;
		ulBms_diagn_reqdetail = ulDetail;
		bRet = false;
	}else{
		eBMS_Diagn_Req = (eBMS_DIAGN_REQ)ucReq;
		switch(eBMS_Diagn_Req){
			case (eBMS_DIAGN_CUR_ADC):
/*				if((ulDetail < REQ_HS_CUR_ADC)||(ulDetail > REQ_LS_CUR_ADC)){	*/
				if(ulDetail != REQ_LS_CUR_ADC){
					ulBms_diagn_reqdetail = DIAGN_INVALID;
					bRet = false;
				}else{
					ulBms_diagn_reqdetail = ulDetail;
				}
			break;
			case (eBMS_DIAGN_REGULATOR):
			case (eBMS_DIAGN_VREF2):
			case (eBMS_DIAGN_MEASUREMENT_SEQ):
				if(ulDetail != 0x00000000u){
					ulBms_diagn_reqdetail = DIAGN_INVALID;
					bRet = false;
				}else{
					ulBms_diagn_reqdetail = ulDetail;
				}
				break;
			case (eBMS_DIAGN_OSC_CLOCK):
				if(ulDetail > REQ_DIAGN_OSCL){
					ulBms_diagn_reqdetail = DIAGN_INVALID;
					bRet = false;
				}else{
					ulBms_diagn_reqdetail = ulDetail;
				}
				break;
			case (eBMS_DIAGN_OPEN_DETECTION):
				/* Multiple open disconnection detection selection */
				if(ulDetail == 0u){
					ulBms_diagn_reqdetail = DIAGN_INVALID;
					bRet = false;
				}else
				if(ulDetail <= DIAG_DSCN_CELLMASK){
					ulBms_diagn_reqdetail = ulDetail;
				}else{
					ulBms_diagn_reqdetail = DIAGN_INVALID;
					bRet = false;
				}
				break;
#if(DIAGNOSTIC_SRPSRN)
			case (eBMS_DIAGN_SRPSRN_OPENSHORT):
				ulBms_diagn_reqdetail = ulDetail;
				break;
#endif	/* DIAGNOSTIC_SRPSRN */
			default:
				eBMS_Diagn_Req = eBMS_DIAGN_NO_REQ;
				bRet = false;
				break;
		}
	}

	if(bRet){										/* diagnostic request is valid? */
		vBMIC_Diagnostic_Req(1u);					/* Set BMS Control status to BMS_DIAGNOSTIC */
	}

	return(bRet);
}

/****************************************************************************
FUNCTION	: vSetDiag_sts
DESCRIPTION	: set diagnostic status
INPUT		: 0x00 (none), 0x01 (start), 0x02 (in progress), 0x03 (complete), 0xFF (Error)
OUTPUT		: none
UPDATE		:
DATE		: 2022/06/13
*****************************************************************************/
void vSetDiag_sts(UCHAR status){
	eBMS_Diagn_Sts = (eBMS_DIAGN_STS)status;
}

/****************************************************************************
FUNCTION	: ucGetDiag_sts
DESCRIPTION	: Get diagnostic status
INPUT		: none
OUTPUT		: none
RETURN		: 0x00 (none), 0x01 (start), 0x02 (in progress), 0x03 (complete), 0xFF (Error)
UPDATE		:
DATE		: 2022/06/13
*****************************************************************************/
UCHAR ucGetDiag_sts(void){
	return((UCHAR)eBMS_Diagn_Sts);
}

/****************************************************************************
FUNCTION	: ucGetDiag_req
DESCRIPTION	: get diagnostic request
INPUT		: none
OUTPUT		: none
RETURN		: 0x00(CHG DIS NMOS FET), 0x01(Current ADC), 0x02(Regular), 0x03(VREF2),
			: 0x04(Measurement Sequence), 0x05(Internal osc clk),
			: 0x06(Open connection detection), 0x07(SRP/SRN open & short detect), 0xFF (No request)
UPDATE		:
DATE		: 2022/06/13
*****************************************************************************/
UCHAR ucGetDiag_req(void){
	return((UCHAR)eBMS_Diagn_Req);
}

/****************************************************************************
FUNCTION	: ulGetDiag_result
DESCRIPTION	: Get diagnostic results
INPUT		: none
OUTPUT		: Current ADC -
			  ulBms_diagn_results :  0xXXXX0000 (NG), 0xXXXX0001(OK) (XXXX - Current ADC diagnostic raw data)

			  Internal Regulator - ulBms_diagn_results:
			  VDD15 Analog OV (>1.85V) flag
			  bit8: 1: detected, 0: not detected
			  VDD15 Digital OV (>1.565V) flag
			  bit7: 1: detected, 0: not detected
			  VDD15 Digital UV (<1.435V) flag
			  bit6: 1: detected, 0: not detected
			  REG_EXT Analog UV (<2.65V) flag
			  bit5: 1: detected, 0: not detected
			  REG_EXT Digital OV (>5.3V/3.6V) flag
			  bit4: 1: detected, 0: not detected
			  REG_EXT Digital UV (<4.7V/3V) flag
			  bit3: 1: detected, 0: not detected
			  VDD50 Analog OV (>5.75V) flag
			  bit2: 1: detected, 0: not detected
			  VDD50 Digital OV (>5.3V) flag
			  bit1: 1: detected, 0: not detected
			  VDD50 Digital UV (<4.7V) flag
			  bit0: 1: detected, 0: not detected
			  bit9 ~ bit31: (Reserved)

			  VREF - ulBms_diagn_results:
			  VREF2 OV (>0.96V) flag
			  bit1: 1: detected, 0: not detected
			  VREF2 UV (<0.48V) flag
			  bit0: 1: detected, 0: not detected
			  bit2~bit31: (unused) set to �0�

			  Measurement sequence -
			  ulBms_diagn_results :  0x00000000 (Normal), 0x00000001(Abnormal)

			  Internal osc clk -
			  ulBms_diagn_results : 0xXXXXXXXX (OSCH), 0xXXXXXXXX (OSCL)

			  Open connection detection -
			  ulBms_diagn_results : 0x0003FFFF (normal)
			  b0~b17 represents C0 ~ C17 respectively. (1: Normal, 0: Opened)

			  SRP/SRN Open & Short detection -
			  b0~b15 : SRN Open & Short detection IADC reading
			  b16~b31: SRP Open & Short detection IADC reading

			  In case of Error/Failed/Invalid -
			  ulBms_diagn_results: 0xFFFFFFFF
UPDATE		: 2023/11/08
DATE		: 2022/06/13
*****************************************************************************/
ULONG ulGetDiag_result(void){
	ucdiag_ret_result_flg = 1u;

	return(ulBms_diagn_results);
}

/****************************************************************************
FUNCTION	: bValidateDiag_req
DESCRIPTION	:
INPUT		: UCHAR
OUTPUT		: bool
UPDATE		:
DATE		: 2022/06/08
*****************************************************************************/
bool bValidateDiag_req(UCHAR ucReq, ULONG ulDetail){

	bool bRet = true;

	if(eBMS_Diagn_Req != ucReq){
		bRet = false;
	}

	if(ulBms_diagn_reqdetail != ulDetail){
		bRet = false;
	}

	return (bRet);

}

/****************************************************************************
FUNCTION	: vTskInit_Diag
DESCRIPTION	: Init setting for Safety Diagnostic function checking
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		: 2022/06/13
*****************************************************************************/
void vTskInit_Diag(void){

	UCHAR i;
	ulBms_diagn_results = DIAGN_INVALID;	/* clear previous diagnostic result */

	ucdiag_curADC_flg = 0u;
	ucdiag_ret_result_flg = 0u;

	ucCVIL_cnt = 0u;

	for(i=0u; i<DIAGN_CMPL_CYCLE; i++){
		sCurADC_buff[i] = 0x00u;
	}

	for(i=0u; i < DIAGN_CMPL_CYCLE_OSC; i++){
		usOSC_pulseCnt_buff[i] =0x00u;
	}
	usOSC_pulseCnt_min = 0xFFFFu;
	usOSC_pulseCnt_max = 0u;

	ulOSC_CurrentCnt = 0u;
	ulOSC_LastCnt = 0u;
	ucOSC_cnt= 0u;
	ucOSC_100ms_flg = 0u;

	for(i=0u; i<MAX_CELL_NUM; i++){
		ulCVAD_DSCNBef_buff[i] = 0x00000000u;
		ulCVAD_DSCNAft_buff[i] = 0x00000000u;
	}
/*	ucdiag_dscn_flg = 0u;*/
	ucdiag_dscn_err_flg = 0u;
	uldscn_Oddcell_req = 0u;
    uldscn_Evencell_req = 0u;
}

/****************************************************************************
FUNCTION	: vTskSet_Diag
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/06/27
*****************************************************************************/
void vTskSet_Diag(eBMS_DIAGN_REQ req){

	switch(req){
		case(eBMS_DIAGN_CUR_ADC):
			vSetDiag_sts(eBMS_DIAGN_INPROGRESS);
			vDiag_Start_CurADC_chk();
			break;
		case(eBMS_DIAGN_REGULATOR):
			vDiag_Read_Regulator();
			break;
		case(eBMS_DIAGN_VREF2):
			vDiag_Read_VREF2();
			break;
		case(eBMS_DIAGN_MEASUREMENT_SEQ):
			vDiag_Read_MUX();
			break;
		case(eBMS_DIAGN_OSC_CLOCK):
			/* TM3 input */
			SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB2MFP_Msk);
			SYS->GPB_MFPL |= (SYS_GPB_MFPL_PB2MFP_TM3);

			/* ---------------------------------- */
			/*  Event Counter Setting			  */
			/* ---------------------------------- */
			/* Give a dummy target frequency here. Will over write prescale and compare value with macro */
			TIMER_Open(TIMER3, TIMER_CONTINUOUS_MODE, 100u);

			TIMER_ResetCounter(TIMER3);

			/* Update prescale and compare value to what we need in event counter mode. */
			TIMER_SET_PRESCALE_VALUE(TIMER3, 0u);

			/* Counter increase on raising edge */
			TIMER_EnableEventCounter(TIMER3, TIMER_COUNTER_EVENT_FALLING);

			vDiag_Start_OSC();
			vSetDiag_sts(eBMS_DIAGN_INPROGRESS);
			TIMER_Start(TIMER3); 	/*  Start Event Counting */
			break;
		case(eBMS_DIAGN_OPEN_DETECTION):
			vSetDiag_sts(eBMS_DIAGN_INPROGRESS);
			vDiag_Start_DSCN_chk();
			break;

#if(DIAGNOSTIC_SRPSRN)
		case (eBMS_DIAGN_SRPSRN_OPENSHORT):
			vSetDiag_sts(eBMS_DIAGN_INPROGRESS);
			vDiag_SRPSRN_start();
			break;
#endif	/* DIAGNOSTIC_SRPSRN */

		default:
			ulBms_diagn_results = DIAGN_INVALID;		/* diagnostic error / fail status */
			vSetDiag_sts(eBMS_DIAGN_COMPLETED);
			break;
	}

}

/****************************************************************************
FUNCTION	: vTskMonitor_Diag
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/06/23
*****************************************************************************/
void vTskMonitor_Diag(eBMS_DIAGN_REQ req){

	bool bChk = false;
	USHORT usOSC_AveCnt = 0u;

	switch(req){
		case(eBMS_DIAGN_CUR_ADC):
			bChk = bDiag_Check_CurADC();
			if(bChk == true){
				vDiag_Read_CurADC(&sCurADC_buff[ucCVIL_cnt]);
				ucCVIL_cnt++;

				if(ucCVIL_cnt >= DIAGN_CMPL_CYCLE){
					ucdiag_curADC_flg = 1u;
				}
			}
			if(ucdiag_curADC_flg == 1u){
				vDiag_End_CurADC_chk();
				ucCVIL_cnt = 0u;
				vSetDiag_sts(eBMS_DIAGN_COMPLETED);				/* update Diagnostic status to complete */
			}
			break;
		case(eBMS_DIAGN_REGULATOR):
			vDiag_Read_Regulator();
			vSetDiag_sts(eBMS_DIAGN_COMPLETED);
			break;
		case(eBMS_DIAGN_VREF2):
			vDiag_Read_VREF2();
			vSetDiag_sts(eBMS_DIAGN_COMPLETED);

			break;
		case(eBMS_DIAGN_MEASUREMENT_SEQ):
			vDiag_Read_MUX();
			vSetDiag_sts(eBMS_DIAGN_COMPLETED);

			break;
		case(eBMS_DIAGN_OSC_CLOCK):
			ucOSC_100ms_flg+= 1u;
			if(ucOSC_100ms_flg == BMS_CTL_TM_100MSEC){
				/* get current OSC pulse count */
				ulOSC_LastCnt = ulOSC_CurrentCnt;
				ulOSC_CurrentCnt = 0x00FFFFFFu & TIMER_GetCounter(TIMER3);

				if(ulOSC_CurrentCnt > ulOSC_LastCnt){
					usOSC_pulseCnt_buff[ucOSC_cnt] = (USHORT)(ulOSC_CurrentCnt - ulOSC_LastCnt);
				}
				COMP_MAX(usOSC_pulseCnt_buff[ucOSC_cnt], usOSC_pulseCnt_max);
				COMP_MIN(usOSC_pulseCnt_buff[ucOSC_cnt], usOSC_pulseCnt_min);

				ucOSC_cnt++;
				ucOSC_100ms_flg = 0u;
			}

			if(ucOSC_cnt >= DIAGN_CMPL_CYCLE_OSC){
				for(ucOSC_cnt=0u; ucOSC_cnt < DIAGN_CMPL_CYCLE_OSC; ucOSC_cnt++){
					usOSC_AveCnt += usOSC_pulseCnt_buff[ucOSC_cnt];
				}
				usOSC_AveCnt = usOSC_AveCnt - usOSC_pulseCnt_max - usOSC_pulseCnt_min;

				usOSC_AveCnt = (usOSC_AveCnt >> 2u);

				switch(ulBms_diagn_reqdetail){
					case(REQ_DIAGN_OSCL):
						ulBms_diagn_results = ((ULONG)usOSC_AveCnt&0x0000FFFFu);
						stDiag_info.usOSCL_pulseCnt = usOSC_AveCnt;
						break;
					case(REQ_DIAGN_OSCH):
						ulBms_diagn_results = ((ULONG)usOSC_AveCnt&0x0000FFFFu);
						stDiag_info.usOSCH_pulseCnt = usOSC_AveCnt;
						break;
					default:
						ulBms_diagn_results = DIAGN_INVALID;
						break;
				}

				TIMER_Stop(TIMER3);
				TIMER_DisableEventCounter(TIMER3);

				SYS->GPF_MFPL &= ~(SYS_GPB_MFPL_PB2MFP_Msk);
				SYS->GPF_MFPL |= (SYS_GPB_MFPL_PB2MFP_GPIO);
				vBMIC_Set_GPIO_PortSel(BMIC_GPIO3, GPIO3_SEL_INI);	/* return BMIC's GPIO to GPIO INIT */

				/* clear continuous operation of OSC */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
				ucBMIC_Send_Req(OSC_CTL_ADDR, OSCH_GATE_EN, OSCH_GATE_EN, BMIC_DATA_INPUT_NONE);
#else
				ucBMIC_Send_Req(GPIO_CTL5_ADDR, OSCH_GATE_EN, OSCH_GATE_EN, BMIC_DATA_INPUT_NONE);
#endif /* BMIC_KA49702A */
				vSetDiag_sts(eBMS_DIAGN_COMPLETED);

			}
			break;
		case(eBMS_DIAGN_OPEN_DETECTION):
			vDiag_DSCN_state();
			break;

#if(DIAGNOSTIC_SRPSRN)
		case (eBMS_DIAGN_SRPSRN_OPENSHORT):
			vDiag_SRPSPN_ctrl();
			break;
#endif	/* DIAGNOSTIC_SRPSRN */

		default:
			break;
	}

}

/****************************************************************************
FUNCTION	: vDiag_Start_CurADC_chk
DESCRIPTION	: Start Current ADC diagnostic Check
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/06/21
*****************************************************************************/
static void vDiag_Start_CurADC_chk(void){

	USHORT usregdata;

	if(ulBms_diagn_reqdetail != DIAGN_INVALID){

		usdiag_pwrctrl = usBMICReferRegData(PWR_CTRL_ADDR);

		/* PWR_CTRL: b15(ADC_CONT) set to 1 */
		ucBMIC_Send_Req(PWR_CTRL_ADDR, (usdiag_pwrctrl|ADC_CONT), 0xFFFFu, BMIC_DATA_INPUT_NONE);

#if(BMIC_IC_TYPE == BMIC_KA49702A)
		usregdata = usBMICReferRegData(ADCTL2_ADDR);
		if( (usregdata&(ADSWSD_EN|ADIL_ON)) != (ADSWSD_EN|ADIL_ON) ){
			ucBMIC_Send_Req(ADCTL2_ADDR, (ADSWSD_EN|ADIL_ON), (ADSWSD_EN|ADIL_ON), BMIC_DATA_INPUT_NEED);
			Wait_msec(1u);							/* wait 1ms before check status */
		}

		/* clear IADS_DONE */
		ucBMIC_Send_Req(MODESTAT_ADDR, IADS_DONE, IADS_DONE, BMIC_DATA_INPUT_NONE);
#else
		usregdata = usBMICReferRegData(ADCTL_ADDR);
		if( (usregdata&(ADSWSD_EN|ADIL_ON)) != (ADSWSD_EN|ADIL_ON) ){
			ucBMIC_Send_Req(ADCTL_ADDR, (ADSWSD_EN|ADIL_ON), (ADSWSD_EN|ADIL_ON), BMIC_DATA_INPUT_NEED);
			Wait_msec(1u);							/* wait 1ms before check status */
		}

		/* clear IADS_DONE */
		ucBMIC_Send_Req(STAT1_ADDR, IADS_DONE, IADS_DONE, BMIC_DATA_INPUT_NONE);
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */

		if((ucdiag_curADC_flg == 0u) && (ulBms_diagn_reqdetail == REQ_LS_CUR_ADC)){
			/* Enable Diagnostic check for LS current ADC */
			ucBMIC_Send_Req(DIAG_EN_ADDR, DIAG_ISD_EN, DIAG_ISD_EN, BMIC_DATA_INPUT_NEED);
		}
	}

}

/****************************************************************************
FUNCTION	: bDiag_Check_CurADC
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/06/21
*****************************************************************************/
static bool bDiag_Check_CurADC(void)
{
	bool bRet = false;
	USHORT usdata;
	volatile bool spi_result = true;
	UCHAR	adc_complete = 0u;

	/* Monitor IADS_DONE status to latch ADIL */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	usdata = usBMIC_ReadReg(MODESTAT_ADDR);
#else
	usdata = usBMIC_ReadReg(STAT1_ADDR);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
	spi_result = bBMICCheckSpiResult();
	if(spi_result){
		if((usdata & IADS_DONE) == IADS_DONE){					/* Check IADS_DONE flg */
			adc_complete = 1u;
			bRet = true;
		}
	}

	if(adc_complete){
#if(BMIC_IC_TYPE == BMIC_KA49702A)
		ucBMIC_Send_Req(MODESTAT_ADDR, IADS_DONE, IADS_DONE, BMIC_DATA_INPUT_NONE);			/* clear IADS_DONE */
#else
		ucBMIC_Send_Req(STAT1_ADDR, IADS_DONE, IADS_DONE, BMIC_DATA_INPUT_NONE);			/* clear IADS_DONE */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
		ucBMIC_Send_Req(OP_MODE_ADDR, ADIL_LATCH_ON, ADIL_LATCH_ON, BMIC_DATA_INPUT_NONE);		/* NOT INUPUT */
	}
	return(bRet);
}

/****************************************************************************
FUNCTION	: vDiag_Read_CurADC
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/06/21
*****************************************************************************/
static void vDiag_Read_CurADC(SHORT *sadr)
{
	USHORT usdata;

	usdata = usBMIC_ReadReg(OP_MODE_ADDR);
	if((usdata & ADIL_LATCH_ON) == 0u){
		/* Read LS current measurement result */
		*(sadr) = (SHORT)usBMIC_ReadReg(CVIL_AD_ADDR);
	}

}

/****************************************************************************
FUNCTION	: vDiag_End_CurADC_chk
DESCRIPTION	: End Current ADC diagnostic Check
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/06/21
*****************************************************************************/
static void vDiag_End_CurADC_chk(void){

	SHORT sdata;
	USHORT usresult = 0x0000u;		/* results NG */
	LLONG lltemp = 0u;

	sdata = sCurADC_buff[DIAGN_CMPL_CYCLE-1u];

	if((sdata > DIAGN_CVIL_MIN )&&(sdata < DIAGN_CVIL_MAX )){	/* within +/- 10mV of 100mV? */
		usresult = 0x0001u; 		/* results OK */
	}

	lltemp = sdata;
	lltemp *= 360000u;
	lltemp /= 65536u;
	stDiag_info.lCurADC_LS_uV = (LONG)lltemp;	/* CVIL = AD * 360000uV / 65536	*/

	ulBms_diagn_results = ((ULONG)usresult&0x0000FFFFu);
	ulBms_diagn_results |= ((ULONG)(sdata)&0x0000FFFFu) <<16u;		/* result high 16bit - CVIL ADC raw data */

	/* End Current LS ADC Diagnostic check by disabling */
	ucBMIC_Send_Req(DIAG_EN_ADDR, ~DIAG_ISD_EN, DIAG_ISD_EN, BMIC_DATA_INPUT_NEED);

	ucBMIC_Send_Req(PWR_CTRL_ADDR, usdiag_pwrctrl, 0xFFFFu, BMIC_DATA_INPUT_NEED);
}

/****************************************************************************
FUNCTION	: vDiag_Read_VREF2
DESCRIPTION	: read VREF2 OV/UV register flag and update it to the diagnostic results
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/07/04
*****************************************************************************/
static void vDiag_Read_VREF2(void)
{
	USHORT usdata;
	bool spi_result = false;

	usdata = usBMIC_ReadReg(BIASSTAT_ADDR);
	spi_result = bBMICCheckSpiResult();

	if(spi_result){
		ulBms_diagn_results = ((ULONG)((usdata & (HVREF2_MASK|LVREF2_MASK))>> 9u)&0x0000FFFFu);	/* VREF ADC Diagnostic : HVREF2 0x026[10], LVREF2 0x26[9] */
		stDiag_info.usVref = (USHORT)ulBms_diagn_results;
	}else{
		ulBms_diagn_results = DIAGN_INVALID;		/* diagnostic error / fail status */
	}
	vSetDiag_sts(eBMS_DIAGN_COMPLETED);
}

/****************************************************************************
FUNCTION	: vDiag_Read_Regulator
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/07/04
*****************************************************************************/
static void vDiag_Read_Regulator(void)
{
	USHORT usdata;
	bool spi_result = false;

	usdata = usBMIC_ReadReg(BIASSTAT_ADDR);
	spi_result = bBMICCheckSpiResult();

	if(spi_result){
		ulBms_diagn_results = ((ULONG)usdata & 0x000001FFu);	/* Regulator (reg0x26): LBIAS3D[0], HBIAS3D[1], HBIAS3A[2],LBIAS2D[3], HBIAS2D[4], HBIAS2A[5], LBIAS1D[6], HBIAS1D[7], HBIAS1A[8] */
		stDiag_info.usRegulator = (USHORT)ulBms_diagn_results;
	}else{
		ulBms_diagn_results = DIAGN_INVALID;		/* diagnostic error / fail status */
	}
	vSetDiag_sts(eBMS_DIAGN_COMPLETED);
}

/****************************************************************************
FUNCTION	: vDiag_Read_MUX
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/07/12
*****************************************************************************/
static void vDiag_Read_MUX(void)
{
	USHORT usdata;
	bool spi_result = false;

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	usdata = usBMIC_ReadReg(STAT_ADDR);
#else
	usdata = usBMIC_ReadReg(OTHSTAT_ADDR);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
	spi_result = bBMICCheckSpiResult();

	if(spi_result){
		ulBms_diagn_results = ((ULONG)((usdata & MUX1A_F_MASK)>> 10u) & 0x0000FFFFu);	/* Measurement Sequence Diagn check: MUX1A_F 0x21[10] */
		stDiag_info.usMeasSeq =  (USHORT)ulBms_diagn_results;
	}else{
		ulBms_diagn_results = DIAGN_INVALID;		/* diagnostic error / fail status */
	}
	vSetDiag_sts(eBMS_DIAGN_COMPLETED);

}

/****************************************************************************
FUNCTION	: vDiag_Start_OSC
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/07/26
*****************************************************************************/
static void vDiag_Start_OSC(void)
{
	switch(ulBms_diagn_reqdetail){
		case(REQ_DIAGN_OSCL):
			vBMIC_Set_GPIO_PortSel(BMIC_GPIO3, GPIO_SEL_LOSC);
			break;
		case(REQ_DIAGN_OSCH):
			vBMIC_Set_GPIO_PortSel(BMIC_GPIO3, GPIO_SEL_HOSC);
			break;
	}

	/* set for continuous operation of OSC */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	ucBMIC_Send_Req(OSC_CTL_ADDR, ~OSCH_GATE_EN, OSCH_GATE_EN, BMIC_DATA_INPUT_NONE);
#else
	ucBMIC_Send_Req(GPIO_CTL5_ADDR, ~OSCH_GATE_EN, OSCH_GATE_EN, BMIC_DATA_INPUT_NONE);
#endif /* BMIC_KA49702A */
}

/****************************************************************************
FUNCTION	: vDiag_Start_ADC
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/07/14
*****************************************************************************/
static void vDiag_Start_ADC(void)
{
	USHORT usdata;
	volatile bool spi_result = true;
	UCHAR	adc_complete = 0u;
	UCHAR	ucChkCnt = 0u;

#if(1 /*BMIC_IC_TYPE == BMIC_KA49702A*/)
#else
	if((usBMICReferRegData(PWR_CTRL_ADDR) & ADC_CONT) == 0u){		/* PWR_CTRL_ADDR bit15: ADC_CONT, if 0 (Oneshot mode), set OP_MODE_ADDR bit4 ADC_TRG to start ADC */
		ucBMIC_Send_Req(OP_MODE_ADDR, ADC_TRG_ON, ADC_TRG_ON, BMIC_DATA_INPUT_NONE);				/* NOT INUPUT */
		Wait_msec(1u);												/* wait 1ms before check status */
	}
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	while(ucChkCnt < (UCHAR)20u){									/* maximum check 20 times, ~ 2ms */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
		usdata = usBMIC_ReadReg(MODESTAT_ADDR);
#else
		usdata = usBMIC_ReadReg(STAT1_ADDR);
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
		spi_result = bBMICCheckSpiResult();
		if(spi_result){
			if((usdata & VAD_DONE) == VAD_DONE){					/* Check VAD_DONE flg */
				adc_complete = 1u;
				break;
			}
		}else{
			break;
		}
#if(1 /*BMIC_IC_TYPE == BMIC_KA49702A*/)
		wait100us();
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
		ucChkCnt ++;
	}

	if(adc_complete){
#if(BMIC_IC_TYPE == BMIC_KA49702A)
		ucBMIC_Send_Req(MODESTAT_ADDR, VAD_DONE, VAD_DONE, BMIC_DATA_INPUT_NONE);	/* clear VAD_DONE */
#else
		ucBMIC_Send_Req(STAT1_ADDR, VAD_DONE, VAD_DONE, BMIC_DATA_INPUT_NONE);		/* clear VAD_DONE */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
	}

	ucBMIC_Send_Req(OP_MODE_ADDR, ADV_LATCH_ON , ADV_LATCH_ON , BMIC_DATA_INPUT_NONE);		/* NOT INPUT */
}

/****************************************************************************
FUNCTION	: vDiag_CalcCVReadSum
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/07/14
*****************************************************************************/
static void vDiag_CalcCVReadSum(UCHAR stage)
{
	USHORT usdata;
	UCHAR i;
	volatile bool spi_result = true;
	UCHAR ad_stat = OK;

	usdata = usBMIC_ReadReg(OP_MODE_ADDR);
	spi_result = bBMICCheckSpiResult();
	ad_stat &= (UCHAR)spi_result;
	if((usdata & ADV_LATCH_ON) != 0u){
		ucdiag_dscn_err_flg = 1u;
	}else{
		for (i=0; i < BMICCellConf.ucSeriesCount; i++) {
			usdata = usBMIC_ReadReg(i+CV01_AD_ADDR);
			spi_result = bBMICCheckSpiResult();
			ad_stat &= (UCHAR)spi_result;
			if(stage == BEFORE_DSCN){
				ulCVAD_DSCNBef_buff[i] = usdata;
			}else{
				ulCVAD_DSCNAft_buff[i] = usdata;
			}
		}
	}
	if(ad_stat == NG){
		ucdiag_dscn_err_flg = 1u;
	}
}

/****************************************************************************
FUNCTION	: vDiag_Start_DSCN_chk
DESCRIPTION	: Start Open Connection Detection diagnostic Check
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/09/28
*****************************************************************************/
static void vDiag_Start_DSCN_chk(void){

	UCHAR i = 0u;

#if(0)
	/* Enable EN_MSOCB if it is disabled */
	if((usBMICReferRegData(CBSEL_17_ADDR)&EN_MSOCB) == (USHORT)0x0000u){		/* EN_MSOCB "0"? - Measurement-oriented CB disabled */
		ucBMIC_Send_Req(CBSEL_17_ADDR, EN_MSOCB, EN_MSOCB, BMIC_DATA_INPUT_NEED);
		ucdiag_dscn_flg = 1u;
	}
#endif

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	usdiag_pwrctrl = usBMICReferRegData(PWR_CTRL_ADDR);
	usdiag_adctl2 = usBMICReferRegData(ADCTL2_ADDR);
	usdiag_cbsel17 = usBMICReferRegData(CBSEL_17_ADDR);

	ucBMIC_Send_Req(CBSEL_17_ADDR, EN_MSOCB, EN_MSOCB, BMIC_DATA_INPUT_NEED);
	ucBMIC_Send_Req(PWR_CTRL_ADDR, ADC_CONT, ADC_CONT, BMIC_DATA_INPUT_NONE);					/* force ADC continuous mode */
	ucBMIC_Send_Req(ADCTL2_ADDR, 0x0000u, ADV_AVE2_MASK|ADV_AVE_MASK, BMIC_DATA_INPUT_NONE);	/* force ADC measurement average option: 00 (x1) */
	ucBMIC_Send_Req(CBSEL_17_ADDR, 0x3100u, CB_MSK2_MASK, BMIC_DATA_INPUT_NONE);				/* force CB_MSK2[6:0]: 0x18 (25ms) */
#else
	usdiag_pwrctrl = usBMICReferRegData(PWR_CTRL_ADDR);
	usdiag_adctl = usBMICReferRegData(ADCTL_ADDR);
	usdiag_cbsel17 = usBMICReferRegData(CBSEL_17_ADDR);

	ucBMIC_Send_Req(CBSEL_17_ADDR, EN_MSOCB, EN_MSOCB, BMIC_DATA_INPUT_NEED);
	ucBMIC_Send_Req(PWR_CTRL_ADDR, ADC_CONT, ADC_CONT, BMIC_DATA_INPUT_NONE);					/* force ADC continuous mode */
	ucBMIC_Send_Req(ADCTL_ADDR, 0x0000u, ADV_AVE2_MASK|ADV_AVE_MASK, BMIC_DATA_INPUT_NONE);	    /* force ADC measurement average option: 00 (x1) */
	ucBMIC_Send_Req(CBSEL_17_ADDR, 0x3100u, CB_MSK2_MASK, BMIC_DATA_INPUT_NONE);				/* force CB_MSK2[6:0]: 0x18 (25ms) */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	/* clear DSCN diagnostic info */
	for (i=0u; i< BMICCellConf.ucSeriesCount; i++) {
		stDiag_info.ulCV_DSCNBef_uV[i] = 0u;
		stDiag_info.ulCV_DSCNAft_EvenCB_uV[i] = 0u;
		stDiag_info.ulCV_DSCNAft_OddCB_uV[i] = 0u;
	}

	for (i=0u; i<= MAX_CELL_NUM; i++) {
		stDiag_info.lCV_DSCNCmpResult_EvenCB_uV[i] = 0u;
		stDiag_info.lCV_DSCNCmpResult_OddCB_uV[i] = 0u;
	}

	stDiag_info.ulDSCN_results_sts = 0u;


	/* Obtain cell voltage data before the open detection */
	vDiag_Start_ADC();
	vDiag_CalcCVReadSum(BEFORE_DSCN);

	ulBms_diagn_results = DIAG_DSCN_CELLMASK;

	/* ODD Cell balance */
	if((BMICCellConf.ucSeriesCount % (UCHAR)2) == (UCHAR)0) {
		if((ulBms_diagn_reqdetail & 0x00000001u) == 0u){
			uldscn_Oddcell_req = ((ulBms_diagn_reqdetail>>1) & CELL_ODD_MASK_EVENCELL);
            uldscn_Evencell_req = (ulBms_diagn_reqdetail & (~CELL_ODD_MASK_EVENCELL));
		}else{
			uldscn_Oddcell_req = (((ulBms_diagn_reqdetail>>1)|0x00000001u) & CELL_ODD_MASK_EVENCELL);
            uldscn_Evencell_req = (ulBms_diagn_reqdetail & (~CELL_ODD_MASK_EVENCELL));
		}
	} else {
		if((ulBms_diagn_reqdetail & 0x00000001u) == 0u){
			uldscn_Oddcell_req = ((ulBms_diagn_reqdetail>>1) & CELL_ODD_MASK_ODDCELL);
            uldscn_Evencell_req = (ulBms_diagn_reqdetail & (~CELL_ODD_MASK_ODDCELL));
		}else{
			uldscn_Oddcell_req = (((ulBms_diagn_reqdetail>>1)|0x00000001u) & CELL_ODD_MASK_ODDCELL);
            uldscn_Evencell_req = (ulBms_diagn_reqdetail & (~CELL_ODD_MASK_ODDCELL));
		}
	}

	/* EVEN Cell balance */
	if((BMICCellConf.ucSeriesCount % (UCHAR)2) == (UCHAR)0) {
        uldscn_Evencell_req |= ((ulBms_diagn_reqdetail>>1) & (~CELL_ODD_MASK_EVENCELL));
        uldscn_Oddcell_req |= (ulBms_diagn_reqdetail & CELL_ODD_MASK_EVENCELL);
    }else{
        uldscn_Evencell_req |= ((ulBms_diagn_reqdetail>>1) & (~CELL_ODD_MASK_ODDCELL));
        uldscn_Oddcell_req |= (ulBms_diagn_reqdetail & CELL_ODD_MASK_ODDCELL);
	}

    uldscn_Evencell_req &= BITPAT_17CELL;

	if(uldscn_Evencell_req != 0u){
		eDiagn_dscn_state = DSCN_EVEN_CB;
	}else if(uldscn_Oddcell_req != 0u ){
		eDiagn_dscn_state = DSCN_ODD_CB;
	}else{
		eDiagn_dscn_state = DSCN_NONE;
	}

}

/****************************************************************************
FUNCTION	: vDiag_DSCN_state
DESCRIPTION	: Start Open Connection Detection diagnostic Check
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/09/28
*****************************************************************************/
void vDiag_DSCN_state(void){

	USHORT usPwrCtrlSetting;
	UCHAR ucIntm_tim = 0x00u;
	static UCHAR ucCB_flg = 0;

	USHORT send_data1;
	USHORT send_data2;

	switch(eDiagn_dscn_state){
		case(DSCN_EVEN_CB):
			/* EVEN Cell balance */
			send_data1 = (USHORT)(uldscn_Evencell_req & 0x0000FFFFu);
			send_data2 = (USHORT)((uldscn_Evencell_req >> 16) & 0x0000FFFFu);

			if((send_data1 != 0x0000u)||(send_data2 != 0x0000u)){
				vDiag_DSCN_CBctrl(ON,send_data1,send_data2);

				/* check INTM_TIM 31.25ms/62.5ms/125ms/250ms */
				usPwrCtrlSetting = usBMICReferRegData(PWR_CTRL_ADDR);
				ucIntm_tim = (UCHAR)((usPwrCtrlSetting >> 13) & 0x0003u);
				switch(ucIntm_tim){
					case(0x00u):
						ucDSCN_cnt = BMS_CTL_TM_50MSEC;
						break;
					case(0x01u):
						ucDSCN_cnt = BMS_CTL_TM_75MSEC;
						break;
					case(0x02u):
						ucDSCN_cnt = BMS_CTL_TM_125MSEC;
						break;
					case(0x03u):
						ucDSCN_cnt = BMS_CTL_TM_250MSEC;
						break;
					default:
						break;

				}
				ucCB_flg = 1;
			}

			eDiagn_dscn_state = DSCN_ODD_CB;
			break;
		case(DSCN_ODD_CB):
			if(ucDSCN_cnt == 1u){
				if(ucCB_flg == 1u){
					vDiag_DSCN_data_comp(DIAG_DSCN_EVENMASK);
					ucCB_flg = 0u;
				}

				/* ODD Cell balance */
				send_data1 = (USHORT)(uldscn_Oddcell_req & 0x0000FFFFu);
				send_data2 = (USHORT)((uldscn_Oddcell_req >> 16) & 0x0000FFFFu);

				if((send_data1 != 0x0000u)||(send_data2 != 0x0000u)){
					vDiag_DSCN_CBctrl(ON,send_data1,send_data2);

					/* check INTM_TIM 31.25ms/62.5ms/125ms/250ms */
					usPwrCtrlSetting = usBMICReferRegData(PWR_CTRL_ADDR);
					ucIntm_tim = (UCHAR)((usPwrCtrlSetting >> 13u) & 0x0003u);
					switch(ucIntm_tim){
						case(0x00u):
							ucDSCN_cnt = BMS_CTL_TM_50MSEC;
							break;
						case(0x01u):
							ucDSCN_cnt = BMS_CTL_TM_75MSEC;
							break;
						case(0x02u):
							ucDSCN_cnt = BMS_CTL_TM_125MSEC;
							break;
						case(0x03u):
							ucDSCN_cnt = BMS_CTL_TM_250MSEC;
							break;
						default:
							break;
					}
					ucCB_flg = 1u;
				}

				eDiagn_dscn_state = DSCN_END;
			}else{
				ucDSCN_cnt--;
			}

			break;
		case(DSCN_END):
			if(ucDSCN_cnt == 1u){
				if(ucCB_flg == 1u){
				/* Get ODD Cell balance DSCN results */
					vDiag_DSCN_data_comp(DIAG_DSCN_ODDMASK);
					ucCB_flg = 0u;
				}

                /* No Cell balance */
                send_data1 = 0u;
                send_data2 = 0u;

                vDiag_DSCN_CBctrl(OFF,send_data1,send_data2);

				/* Get DSCN judgement results */
				vDiag_DSCN_judgement(ulBms_diagn_reqdetail);

#if(0)
				/* return EN_MSOCB to it original state before DSCN */
				if(ucdiag_dscn_flg == 1u){
					ucBMIC_Send_Req(CBSEL_17_ADDR, ~EN_MSOCB, EN_MSOCB, BMIC_DATA_INPUT_NONE);
					ucdiag_dscn_flg = 0u;
				}
#endif

				ucBMIC_Send_Req(CBSEL_17_ADDR, ~EN_MSOCB, EN_MSOCB, BMIC_DATA_INPUT_NONE);
#if(BMIC_IC_TYPE == BMIC_KA49702A)
				ucBMIC_Send_Req(PWR_CTRL_ADDR, usdiag_pwrctrl, 0xFFFFu, BMIC_DATA_INPUT_NONE);			/* Restore PWR_CTRL user setting */
				ucBMIC_Send_Req(ADCTL2_ADDR, usdiag_adctl2, 0xFFFFu, BMIC_DATA_INPUT_NONE);				/* Restore ADCTL2 user setting */
#else
				ucBMIC_Send_Req(PWR_CTRL_ADDR, usdiag_pwrctrl, 0xFFFFu, BMIC_DATA_INPUT_NONE);			/* Restore PWR_CTRL user setting */
				ucBMIC_Send_Req(ADCTL_ADDR, usdiag_adctl, 0xFFFFu, BMIC_DATA_INPUT_NONE);				/* Restore ADCTL2 user setting */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
				ucBMIC_Send_Req(CBSEL_17_ADDR, usdiag_cbsel17, 0xFFFFu, BMIC_DATA_INPUT_NONE);				/* force CB_MSK2[6:0]: 0x18 (25ms) */


                stDiag_info.ulDSCN_results_sts = ulBms_diagn_results;
				eDiagn_dscn_state = DSCN_NONE;
				vSetDiag_sts(eBMS_DIAGN_COMPLETED);
			}else{
				ucDSCN_cnt--;
			}

			break;
		default:
			break;


	}


}

/****************************************************************************
FUNCTION	: vDiag_DSCN_CBctrl
DESCRIPTION	: Open Connection Detection Cell Balance control
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/10/02
*****************************************************************************/
static void vDiag_DSCN_CBctrl(UCHAR ctrl,USHORT data1, USHORT data2){

	switch(ctrl){
		case(ON):
#if(0)		/* required when EN_MSOCB is disabled */
			ucBMIC_Send_Req(OP_MODE_ADDR, OVMSK_OFF|UVMSK_OFF, OVMSK_OFF|UVMSK_OFF, BMIC_DATA_INPUT_NEED);	/* OV/UV detection off  */
#endif
			/* Set NPD_CB control to turn ON CB */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
			ucBMIC_Send_Req(ADCTL1_ADDR, NPD_CB_NORMAL, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);
#else
			ucBMIC_Send_Req(OTHCTL_ADDR, NPD_CB_NORMAL, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */
			ucBMIC_Send_Req(CBSEL_ADDR, data1, 0xFFFFu, BMIC_DATA_INPUT_NEED);							/* Select cell for CB1~16 */
			ucBMIC_Send_Req(CBSEL_17_ADDR, data2, 0x0001u, BMIC_DATA_INPUT_NEED);						/* Select cell for CB17~22 */
			ucBMIC_Send_Req(OP_MODE_ADDR, CB_SET_ON, CB_SET_ON, BMIC_DATA_INPUT_NEED);						/* CB on  */
			break;
		case(OFF):

			/* set CB_SET bit to "0" to stop CB op */
			ucBMIC_Send_Req(OP_MODE_ADDR, CB_SET_OFF, CB_SET_ON, BMIC_DATA_INPUT_NEED);						/* CB off */
			ucBMIC_Send_Req(CBSEL_ADDR, data1, 0xFFFFu, BMIC_DATA_INPUT_NEED);							/* Deselect cell for CB1~16 */
			ucBMIC_Send_Req(CBSEL_17_ADDR, data2, 0x0001u, BMIC_DATA_INPUT_NEED);						/* Deselect cell for CB17~22 */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
			ucBMIC_Send_Req(ADCTL1_ADDR, NPD_CB_POWERDOWN, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);				/* ADCTL1: NPD_CB OFF */
#else
			ucBMIC_Send_Req(OTHCTL_ADDR, NPD_CB_POWERDOWN, NPD_CB_MASK, BMIC_DATA_INPUT_NEED);				/* OTHCTL: NPD_CB OFF */
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */
#if(0)		/* required when EN_MSOCB is disabled */
			ucBMIC_Send_Req(OP_MODE_ADDR, OVMSK_ON|UVMSK_ON, OVMSK_OFF|UVMSK_OFF, BMIC_DATA_INPUT_NEED);	/* OV/UV detection on */
#endif
			break;
		default:
			break;
	}
}

/****************************************************************************
FUNCTION	: vDiag_DSCN_data_comp
DESCRIPTION	: Get after CB cells voltage data for comparison to determine Open Connection Detection
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/09/28
*****************************************************************************/
static void vDiag_DSCN_data_comp(ULONG target){

	UCHAR i;
	USHORT usCVAD_Bef[MAX_CELL_NUM];
	USHORT usCVAD_Aft[MAX_CELL_NUM];
	ULONG ulCV_DSCNAft_uV[MAX_CELL_NUM];
	ULLONG ulltemp = 0u;
	LLONG lltemp = 0u;

	/* Obtain cell voltage data After the open detection */
	vDiag_Start_ADC();
	vDiag_CalcCVReadSum(AFTER_DSCN);

	/* Compare Data */
	if(ucdiag_dscn_err_flg == 0x00u){
		for (i=0; i< BMICCellConf.ucSeriesCount; i++) {
			usCVAD_Bef[i] = (USHORT)(ulCVAD_DSCNBef_buff[i]);
			ulltemp = usCVAD_Bef[i];
			ulltemp *= 5000000u;
			ulltemp /= 16384u;
			stDiag_info.ulCV_DSCNBef_uV[i] = (ULONG)ulltemp;	/* CVn = AD * 5000000uV / 16384	*/

			usCVAD_Aft[i] = (USHORT)(ulCVAD_DSCNAft_buff[i]);
			ulltemp = usCVAD_Aft[i];
			ulltemp *= 5000000u;
			ulltemp /= 16384u;
			ulCV_DSCNAft_uV[i] = (ULONG)ulltemp;	/* CVn = AD * 5000000uV / 16384	*/
			if(target == DIAG_DSCN_EVENMASK){
				stDiag_info.ulCV_DSCNAft_EvenCB_uV[i] = (ULONG)ulltemp;
			}else{
				stDiag_info.ulCV_DSCNAft_OddCB_uV[i] = (ULONG)ulltemp;
			}

		}
		for (i=0u; i<= MAX_CELL_NUM; i++) {
			if(i == 0u){
				lltemp = (stDiag_info.ulCV_DSCNBef_uV[i] - ulCV_DSCNAft_uV[i]);
			}else{
				lltemp = (stDiag_info.ulCV_DSCNBef_uV[i-1] - ulCV_DSCNAft_uV[i-1]);
			}

			if(target == DIAG_DSCN_EVENMASK){
				stDiag_info.lCV_DSCNCmpResult_EvenCB_uV[i] = (LONG)lltemp;
			}else{
				stDiag_info.lCV_DSCNCmpResult_OddCB_uV[i] = (LONG)lltemp;
			}
		}
	}else{
		ulBms_diagn_results = DIAGN_INVALID;
	}
}

/****************************************************************************
FUNCTION	: vDiag_DSCN_judgement
DESCRIPTION	: Get disconnection detection judgement results
			Open Judgment table
			C0	(CV01_AD)before - (CV01_AD)after > 100mV  &
				(CV02_AD)before - (CV02_AD)after < 100mV
			C1	(CV01_AD)before - (CV01_AD)after > 100mV  &
				(CV02_AD)before - (CV02_AD)after > 100mV
			C2	(CV02_AD)before - (CV02_AD)after > 100mV  &
				(CV03_AD)before - (CV03_AD)after > 100mV
			C3	(CV03_AD)before - (CV03_AD)after > 100mV  &
				(CV04_AD)before - (CV04_AD)after > 100mV
			C4	(CV04_AD)before - (CV04_AD)after > 100mV  &
				(CV05_AD)before - (CV05_AD)after > 100mV
			C5	(CV05_AD)before - (CV05_AD)after > 100mV  &
				(CV06_AD)before - (CV06_AD)after > 100mV
			C6	(CV06_AD)before - (CV06_AD)after > 100mV  &
				(CV07_AD)before - (CV07_AD)after > 100mV
			C7	(CV07_AD)before - (CV07_AD)after > 100mV  &
				(CV08_AD)before - (CV08_AD)after > 100mV
			C8	(CV08_AD)before - (CV08_AD)after > 100mV  &
				(CV09_AD)before - (CV09_AD)after > 100mV
			C9	(CV09_AD)before - (CV09_AD)after > 100mV  &
				(CV10_AD)before - (CV10_AD)after > 100mV
			C10	(CV10_AD)before - (CV10_AD)after > 100mV  &
				(CV11_AD)before - (CV11_AD)after > 100mV
			C11	(CV11_AD)before - (CV11_AD)after > 100mV  &
				(CV12_AD)before - (CV12_AD)after > 100mV
			C12	(CV12_AD)before - (CV12_AD)after > 100mV  &
				(CV13_AD)before - (CV13_AD)after > 100mV
			C13	(CV13_AD)before - (CV13_AD)after > 100mV  &
				(CV14_AD)before - (CV14_AD)after > 100mV
			C14	(CV14_AD)before - (CV14_AD)after > 100mV  &
				(CV15_AD)before - (CV15_AD)after > 100mV
			C15	(CV15_AD)before - (CV15_AD)after > 100mV  &
				(CV16_AD)before - (CV16_AD)after > 100mV
			C16	(CV16_AD)before - (CV16_AD)after > 100mV  &
				(CV17_AD)before - (CV17_AD)after > 100mV
			C17	(CV17_AD)before - (CV17_AD)after > 100mV  &
				(CV16_AD)before - (CV16_AD)after < 100mV
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/10/26
*****************************************************************************/
static void vDiag_DSCN_judgement(ULONG target){

	ULONG ulCnt_pos = 0u;

	for (UCHAR i=0u; i<= MAX_CELL_NUM; i++){
		ulCnt_pos = (1u << i);
		if((target&ulCnt_pos) == ulCnt_pos ){	/* C0,C1,C2,C3,C4... C16,C17 */
			if(i == 0u){			/* C0 */
				if((stDiag_info.lCV_DSCNCmpResult_OddCB_uV[i]>DIAG_DSCN_JGVAL1)				/* odd CB result: CV[01] bef - aft > 100mV? */
				&&(stDiag_info.lCV_DSCNCmpResult_EvenCB_uV[i+2u]<DIAG_DSCN_JGVAL1)			/* even CB result: CV[02] bef - aft < 100mV?*/
				){
					ulBms_diagn_results &= (DIAG_DSCN_CELLMASK & (~ulCnt_pos));
				}
			}else if(i == 17u){	/* C17 */
				if((stDiag_info.lCV_DSCNCmpResult_OddCB_uV[i]>DIAG_DSCN_JGVAL1)				/* odd CB result: CV[17] bef - aft > 100mV? */
				&&(stDiag_info.lCV_DSCNCmpResult_EvenCB_uV[i-1u]<DIAG_DSCN_JGVAL1)){		/* even CB result: CV[16] bef -aft < 100mV */
					ulBms_diagn_results &= (DIAG_DSCN_CELLMASK & (~ulCnt_pos));
				}
			}else{						/* C1,C2,C3,C4...C16 */
				if((ulCnt_pos & DIAG_DSCN_EVENMASK)!= 0u){	/* C2,C4,C6...C16 */
					if((stDiag_info.lCV_DSCNCmpResult_EvenCB_uV[i]>DIAG_DSCN_JGVAL1)			/* even CB result: CV[i] bef - aft > 100mv? */
					&&(stDiag_info.lCV_DSCNCmpResult_OddCB_uV[i+1u]>DIAG_DSCN_JGVAL1)){			/* odd CB result:  CV[i+1] bef - aft > 100mV? */
						ulBms_diagn_results &= (DIAG_DSCN_CELLMASK & (~ulCnt_pos));
					}
				}else{										/* C1,C3,C5...C15 */
					if((stDiag_info.lCV_DSCNCmpResult_OddCB_uV[i]>DIAG_DSCN_JGVAL1)				/* odd CB result: CV[i] bef - aft > 100mv? */
					&&(stDiag_info.lCV_DSCNCmpResult_EvenCB_uV[i+1u]>DIAG_DSCN_JGVAL1)){		/* even CB result: CV[i+1] bef - aft > 100mV? */
						ulBms_diagn_results &= (DIAG_DSCN_CELLMASK & (~ulCnt_pos));
					}
				}
			}
		}
	}
}


#if(DIAGNOSTIC_SRPSRN)
/****************************************************************************
FUNCTION	: vDiag_SRPSRN_start
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2024/04/25
*****************************************************************************/
void vDiag_SRPSRN_start(void)
{
//	USHORT usregdata;

	usdiag_alarmctl1 = usBMICReferRegData(ALARM_CTL1_ADDR);
	ucBMIC_Send_Req(ALARM_CTL1_ADDR, ~EN_CP, EN_CP, BMIC_DATA_INPUT_NEED);		/* EN_CP "0": Disable Current protection during SRP/SRN open/short detection */

	ucBMIC_Send_Req(ANA_CTL_ADDR, (IND_SRNPD|IND_SRPPD|NPD_IND), (IND_SRNPD|IND_SRPPD|NPD_IND), BMIC_DATA_INPUT_NEED);

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	usdiag_adctl2 = usBMICReferRegData(ADCTL2_ADDR);
	if( (usdiag_adctl2&(ADSWSD_EN|ADIL_ON)) != (ADSWSD_EN|ADIL_ON) ){
		ucBMIC_Send_Req(ADCTL2_ADDR, (ADSWSD_EN|ADIL_ON), (ADSWSD_EN|ADIL_ON), BMIC_DATA_INPUT_NONE);
		Wait_msec(1u);							/* wait 1ms before check status */
	}

	/* clear IADS_DONE */
	ucBMIC_Send_Req(MODESTAT_ADDR, IADS_DONE, IADS_DONE, BMIC_DATA_INPUT_NONE);
#else
	usdiag_adctl = usBMICReferRegData(ADCTL_ADDR);
	if( (usdiag_adctl&(ADSWSD_EN|ADIL_ON)) != (ADSWSD_EN|ADIL_ON) ){
		ucBMIC_Send_Req(ADCTL_ADDR, (ADSWSD_EN|ADIL_ON), (ADSWSD_EN|ADIL_ON), BMIC_DATA_INPUT_NONE);
		Wait_msec(1u);							/* wait 1ms before check status */
	}

	/* clear IADS_DONE */
	ucBMIC_Send_Req(STAT1_ADDR, IADS_DONE, IADS_DONE, BMIC_DATA_INPUT_NONE);
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */

	eDiagn_SRPSRN_state = DIAGN_SRN_START;
}


/****************************************************************************
FUNCTION	: vDiag_SRPSPN_ctrl
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2024/04/25
*****************************************************************************/
void vDiag_SRPSPN_ctrl(void)
{
	SHORT sdata;
	LLONG lltemp = 0u;
	static UCHAR ucSRPSRN_chk = 0u;

	switch(eDiagn_SRPSRN_state){

		case DIAGN_SRN_START:
			ucBMIC_Send_Req(ANA_CTL_ADDR, IND_SRNDIAG, IND_SRNDIAG, BMIC_DATA_INPUT_NEED);				/* IND_SRNDIAG "1", IND_SRPDIAG "0" */
			ucSRPSRN_chk = 0u;
			eDiagn_SRPSRN_state = DIAGN_SRN_CHECK;
			break;
		case DIAGN_SRN_CHECK:
			if(bDiag_Check_CurADC()){
				vDiag_Read_CurADC(&sdata);
				ucSRPSRN_chk ++;
				if(ucSRPSRN_chk >= 2u){
					ulBms_diagn_results = ((ULONG)sdata & 0x0000FFFFu);

					/* CVIL in uA = AD * 360000uV / 65536	*/
					lltemp = sdata;
					lltemp *= 360000u;
					lltemp /= 65536u;
					stDiag_info.lSRPSRN_DiagCurADC_uV[0] = (LONG)lltemp;	/* SRN open & short diagnostic result */

					eDiagn_SRPSRN_state = DIAGN_SRP_START;
				}
			}
			break;
		case DIAGN_SRP_START:
			ucBMIC_Send_Req(ANA_CTL_ADDR, IND_SRPDIAG, (IND_SRPDIAG|IND_SRNDIAG), BMIC_DATA_INPUT_NEED);/* IND_SRNDIAG "0", IND_SRPDIAG "1" */

			ucSRPSRN_chk = 0u;
			eDiagn_SRPSRN_state = DIAGN_SRP_CHECK;
			break;
		case DIAGN_SRP_CHECK:
			if(bDiag_Check_CurADC()){
				vDiag_Read_CurADC(&sdata);
				ucSRPSRN_chk ++;
				if(ucSRPSRN_chk >= 2u){
					ulBms_diagn_results = ulBms_diagn_results | ((ULONG)sdata << 16u);

					/* CVIL in uA = AD * 360000uV / 65536	*/
					lltemp = sdata;
					lltemp *= 360000u;
					lltemp /= 65536u;
					stDiag_info.lSRPSRN_DiagCurADC_uV[1] = (LONG)lltemp;	/* SRP open & short diagnostic result */

					eDiagn_SRPSRN_state = DIAGN_SRPSRN_END;
				}
			}

			break;
		case DIAGN_SRPSRN_END:
			ucBMIC_Send_Req(ANA_CTL_ADDR, 0x0000u, (IND_SRNPD|IND_SRPPD|IND_SRNDIAG|IND_SRPDIAG|NPD_IND), BMIC_DATA_INPUT_NEED);
#if(BMIC_IC_TYPE == BMIC_KA49702A)
			ucBMIC_Send_Req(ADCTL2_ADDR, usdiag_adctl2, 0xFFFFu, BMIC_DATA_INPUT_NONE);				/* Restore ADCTL2 user setting */
#else
			ucBMIC_Send_Req(ADCTL_ADDR, usdiag_adctl, 0xFFFFu, BMIC_DATA_INPUT_NONE);				/* Restore ADCTL user setting */
#endif /* BMIC_IC_TYPE == BMIC_KA49702A */
			ucBMIC_Send_Req(ALARM_CTL1_ADDR, usdiag_alarmctl1, 0xFFFFu, BMIC_DATA_INPUT_NEED);		/* Restore ALARM_CTL1 user setting */
			eDiagn_SRPSRN_state = DIAGN_SRPSRN_NONE;
			vSetDiag_sts(eBMS_DIAGN_COMPLETED);
			break;

		default:
			break;
	}
}
#endif	/* DIAGNOSTIC_SRPSRN */


#endif /* BMS_DIAGNOSTIC_SUPPORT */
