/****************************************************************************
#ifdef DOC
File Name		:tsk_led.c
Description		:
Remark			:
Date			:2020/10/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/
#include "NuMicro.h"
#include <stdbool.h>
#include "sys_type.h"
#include "main.h"
#include "drv_timer.h"
#include "drv_bmic.h"
#include "tsk_bmic.h"
#include "portio.h"

/****************************************************************************
 define macro
*****************************************************************************/


/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/

/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/

/****************************************************************************
 Variable declaration
*****************************************************************************/
static UCHAR ucLEDBlink;
/****************************************************************************
 Prototype declaration
*****************************************************************************/

/****************************************************************************
 define data table
*****************************************************************************/

/****************************************************************************
FUNCTION	: vTskInit_led
DESCRIPTION	: LED control task init
INPUT		:
OUTPUT		:
UPDATE		:2022/06/22
DATE		:2020/11/25
*****************************************************************************/
void vTskInit_led(void)
{
	ucLEDBlink = 0u;

	GPIO_PORT_LED4 = 1u;								/* LED4 OFF */
	GPIO_PORT_LED3 = 1u;								/* LED3 OFF */
	GPIO_PORT_LED2 = 1u;								/* LED2 OFF */
	GPIO_PORT_LED1 = 1u;								/* LED1 OFF */

}


/****************************************************************************
FUNCTION	: vTsk_led
DESCRIPTION	: LED control for status indication
INPUT		:
OUTPUT		:
UPDATE		:2023/06/22
DATE		:2020/10/16
*****************************************************************************/
void vTsk_led(void)
{
	UCHAR ucBMIC_status1 = ucGetBMIC_status1();

#if(BMS_STANDBYMODE_SUPPORT)
	UCHAR status = getBMIC_Ctrl_Status();
#endif	/* BMS_STANDBYMODE_SUPPORT */

	if(ucLoop500msFlg){
		ucLoop500msFlg = 0u;

		if(ucLEDBlink){
			ucLEDBlink = 0u;
		}else{
			ucLEDBlink = 1u;
		}

	}

#if(BMS_STANDBYMODE_SUPPORT)
	switch(status){
		case (UCHAR)BMIC_SHUTDOWN:
			GPIO_PORT_LED4 = 1u;								/* LED4 OFF */
			GPIO_PORT_LED3 = 1u;								/* LED3 OFF */
			GPIO_PORT_LED2 = 1u;								/* LED2 OFF */
			GPIO_PORT_LED1 = 1u;								/* LED1 OFF */
			break;
		case (UCHAR)BMIC_STANDBY:
		case (UCHAR)BMIC_SLEEP:	/* Sleep mode */
			GPIO_PORT_LED4 = 1u;								/* LED4 OFF */
			GPIO_PORT_LED3 = 1u;								/* LED3 OFF */
			GPIO_PORT_LED2 = ucLEDBlink;
			GPIO_PORT_LED1 = ucLEDBlink;
			break;
		case (UCHAR)BMIC_LOWPOWER:
			GPIO_PORT_LED4 = 1u;								/* LED4 OFF */
			GPIO_PORT_LED3 = ucLEDBlink;
			if(ucBMIC_status1 & BMIC_OPE_FET_DIS_ON){
				GPIO_PORT_LED2 = 0u;							/* DIS ON: LED2 ON */
			}else{
				GPIO_PORT_LED2 = 1u;
			}

			if(ucBMIC_status1 & BMIC_OPE_FET_CHG_ON){
				GPIO_PORT_LED1 = 0u;							/* DIS ON: LED1 ON */
			}else{
				GPIO_PORT_LED1 = 1u;
			}
			break;
#if(BMS_DIAGNOSTIC_SUPPORT)
		case (UCHAR)BMIC_DIAGNOSTIC:
			GPIO_PORT_LED4 = 1u;								/* LED4 OFF */
			GPIO_PORT_LED3 = ucLEDBlink;
			GPIO_PORT_LED2 = ucLEDBlink;
			GPIO_PORT_LED1 = ucLEDBlink;
			break;
#endif /* BMS_DIAGNOSTIC_SUPPORT */
		default:
#endif	/* BMS_STANDBYMODE_SUPPORT */
			/* LED Display - Status: Active Mode */
			if(ucBMIC_status1 & BMIC_SPI_STATUS_WAKEUP_ERR){
				if(ucBMIC_status1 == BMIC_SPI_STATUS_WAKEUP_ERR){
					GPIO_PORT_LED4 = 0u;
					GPIO_PORT_LED3 = 0u;
					GPIO_PORT_LED2 = 0u;
					GPIO_PORT_LED1 = 0u;
				}else{
					if(ucBMIC_status1 & BMIC_SPI_STATUS_WRITE_ERR){
						GPIO_PORT_LED1 = 0u;							/* Write error: LED1 ON */
					}
					if(ucBMIC_status1 & BMIC_SPI_STATUS_READ_ERR){
						GPIO_PORT_LED2 = 0u;							/* Read error:  LED2 ON */
					}
					GPIO_PORT_LED4 = 1u;								/* LED4 OFF */
					GPIO_PORT_LED3 = 1u;								/* LED3 OFF */
				}
			}else{
				if(ucBMIC_status1 & BMIC_OPE_STATUS_NORMAL){
					GPIO_PORT_LED4 = ucLEDBlink;					/* Normal operation: LED4 blinking */
				}else{
					GPIO_PORT_LED4 = 1u;
				}

				if(ucBMIC_status1 & BMIC_OPE_CELL_BALANCE){
					GPIO_PORT_LED3 = /*ucLEDBlink*/0u;				/* Cell balancing: LED3 light on when CB ON */
				}else{
					GPIO_PORT_LED3 = 1u;
				}

				if(ucBMIC_status1 & BMIC_OPE_FET_DIS_ON){
					GPIO_PORT_LED2 = 0u;								/* DIS ON: LED2 ON */
				}else{
					GPIO_PORT_LED2 = 1u;
				}

				if(ucBMIC_status1 & BMIC_OPE_FET_CHG_ON){
					GPIO_PORT_LED1 = 0u;								/* CHG ON: LED1 ON */
				}else{
					GPIO_PORT_LED1 = 1u;
				}

			}
#if(BMS_STANDBYMODE_SUPPORT)
		break;
	}
#endif	/* BMS_STANDBYMODE_SUPPORT */

}

