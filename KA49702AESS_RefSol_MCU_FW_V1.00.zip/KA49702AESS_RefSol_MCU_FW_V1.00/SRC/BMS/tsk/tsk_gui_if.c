/****************************************************************************
#ifdef DOC
File Name		:tsk_gui_if.c
Description		:
Remark			:
Date			:2020/10/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/
#include "NuMicro.h"
#include <stdbool.h>
#include "sys_type.h"
#include "main.h"
#include "drv_timer.h"
#if(PCGUI_IF_USB)
#include "drv_usbd.h"
#else
#include "drv_uart.h"
#endif	/* PCGUI_IF_USB */
#include "drv_bmic.h"
#if(BMIC_IC_TYPE == BMIC_KA49702A)
#include "bmic_reg_702.h"
#else
#include "bmic_reg_701.h"
#endif /* BMIC_KA49702A */
#include "tsk_bmic.h"
#include "portio.h"
#if(BMS_DIAGNOSTIC_SUPPORT)
#include "tsk_diagn.h"
#endif /* BMS_DIAGNOSTIC_SUPPORT */
/****************************************************************************
 define macro
*****************************************************************************/
#define	RX_BUF_SIZE						(200u)
#define TX_BUF_SIZE						(300u)
#define MASTER_HEADER					(0xA1u)
#define SLAVE_OK_HEADER					(0x52u)
#define SLAVE_NG_HEADER					(0x62u)

/* PC GUI Command ID Definition	Start				*/
#define GUICMD_ALL_REQ					(0x01u)
#define GUICMD_REGISTER_WRITE_REQ		(0x02u)
/*#define								(0x03u)	*/
#if(BMS_FETSTATE_CTRL)
#define	GUICMD_FET_CTL_ON_OFF_REQ		(0x04u)
#define	GUICMD_PROTECT_SETTING_REQ		(0x05u)
#endif	/* BMS_FETSTATE_CTRL */
#define	GUICMD_CELL_BALANCE_REQ			(0x06u)
/*#define								(0x07u) */
/*#define								(0x08u) */
/*#define								(0x09u) */
/*#define								(0x0Au) */
#define	GUICMD_SAFETY_DIAGN_REQ			(0x0Bu)
/*#define								(0x0Cu) */
/*#define								(0x0Du) */
#if(BMS_TESTMODE)
#define GUICMD_TMODE_RW_REQ				(0x0Eu)
#endif /* BMS_TESTMODE */
#define		GUICMD_FW_VER_REQ			(0x0Fu)
#define	GUICMD_FW_UPD_REQ				(0x10u)
/* PC GUI Command ID Definition	End				*/

/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/
typedef struct {
	USHORT	usRxLen;
	UCHAR	ucRxData[RX_BUF_SIZE];
	UCHAR	ucRxNewCmd;
}TUARTRxInfo;

typedef struct {
	USHORT	usTxCnt;
	USHORT	usTxLen;
	UCHAR	ucTxData[TX_BUF_SIZE];
	UCHAR	ucTxInProcess;
}TUARTTxInfo;

/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/
/****************************************************************************
 Variable declaration
*****************************************************************************/
static TUARTRxInfo		UARTRxInfo;
static TUARTTxInfo		UARTTxInfo;

/****************************************************************************
 Prototype declaration
*****************************************************************************/
void SetResponse_CmdErr(UCHAR tx0);
void SetResponse_nodata(UCHAR tx0, UCHAR tx1);
void SetResponse_1data(UCHAR tx0, UCHAR tx1, UCHAR data);
void vTask_gui_if(void);
void vUartCmdRx(UCHAR rx_data);

/****************************************************************************
 define data table
*****************************************************************************/


/****************************************************************************
FUNCTION	: vCalcCRC8
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/10/29
*****************************************************************************/
static void vCalcCRC8(UCHAR *crc, UCHAR data)
{
	static const UCHAR ucCRC8_tCalc[] = {
		0x00u,0xd5u,0x7fu,0xaau,0xfeu,0x2bu,0x81u,0x54u,0x29u,0xfcu,0x56u,0x83u,0xd7u,0x02u,0xa8u,0x7du,
		0x52u,0x87u,0x2du,0xf8u,0xacu,0x79u,0xd3u,0x06u,0x7bu,0xaeu,0x04u,0xd1u,0x85u,0x50u,0xfau,0x2fu,
		0xa4u,0x71u,0xdbu,0x0eu,0x5au,0x8fu,0x25u,0xf0u,0x8du,0x58u,0xf2u,0x27u,0x73u,0xa6u,0x0cu,0xd9u,
		0xf6u,0x23u,0x89u,0x5cu,0x08u,0xddu,0x77u,0xa2u,0xdfu,0x0au,0xa0u,0x75u,0x21u,0xf4u,0x5eu,0x8bu,
		0x9du,0x48u,0xe2u,0x37u,0x63u,0xb6u,0x1cu,0xc9u,0xb4u,0x61u,0xcbu,0x1eu,0x4au,0x9fu,0x35u,0xe0u,
		0xcfu,0x1au,0xb0u,0x65u,0x31u,0xe4u,0x4eu,0x9bu,0xe6u,0x33u,0x99u,0x4cu,0x18u,0xcdu,0x67u,0xb2u,
		0x39u,0xecu,0x46u,0x93u,0xc7u,0x12u,0xb8u,0x6du,0x10u,0xc5u,0x6fu,0xbau,0xeeu,0x3bu,0x91u,0x44u,
		0x6bu,0xbeu,0x14u,0xc1u,0x95u,0x40u,0xeau,0x3fu,0x42u,0x97u,0x3du,0xe8u,0xbcu,0x69u,0xc3u,0x16u,
		0xefu,0x3au,0x90u,0x45u,0x11u,0xc4u,0x6eu,0xbbu,0xc6u,0x13u,0xb9u,0x6cu,0x38u,0xedu,0x47u,0x92u,
		0xbdu,0x68u,0xc2u,0x17u,0x43u,0x96u,0x3cu,0xe9u,0x94u,0x41u,0xebu,0x3eu,0x6au,0xbfu,0x15u,0xc0u,
		0x4bu,0x9eu,0x34u,0xe1u,0xb5u,0x60u,0xcau,0x1fu,0x62u,0xb7u,0x1du,0xc8u,0x9cu,0x49u,0xe3u,0x36u,
		0x19u,0xccu,0x66u,0xb3u,0xe7u,0x32u,0x98u,0x4du,0x30u,0xe5u,0x4fu,0x9au,0xceu,0x1bu,0xb1u,0x64u,
		0x72u,0xa7u,0x0du,0xd8u,0x8cu,0x59u,0xf3u,0x26u,0x5bu,0x8eu,0x24u,0xf1u,0xa5u,0x70u,0xdau,0x0fu,
		0x20u,0xf5u,0x5fu,0x8au,0xdeu,0x0bu,0xa1u,0x74u,0x09u,0xdcu,0x76u,0xa3u,0xf7u,0x22u,0x88u,0x5du,
		0xd6u,0x03u,0xa9u,0x7cu,0x28u,0xfdu,0x57u,0x82u,0xffu,0x2au,0x80u,0x55u,0x01u,0xd4u,0x7eu,0xabu,
		0x84u,0x51u,0xfbu,0x2eu,0x7au,0xafu,0x05u,0xd0u,0xadu,0x78u,0xd2u,0x07u,0x53u,0x86u,0x2cu,0xf9u
	};

	*crc = ucCRC8_tCalc[*crc ^ data];
}

/****************************************************************************
FUNCTION	: ucGetCRC8
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/10/29
*****************************************************************************/
static UCHAR ucGetCRC8(const UCHAR *buf, USHORT size)
{
	/* UCHAR	uccrc = 0x0u; */
	UCHAR	uccrc = 0xD5u;					/* CRC initial: 0xD5*/
	USHORT	i;

	if ((buf != NULL) && (size > 0u)) {
		for( i = 0u; i < size; i++) {
			vCalcCRC8(&uccrc,  buf[i]);
		}
	}
	return uccrc;
}


/****************************************************************************
FUNCTION	: vClearCmdRx
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/10/29
*****************************************************************************/
static void vClearCmdRx(void)
{
	UARTRxInfo.usRxLen = 0u;
	UARTRxInfo.ucRxNewCmd = 0u;
}


/****************************************************************************
FUNCTION	: IsValdCmd
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/10/29
*****************************************************************************/
static bool IsValidCmd(UCHAR rx_data)
{
	bool ret = false;
	if ((0x1u <= rx_data) && (rx_data <= 0x10u)) {
		ret = true;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: bRxCmdComplete
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/10/19
*****************************************************************************/
static bool bRxCmdComplete(void)
{
	bool ret = false;
	USHORT len = 0u;

	if (UARTRxInfo.usRxLen >= 4u) {
		if(UARTRxInfo.ucRxData[1u] >= GUICMD_FW_UPD_REQ){
			len = (USHORT)UARTRxInfo.ucRxData[2u] | ((USHORT)UARTRxInfo.ucRxData[3u] << 8u) ;
			if (((USHORT)len + 5u) <= UARTRxInfo.usRxLen) {
				ret = true;
			}

		}else{
			len = UARTRxInfo.ucRxData[2u];
			if (((USHORT)len + 4u) <= UARTRxInfo.usRxLen) {
				ret = true;
			}
		}
	}
	return ret;
}
/****************************************************************************
FUNCTION	: vUartCmdRx
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/10/19
*****************************************************************************/
void vUartCmdRx(UCHAR rx_data)
{
	if (UARTRxInfo.usRxLen == 0u) {
		if (rx_data == MASTER_HEADER) {
			UARTRxInfo.ucRxData[0u] = rx_data;
			UARTRxInfo.usRxLen = 1u;
		}
	} else if (UARTRxInfo.usRxLen == 1u) {
		if (IsValidCmd(rx_data)) {
			UARTRxInfo.ucRxData[1u] = rx_data;
			UARTRxInfo.usRxLen = 2u;
		} else {
			UARTRxInfo.usRxLen = 0u;
		}
	} else {
		UARTRxInfo.ucRxData[UARTRxInfo.usRxLen] = rx_data;
		UARTRxInfo.usRxLen++;
		if (bRxCmdComplete()) {
			UARTRxInfo.ucRxNewCmd = 1u;
		}
		/* To avoid rx buffer overflow when debug pause with GUI running */
		if(UARTRxInfo.usRxLen >= RX_BUF_SIZE){
			vClearCmdRx();
		}
	}
}


/****************************************************************************
FUNCTION	: vGuiIfCmd_GetAllInfo
DESCRIPTION	: Request all command packet
			:  0xA1, 0x1, 0x0, <crc8>
			:  OK: 0x52, 0x1, <data len>, <data>, <crc8>
			:  NG: 0x62
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/10/19
*****************************************************************************/
static void vGuiIfCmd_GetAllInfo(void)		/* cmd=0x1	All_Req */
{

	UCHAR size = UARTRxInfo.ucRxData[2u];
	UCHAR adr = 0u;
	USHORT regdata = 0u;
	UCHAR crc = 0u;

	UCHAR ucCnt;

	UCHAR ucCurrentLog;
	if ((UARTRxInfo.usRxLen == 5u) && (size == 0x1u)) {
		ucCurrentLog = 	UARTRxInfo.ucRxData[3u];
		size = 0u;

		UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;
		UARTTxInfo.ucTxData[size++] = GUICMD_ALL_REQ;
		UARTTxInfo.ucTxData[size++] = 0u;								/* temp data size: 0 */

		for(adr = PWR_CTRL_ADDR; adr <= (UCHAR)BMIC_REG_MAX_ADDR; adr ++){
			regdata = usBMICReferRegData(adr);
			UARTTxInfo.ucTxData[size++] = (UCHAR)(regdata & (USHORT)0x00FF);
			UARTTxInfo.ucTxData[size++] = (UCHAR)((regdata & (USHORT)0xFF00) >> 8u);
		}
		UARTTxInfo.ucTxData[size++] = ucGetBMIC_status1();				/* status 1: operation mode & error status */
		UARTTxInfo.ucTxData[size++] = ucGetBMIC_status2();				/* status 2: FG */
		#if(BMS_FETSTATE_CTRL)
		UARTTxInfo.ucTxData[size++] = ucGetBMIC_status3();				/* status 3: MCU charge/discharge state */
		#else
		UARTTxInfo.ucTxData[size++] = 0u;								/* status 3: reserved */
		#endif	/* BMS_FETSTATE_CTRL */

		/*UARTTxInfo.ucTxData[size++] = 0u;*/							/* status 4: reserved */
		UARTTxInfo.ucTxData[size++] = ucGetADIL_DataLogStatus();		/* status 4: ADIL data log status */

		/* Temperature conversion result */
		for(ucCnt=0; ucCnt < THERMISTOR_NUM; ucCnt++){
			UARTTxInfo.ucTxData[size++] = (UCHAR)((USHORT)(BMIC_Info.sTemp_01Cdeg[ucCnt] + (SHORT)400) & (USHORT)0x00FF);
			UARTTxInfo.ucTxData[size++] = (UCHAR)(((USHORT)(BMIC_Info.sTemp_01Cdeg[ucCnt] + (SHORT)400) >>8) & (USHORT)0x00FF);
		}
		/* 1: Include ADIL log data */
		ucCnt = ucGetBMIC_ADIL_LogData(&UARTTxInfo.ucTxData[size], ucCurrentLog);
		size += ucCnt;

		UARTTxInfo.ucTxData[2] = size - 3u;								/* update actual data size */

		crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
		UARTTxInfo.ucTxData[size++] = crc;
		UARTTxInfo.usTxLen = size;
	}
	else {
		SetResponse_CmdErr(SLAVE_NG_HEADER);
	}
}

#if(BMS_TESTMODE)
/****************************************************************************
FUNCTION	: vGuiIfCmd_TMODEReadWrite
DESCRIPTION	: BMS Program EFUSE command packet
			:  0xA1, 0xE, <datalength>, <format>, <data1>, <data2>,.., <crc8>
			:  Read OK: 0x52, 0xE, <datalength>, <data1>, <data2>,.., <crc8>
			:  WRITE OK: 0x52, 0xE, <datalength>, <data>, <crc8>
			:  NG: 0x62
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/08/07
*****************************************************************************/
static void vGuiIfCmd_TMODEReadWrite(void)		/* cmd=0x7 Register Read or Write */
{
	UCHAR size = UARTRxInfo.ucRxData[2u];
	UCHAR format = UARTRxInfo.ucRxData[3u];
	UCHAR regaddr_no = 0u;
	UCHAR adr = 0u;
	USHORT register_data = 0u;
	UCHAR crc = 0u;
	volatile UCHAR spi_result;
	UCHAR stat = OK;

	/* Format Read (GUI -> MCU) */
	if ((UARTRxInfo.usRxLen == 7u) && (size == 0x3u) && (format == 0x01u)) {
		UCHAR register_adr = UARTRxInfo.ucRxData[4u];
		regaddr_no = UARTRxInfo.ucRxData[5u];


		size = 0u;
		UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;
		UARTTxInfo.ucTxData[size++] = GUICMD_TMODE_RW_REQ;
		UARTTxInfo.ucTxData[size++] = ((regaddr_no * 2u)+1u);	/* 1 byte start reg add + no. of reg addr data to return */

		UARTTxInfo.ucTxData[size++] = register_adr;
		for(adr = register_adr; adr < (UCHAR)(register_adr+regaddr_no); adr ++){
			register_data = usBMIC_ReadReg(adr);
			UARTTxInfo.ucTxData[size++] = (UCHAR)(register_data & (USHORT)0x00FF);
			UARTTxInfo.ucTxData[size++] = (UCHAR)((register_data & (USHORT)0xFF00) >> 8u);
		}

		crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
		UARTTxInfo.ucTxData[size++] = crc;
		UARTTxInfo.usTxLen = size;

	} /* Format Write (GUI -> MCU) */
	else if(((UARTRxInfo.usRxLen >= 8u) && (size >= 0x3u) && (format == 0x00u))){

		for(adr = 0u; adr < (size - 1u); adr += 3u){
			UCHAR register_adr = UARTRxInfo.ucRxData[(4u+adr)];
			register_data = (USHORT)UARTRxInfo.ucRxData[(5u+adr)] & 0x00FFu;					/* register data lower byte */
			register_data |= (USHORT)(((USHORT)UARTRxInfo.ucRxData[(6u+adr)] & 0x00FFu) << 8u);	/* register data higher byte */
			if(register_adr <= BMIC_REG_MAX_ADDR){
				spi_result= ucBMIC_Send_Req(register_adr, register_data, 0xFFFFu, BMIC_DATA_INPUT_NEED);
			}else{
				vBMICWriteReg(register_adr, register_data);
				spi_result = OK;
			}
			stat &= spi_result;
		}
		if(stat == OK){
			SetResponse_1data(SLAVE_OK_HEADER, GUICMD_TMODE_RW_REQ, OK);	/* register data write success response */
		}else{
			SetResponse_1data(SLAVE_OK_HEADER, GUICMD_TMODE_RW_REQ, NG);	/* register data write fail respons */
		}

	} /* Format Continuous Write (GUI -> MCU) */
	else if(((UARTRxInfo.usRxLen >= 10u) && (size >= 0x6u) && (format == 0x02u))){
		if(((size - 1u)%5u) == 0u){
			stat = ucTM_ContiWriteReq(&UARTRxInfo.ucRxData[2u]);
		}else{
			stat = NG;
		}
		if(stat == OK){
			SetResponse_1data(SLAVE_OK_HEADER, GUICMD_TMODE_RW_REQ, OK);	/* register data write success response */
		}else{
			SetResponse_1data(SLAVE_OK_HEADER, GUICMD_TMODE_RW_REQ, NG);	/* register data write fail respons */
		}

	} /* Format Continuous Read or Write (GUI -> MCU) */
	else if(((UARTRxInfo.usRxLen >= 11u) && (size >= 0x7u) && (format == 0x0Fu))){
		if(((size - 1u)%6u) == 0u){
			stat = ucTM_ContiRWReq(&UARTRxInfo.ucRxData[2u]);
		}else{
			stat = NG;
		}
		if(stat == OK){
			vCtrl_ContinuousRWReg();	/* register data read/write success response */
			size = 0u;
			UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;
			UARTTxInfo.ucTxData[size++] = GUICMD_TMODE_RW_REQ;
			UARTTxInfo.ucTxData[size++] = UARTRxInfo.ucRxData[2u];
			UARTTxInfo.ucTxData[size++] = format;

			size = size + ucGetTM_ContiRWReq(&UARTTxInfo.ucTxData[size]) + 1u;
            crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
            UARTTxInfo.ucTxData[size++] = crc;
            UARTTxInfo.usTxLen = size;
		}else{
			SetResponse_CmdErr(SLAVE_NG_HEADER);
		}

	} /* Format Prepare MCU to go into Testmode */
	else if((UARTRxInfo.usRxLen == 7u) && (size == 0x3u) && (format == 0x02u)){

		size = 0u;
		UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;
		UARTTxInfo.ucTxData[size++] = GUICMD_TMODE_RW_REQ;
		UARTTxInfo.ucTxData[size++] = 0x01u;
		UARTTxInfo.ucTxData[size++] = ucTestMode_Req(UARTRxInfo.ucRxData[4u], UARTRxInfo.ucRxData[5u]);

		crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
		UARTTxInfo.ucTxData[size++] = crc;
		UARTTxInfo.usTxLen = size;

	} /* Format Get CVAD data */
	else if((UARTRxInfo.usRxLen == 7u) && (size == 0x3u) && (format == 0x03u)){
		UCHAR cellno = UARTRxInfo.ucRxData[4u];
		UCHAR cvad = UARTRxInfo.ucRxData[5u];


		size = 0u;
		UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;
		UARTTxInfo.ucTxData[size++] = GUICMD_TMODE_RW_REQ;
		UARTTxInfo.ucTxData[size++] = ((cvad * 2u)+1u);	/* 1 byte cellno request + no. of CVAD to return */
		UARTTxInfo.ucTxData[size++] = cellno;

		for(UCHAR cnt=0; cnt<cvad; cnt++){
			register_data = usGet_CVADLog(cellno,cnt);
			UARTTxInfo.ucTxData[size++] = (UCHAR)(register_data & (USHORT)0x00FF);
			UARTTxInfo.ucTxData[size++] = (UCHAR)((register_data & (USHORT)0xFF00) >> 8u);
		}
		crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
		UARTTxInfo.ucTxData[size++] = crc;
		UARTTxInfo.usTxLen = size;
	} else {
		SetResponse_CmdErr(SLAVE_NG_HEADER);
	}

}
#endif /* BMS_TESTMODE */

/****************************************************************************
FUNCTION	: vGuiIfCmd_RegisterWrite
DESCRIPTION	: BMS Register Write command packet
			:  0xA1, 0x2, 0x03, <addr>, <dataLo>, <dataHi>, <crc8>
			:  OK: 0x52, 0x2, <data len>, <data>, <crc8>
			:  NG: 0x62
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/10/19
*****************************************************************************/
static void vGuiIfCmd_RegisterWrite(void)		/* cmd=0x2 Register Write */
{
	UCHAR size = UARTRxInfo.ucRxData[2u];
#if(BMS_STANDBYMODE_SUPPORT)
	UCHAR ucCurOpeMode = ucGet_BMICOpeMode();
	UCHAR ucComm_flg = ON;
#endif	/* BMS_STANDBYMODE_SUPPORT */

	if ((UARTRxInfo.usRxLen == 7u) && (size == 0x3u)) {
		UCHAR	register_adr = UARTRxInfo.ucRxData[3u];
		USHORT register_data = 0u;

		register_data = (USHORT)UARTRxInfo.ucRxData[4u] & 0x00FFu;			/* register data lower byte */
		register_data |= (USHORT)(((USHORT)UARTRxInfo.ucRxData[5u] & 0x00FFu) << 8u);	/* register data higher byte */

#if(BMS_STANDBYMODE_SUPPORT)
		ucCurOpeMode = ucGet_BMICOpeMode();

		ucComm_flg = ucCheckOpeModeComm(ucCurOpeMode,register_adr,register_data);

		if(ucComm_flg == ON){
			if(register_adr == PWR_CTRL_ADDR){
				vChangeOpeModeReq(ucCurOpeMode,&register_data);			/* Check operation mode change request*/
			}
#endif	/* BMS_STANDBYMODE_SUPPORT */

			if(ucBMIC_Send_Req(register_adr, register_data, 0xFFFFu, BMIC_DATA_INPUT_NEED)){
				SetResponse_1data(SLAVE_OK_HEADER, GUICMD_REGISTER_WRITE_REQ, OK);	/* register data write success response */
			}else{
				SetResponse_1data(SLAVE_OK_HEADER, GUICMD_REGISTER_WRITE_REQ, NG);	/* register data write fail respons */
			}
#if(BMS_STANDBYMODE_SUPPORT)
		}else{
			SetResponse_1data(SLAVE_OK_HEADER, GUICMD_REGISTER_WRITE_REQ, NG);		/* register data write fail respons */
		}
#endif	/* BMS_STANDBYMODE_SUPPORT */



	} else {
		SetResponse_CmdErr(SLAVE_NG_HEADER);
	}

}

#if(BMS_FETSTATE_CTRL)
/****************************************************************************
FUNCTION	: vGuiIfCmd_FETControl
DESCRIPTION	: BMS FET Control command packet
			:  0xA1, 0x04, 0x03, <data1>, <data2>, <data3>, <crc8>
			:  OK: 0x52, 0x04, <data len>, <data>, <crc8>
			:  NG: 0x62
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2021/02/19
*****************************************************************************/
static void vGuiIfCmd_FETControl(void)
{
	UCHAR size = UARTRxInfo.ucRxData[2u];
	UCHAR ucFETCtrl;
	bool bRet;
	USHORT regdata;
	UCHAR crc = 0u;

	if ((UARTRxInfo.usRxLen == 7u) && (size == 0x3u)) {

		ucFETCtrl = UARTRxInfo.ucRxData[3u];

		bRet = bSetFETCtrlMode(ucFETCtrl);

		if(bRet){
			if(ucFETCtrl == 0u){ /* GUI evaluation mode */

#if(BMS_STANDBYMODE_SUPPORT)
				UCHAR ucCurOpeMode = ucGet_BMICOpeMode();
				if((ucCurOpeMode == (UCHAR)BMIC_OPEMODE_ACTIVE)
				|| (ucCurOpeMode == (UCHAR)BMIC_OPEMODE_LOWPOWER)
				){
#endif	/* BMS_STANDBYMODE_SUPPORT */

					vBMIC_Discharge_FET_Out(UARTRxInfo.ucRxData[4u]);
					vBMIC_Charge_FET_Out(UARTRxInfo.ucRxData[5u]);

#if(BMS_STANDBYMODE_SUPPORT)
				}else{
					/* Other than Active mode or LowPower mode, response NG & return */
					SetResponse_CmdErr(SLAVE_NG_HEADER);
					return;
				}
#endif	/* BMS_STANDBYMODE_SUPPORT */

			}

			/* Prepare response data */
			size = 0u;
			UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;					/* Slave Header */
			UARTTxInfo.ucTxData[size++] = GUICMD_FET_CTL_ON_OFF_REQ;		/* CMD ID 	*/
			UARTTxInfo.ucTxData[size++] = 3u;								/* Data Len */

			UARTTxInfo.ucTxData[size++] = ucGetFETCtrlMode();

			if(ucGetFETCtrlMode()){							/* Enable FET SW control, response data refer to FET DRV status */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
				regdata = usBMICReferRegData(MODESTAT_ADDR);	/* check MODESTAT data */
#else
				regdata = usBMICReferRegData(STAT1_ADDR);		/* check STAT1 data */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
				if(regdata & FDRV_DIS_ST_MASK){					/* bp11 - FDRV_DIS_ST */
					UARTTxInfo.ucTxData[size++] = ON;
				}else{
					UARTTxInfo.ucTxData[size++] = OFF;
				}
				if(regdata & FDRV_CHG_ST_MASK){					/* bp10 - FDRV_CHG_ST */
					UARTTxInfo.ucTxData[size++] = ON;
				}else{
					UARTTxInfo.ucTxData[size++] = OFF;
				}
			}else{											/* Disable FET SW control, response data according to request */
				UARTTxInfo.ucTxData[size++] = UARTRxInfo.ucRxData[4u];
				UARTTxInfo.ucTxData[size++] = UARTRxInfo.ucRxData[5u];
			}
			crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
			UARTTxInfo.ucTxData[size++] = crc;
			UARTTxInfo.usTxLen = size;

		}else{
			SetResponse_CmdErr(SLAVE_NG_HEADER);
		}

	} else {
		SetResponse_CmdErr(SLAVE_NG_HEADER);
	}
}


/****************************************************************************
FUNCTION	: vGuiIfCmd_ProtectSetting
DESCRIPTION	: Protect Setting command packet
			:  0xA1, 0x05, 0x01, <0x00>, <crc8> - Request Format 1
			:  0xA1, 0x05, 0x3D, <0x01>, <data2>, <data3>, ... , <crc8> - Request Format 2
			:  OK: 0x52, 0x05, <0x3D>, <0x00>, <data2>, <data3>, ... , <crc8> - Response Format 1
			:  OK: 0x52, 0x05, <0x02>, <data1>, <data2>, <crc8> - Response Fromat 2
			:  NG: 0x62
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2021/02/19
*****************************************************************************/
static void vGuiIfCmd_ProtectSetting(void)
{
	UCHAR size = UARTRxInfo.ucRxData[2u];
	UCHAR crc = 0u;
	UCHAR ucSetResult = 0u;

	if((size == 0x01u) && (UARTRxInfo.ucRxData[3u] == 0x00u)){				/* Requset Format 1? */
		size = 0u;
		UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;
		UARTTxInfo.ucTxData[size++] = GUICMD_PROTECT_SETTING_REQ;
		UARTTxInfo.ucTxData[size++] = 0u;						/* temp data size: 0 */

		UARTTxInfo.ucTxData[size++] = 0x00u;					/* 0x00 - current protect settings */

		vGetCurrentProtectSetting(&UARTTxInfo.ucTxData[size], &size);

		UARTTxInfo.ucTxData[2] = size - 3u;						/* update actual data size */

		crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
		UARTTxInfo.ucTxData[size++] = crc;
		UARTTxInfo.usTxLen = size;

	}else if((size == 0x3Du) && (UARTRxInfo.ucRxData[3u] == 0x01u)){		/* Request Format 2? */
		ucSetResult = ucSetProtectSetting(&UARTRxInfo.ucRxData[4u], (size-(UCHAR)1));

		size = 0u;

		UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;
		UARTTxInfo.ucTxData[size++] = GUICMD_PROTECT_SETTING_REQ;
		UARTTxInfo.ucTxData[size++] = 2u;
		UARTTxInfo.ucTxData[size++] = 0x01u;					/* 0x01 - MCU protect settings update result */
		UARTTxInfo.ucTxData[size++] = ucSetResult;

		crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
		UARTTxInfo.ucTxData[size++] = crc;
		UARTTxInfo.usTxLen = size;

	}else{
		SetResponse_CmdErr(SLAVE_NG_HEADER);
	}

}

#endif	/* #if(BMS_FETSTATE_CTRL) */

extern const char appliversion[];
/****************************************************************************
FUNCTION	: vGuiIfCmd_GetVerInfo
DESCRIPTION	: BMS DD firmware version request
			:  0xA1, 0xf, 0x00, <crc8>
			:  OK: 0x52, 0xf, <0x2>, <minor ver>, <major ver>, <crc8>
			:  NG: 0x62
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/11/06
*****************************************************************************/
static void vGuiIfCmd_GetVerInfo(void)			/* cmd=0xF FW version request */
{
	UCHAR size = UARTRxInfo.ucRxData[2u];
	UCHAR crc = 0u;

	if ((UARTRxInfo.usRxLen == 4u) && (size == 0x0u)) {
		size = 0u;
		UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;
		UARTTxInfo.ucTxData[size++] = GUICMD_FW_VER_REQ;
		UARTTxInfo.ucTxData[size++] = 3u;					/* len: 3 */
		UARTTxInfo.ucTxData[size++] = (UCHAR)(appliversion[28u] - '0') * 10u + (UCHAR)(appliversion[29u] - '0');	/* Ver minor */
		UARTTxInfo.ucTxData[size++] = (UCHAR)(appliversion[25u]  - '0') * 10u + (UCHAR)(appliversion[26u] - '0');	/* Ver major */
		UARTTxInfo.ucTxData[size++] = BMIC_IC_TYPE;
		crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
		UARTTxInfo.ucTxData[size++] = crc;
		UARTTxInfo.usTxLen = size;

	} else {
		SetResponse_CmdErr(SLAVE_NG_HEADER);
	}

}
#if(BMS_DIAGNOSTIC_SUPPORT)
/****************************************************************************
FUNCTION	: vGuiIfCmd_DiagN_req
DESCRIPTION	: Safety Diagnostic check request
			:  0xA1, 0x0B, 0x04, <data1>, <data2>, <data3>, <crc8>
			:  OK: 0x52, 0x0B, <data len>, <data>, <crc8>
			:  NG: 0x62
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2022/06/24
*****************************************************************************/
static void vGuiIfCmd_DiagN_req(void)
{
	UCHAR size = UARTRxInfo.ucRxData[2u];
	UCHAR ucDiagNReq, ucReq_type;
	UCHAR ucStatus = DIAGN_ERROR_STS;
	bool bRet = false;
	ULONG ulDiagNDetail;
	ULONG ulResults = DIAGN_INVALID;
	UCHAR crc = 0u;

	#if(BMS_STANDBYMODE_SUPPORT)
	if(ucGet_BMICOpeMode() == (UCHAR)BMIC_OPEMODE_ACTIVE){
	#endif /* BMS_STANDBYMODE_SUPPORT */
		if ((UARTRxInfo.usRxLen == 10u) && (size == 0x06u)) {			/* selection of diagnostic check */
			if((getBMIC_Ctrl_Status()== BMIC_NORMAL)||(getBMIC_Ctrl_Status()== BMIC_DIAGNOSTIC)){
				ucDiagNReq = UARTRxInfo.ucRxData[3u]; 						/* get diagnostic request definition */
				ulDiagNDetail = (UARTRxInfo.ucRxData[7u]<<24u) + (UARTRxInfo.ucRxData[6u]<<16u) + (UARTRxInfo.ucRxData[5u]<<8u) + UARTRxInfo.ucRxData[4u];
				ucReq_type = UARTRxInfo.ucRxData[8u];
				ucStatus = ucGetDiag_sts();
				if((ucReq_type == DIAGN_NEW_REQ)&&(ucStatus == (UCHAR)eBMS_DIAGN_NONE)){
					bRet = bSetDiag_req(ucDiagNReq, ulDiagNDetail);
				}else{
					bRet = bValidateDiag_req(ucDiagNReq, ulDiagNDetail);
				}

				if(bRet){

					/* Prepare response data */
					size = 0u;
					UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;				/* Slave Header */
					UARTTxInfo.ucTxData[size++] = GUICMD_SAFETY_DIAGN_REQ;		/* CMD ID 	*/

					switch(ucReq_type){
						case (DIAGN_NEW_REQ):									/* New request */
							UARTTxInfo.ucTxData[size++] = 6u;					/* Data Len */
							UARTTxInfo.ucTxData[size++] = ucDiagNReq;
							UARTTxInfo.ucTxData[size++] = (UCHAR)(ulDiagNDetail & 0x000000FFu);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0x0000FF00u)>> 8u);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0x00FF0000u)>> 16u);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0xFF000000u)>> 24u);
							UARTTxInfo.ucTxData[size++] = 1u;					/* Start Acknowledge */
							vSetDiag_sts(eBMS_DIAGN_NONE);
							break;
						case (DIAGN_STS_REQ): 									/* Status request */
							UARTTxInfo.ucTxData[size++] = 6u;					/* Data Len */
							UARTTxInfo.ucTxData[size++] = ucDiagNReq;
							UARTTxInfo.ucTxData[size++] = (UCHAR)(ulDiagNDetail & 0x000000FFu);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0x0000FF00u)>> 8u);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0x00FF0000u)>> 16u);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0xFF000000u)>> 24u);
							UARTTxInfo.ucTxData[size++] = ucStatus;
							break;
						case (DIAGN_RESULT_REQ):								/* Result request */
							UARTTxInfo.ucTxData[size++] = 9u;					/* Data Len */
							UARTTxInfo.ucTxData[size++] = ucDiagNReq;
							UARTTxInfo.ucTxData[size++] = (UCHAR)(ulDiagNDetail & 0x000000FFu);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0x0000FF00u)>> 8u);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0x00FF0000u)>> 16u);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0xFF000000u)>> 24u);

							if(ucStatus == (UCHAR)eBMS_DIAGN_COMPLETED){		/* Diagnostic check status is completed */
								ulResults = ulGetDiag_result();
							}
							UARTTxInfo.ucTxData[size++] = (UCHAR)(ulResults & 0x000000FFu);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulResults & 0x0000FF00u)>> 8u);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulResults & 0x00FF0000u)>> 16u);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulResults & 0xFF000000u)>> 24u);
							UARTTxInfo.ucTxData[2] = size - 3u;					/* update actual data size */
							break;

						default:
							UARTTxInfo.ucTxData[size++] = 6u;					/* Data Len */
							UARTTxInfo.ucTxData[size++] = ucDiagNReq;
							UARTTxInfo.ucTxData[size++] = (UCHAR)(ulDiagNDetail & 0x000000FFu);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0x0000FF00u)>> 8u);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0x00FF0000u)>> 16u);
							UARTTxInfo.ucTxData[size++] = (UCHAR)((ulDiagNDetail & 0xFF000000u)>> 24u);
							UARTTxInfo.ucTxData[size++] = DIAGN_ERROR_STS;		/* Error status */
							break;
					}

					crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
					UARTTxInfo.ucTxData[size++] = crc;
					UARTTxInfo.usTxLen = size;
				}else{
					SetResponse_CmdErr(SLAVE_NG_HEADER);
				}
			}else{
				SetResponse_CmdErr(SLAVE_NG_HEADER);
			}
		} else {
			SetResponse_CmdErr(SLAVE_NG_HEADER);
		}
	#if(BMS_STANDBYMODE_SUPPORT)
	}else{
		SetResponse_CmdErr(SLAVE_NG_HEADER);
	}
	#endif /* BMS_STANDBYMODE_SUPPORT */
}
#endif /* BMS_DIAGNOSTIC_SUPPORT */

/****************************************************************************
FUNCTION	: vGuiIfCmd_CBL_req
DESCRIPTION	: Cellbalance request
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/05/08
*****************************************************************************/
static void vGuiIfCmd_CBL_req(void){
	UCHAR size = UARTRxInfo.ucRxData[2u];
	ULONG targetcell = 0x00000000ul;
	bool bRet = false;
	UCHAR crc = 0u;
	UCHAR cellbalON = 0u;
	UCHAR cellbalOFF = 0u;
	USHORT usErrResponse = 0u;		/* no error */

	if((UARTRxInfo.usRxLen == 5u) && (size == 0x1u)){
		if(UARTRxInfo.ucRxData[3u] == 0x00u){		/* Request current Cell balance setting */

			/* Prepare response data */
			size = 0;
			UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;				/* Slave Header */
			UARTTxInfo.ucTxData[size++] = GUICMD_CELL_BALANCE_REQ;		/* CMD ID 	*/
			UARTTxInfo.ucTxData[size++] = 0x05u;						/* Length 	*/
			targetcell = ulBMIC_GetCellbalanceReq();
			if(targetcell!= 0x00000000u){
				UARTTxInfo.ucTxData[size++] = ON;						/* Cell Balance is Enabled 	*/
			}else{
				UARTTxInfo.ucTxData[size++] = OFF;						/* Cell Balance is Disabled	*/
			}
			UARTTxInfo.ucTxData[size++] = (UCHAR)(targetcell & 0x000000FFu);			/* CB Cell 1~8 	*/
			UARTTxInfo.ucTxData[size++] = (UCHAR)((targetcell>>8u) & 0x000000FFu);	/* CB Cell 9~16 */
			UARTTxInfo.ucTxData[size++] = (UCHAR)((targetcell>>16u) & 0x000000FFu);	/* CB Cell 17~22 */
			vBMIC_GetCellbalanceONOFFtime(&cellbalON,&cellbalOFF);
#if(ESS_DEMO_CB)
			UARTTxInfo.ucTxData[size++] = ((cellbalON) + ((cellbalOFF)<<4));
#else
			UARTTxInfo.ucTxData[size++] = ((cellbalON/BMS_CTL_TM_100MSEC) + ((cellbalOFF/BMS_CTL_TM_100MSEC)<<4));
#endif	/* ESS_DEMO_CB */
			crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
			UARTTxInfo.ucTxData[size++] = crc;
			UARTTxInfo.usTxLen = size;

		}else{
			SetResponse_CmdErr(SLAVE_NG_HEADER);
		}
	}else
	if ((UARTRxInfo.usRxLen == 9u) && (size == 0x5u)) {
		if(UARTRxInfo.ucRxData[3u] == 0x01){		/* enable cell balance */
			#if(1)
			/* Bit0~2 - current fault(bit0: OCC, bit1: OCD, bit2:SCD, Bit 4~5 - voltage fault(bit4:UV, bit5:0V)
				Bit8~11 (bit8:UTC, bit9: UTD, bit10: OTC, bit11: OTD */
			/*usErrResponse = (USHORT)((ulBMIC_GetBatPackErr()>>4)&0x00000F37u);*/
			usErrResponse = ((USHORT)ulBMIC_GetBatPackErr() & /*MASK_TEMP_VOL_CUR_ERR*/MASK_TEMP_CUR_ERR) >>4u;
			if(usErrResponse != 0u){
				;
			}else
			#endif
#if(BMS_STANDBYMODE_SUPPORT)
			if((getBMIC_Ctrl_Status() == (UCHAR)BMIC_NORMAL)||(getBMIC_Ctrl_Status() == (UCHAR)BMIC_LOWPOWER)){
#endif /* BMS_STANDBYMODE_SUPPORT */
				targetcell = (BMICCellConf.ulCellPos & ((UARTRxInfo.ucRxData[6u]<<16u)+(UARTRxInfo.ucRxData[5u]<<8u)+UARTRxInfo.ucRxData[4u]));
#if(ESS_DEMO_CB)
				cellbalON = (UARTRxInfo.ucRxData[7u]&0x0Fu);
				cellbalOFF = ((UARTRxInfo.ucRxData[7u]&0xF0u)>>4u);
#else
				cellbalON = (UARTRxInfo.ucRxData[7u]&0x0Fu)*BMS_CTL_TM_100MSEC;
				cellbalOFF = ((UARTRxInfo.ucRxData[7u]&0xF0u)>>4u)*BMS_CTL_TM_100MSEC;
#endif	/* ESS_DEMO_CB */
				if(targetcell != 0x00000000u){		/* When enable CB, selected target must not 0 */
					bRet = true;
				}
#if(BMS_STANDBYMODE_SUPPORT)
			}else{
				usErrResponse |=0x0080u;
			}
#endif /* BMS_STANDBYMODE_SUPPORT */
		}else if(UARTRxInfo.ucRxData[3u] == 0x00u){	/* disable cell balance, targetcell remain init data 0 */
			bRet = true;
#if(ESS_DEMO_CB)
			cellbalON = (UARTRxInfo.ucRxData[7u]&0x0Fu);
			cellbalOFF = ((UARTRxInfo.ucRxData[7u]&0xF0u)>>4u);
#else
			cellbalON = (UARTRxInfo.ucRxData[7u]&0x0Fu)*BMS_CTL_TM_100MSEC;
			cellbalOFF = ((UARTRxInfo.ucRxData[7u]&0xF0u)>>4u)*BMS_CTL_TM_100MSEC;
#endif	/* ESS_DEMO_CB */
		}else{
			;
		}

		/* Prepare response data */
		size = 0u;
		UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;				/* Slave Header */
		UARTTxInfo.ucTxData[size++] = GUICMD_CELL_BALANCE_REQ;		/* CMD ID 	*/
		UARTTxInfo.ucTxData[size++] = 0x03u;							/* Length 	*/
		if(bRet == true){
			vBMIC_SetCellbalanceReq(targetcell,cellbalON,cellbalOFF);
			if(targetcell != 0x00000000u){
				if(ulBMIC_GetCellbalanceReq() != 0x00000000u){
					UARTTxInfo.ucTxData[size++] = OK;					/* Data1: OK 	*/
				}else{
					UARTTxInfo.ucTxData[size++] = NG;					/* Data1: NG eg. all cells select for CB not allowed */
				}
			}else{
				UARTTxInfo.ucTxData[size++] = OK;						/* Data1: OK 	*/
			}
		}else{
			UARTTxInfo.ucTxData[size++] = NG;							/* Data1: NG eg. no cells selected or BMIC fault detected or BMS not active mode	*/
		}
		UARTTxInfo.ucTxData[size++] = (UCHAR)(usErrResponse&0x00FFu);
		UARTTxInfo.ucTxData[size++] = (UCHAR)((usErrResponse&0xFF00u)>> 8u);

		crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
		UARTTxInfo.ucTxData[size++] = crc;
		UARTTxInfo.usTxLen = size;
	} else {
		SetResponse_CmdErr(SLAVE_NG_HEADER);
	}
}

/****************************************************************************
FUNCTION	: vGuiCmd_FwUpdReq
DESCRIPTION	: command to request MCU for Firmware Update
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		:
*****************************************************************************/
void vGuiCmd_FwUpdReq(void)
{
	USHORT size = (USHORT)UARTRxInfo.ucRxData[2u] | ((USHORT)UARTRxInfo.ucRxData[3u] << 8u) ;
	UCHAR crc = 0u;

	if ((UARTRxInfo.usRxLen == 7u) && (size == 0x2u)) {
		if((UARTRxInfo.ucRxData[4u]== 0x55) && (UARTRxInfo.ucRxData[5u] == 0xAA)){
			/* Prepare response data */
			size = 0u;
			UARTTxInfo.ucTxData[size++] = SLAVE_OK_HEADER;				/* Slave Header */
			UARTTxInfo.ucTxData[size++] = GUICMD_FW_UPD_REQ;			/* CMD ID 	*/
			UARTTxInfo.ucTxData[size++] = 0x02u;						/* Length (lower)	*/
			UARTTxInfo.ucTxData[size++] = 0x00u;						/* Length (upper)	*/
			UARTTxInfo.ucTxData[size++] = 0x00u;						/* Data 	*/
			UARTTxInfo.ucTxData[size++] = 0x00u;						/* Data 	*/

			crc = ucGetCRC8(UARTTxInfo.ucTxData, (USHORT)size);
			UARTTxInfo.ucTxData[size++] = crc;
			UARTTxInfo.usTxLen = size;

#if defined(SUPPORT_FWUPDATE)
			vSetUPD_PrepareReq();
#endif	/* SUPPORT_FWUPDATE */

		}else{
			SetResponse_CmdErr(SLAVE_NG_HEADER);
		}
	} else {
		SetResponse_CmdErr(SLAVE_NG_HEADER);
	}
}

/****************************************************************************
FUNCTION	: bCheckCRCError
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/10/29
*****************************************************************************/
bool bCheckCRCError(UCHAR *data)
{
	/*  <header>, <command>, <data size>, <data>, <crc8> */
	bool ret = false;
	USHORT size = 0u;
	if(data[1u] >= GUICMD_FW_UPD_REQ){
		size = (USHORT)data[2u] | ((USHORT)data[3u] << 8u);
		size = size + 4u;
	}else{
		size = (USHORT)data[2u] + 3u;
	}
	UCHAR crc = ucGetCRC8(data, size);
	if (crc == data[size]) {
		ret = true;
	}
	return ret;
}

/****************************************************************************
FUNCTION	: vRxCommandAna
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		: 2023/08/11
DATE		: 2019/10/29
*****************************************************************************/
static void vRxCommandAna(void)
{
	if ((UARTRxInfo.usRxLen >= 4u) && (UARTRxInfo.ucRxData[0u] == MASTER_HEADER)) {
		if (!bCheckCRCError(UARTRxInfo.ucRxData)) {
			SetResponse_CmdErr(SLAVE_NG_HEADER);
		} else {

			switch(UARTRxInfo.ucRxData[1u]){
				case GUICMD_ALL_REQ:
					vGuiIfCmd_GetAllInfo();
					break;

				case GUICMD_REGISTER_WRITE_REQ:
					vGuiIfCmd_RegisterWrite();
					break;

#if(BMS_FETSTATE_CTRL)
				case GUICMD_FET_CTL_ON_OFF_REQ:
					vGuiIfCmd_FETControl();
					break;

				case GUICMD_PROTECT_SETTING_REQ:
					vGuiIfCmd_ProtectSetting();
					break;
#endif	/* BMS_FETSTATE_CTRL */

				case GUICMD_FW_VER_REQ:
					vGuiIfCmd_GetVerInfo();
					break;

#if(BMS_DIAGNOSTIC_SUPPORT)
				case GUICMD_SAFETY_DIAGN_REQ:
					vGuiIfCmd_DiagN_req();
					break;
#endif	/* BMS_DIAGNOSTIC_SUPPORT */

				case GUICMD_CELL_BALANCE_REQ:
					vGuiIfCmd_CBL_req();
					break;

#if(BMS_TESTMODE)
				case GUICMD_TMODE_RW_REQ:
					vGuiIfCmd_TMODEReadWrite();
					break;
#endif	/* BMS_TESTMODE */

#if defined(SUPPORT_FWUPDATE)
				case GUICMD_FW_UPD_REQ:
					vGuiCmd_FwUpdReq();
					break;
#endif /* SUPPORT_FWUPDATE */
				default:
					SetResponse_CmdErr(SLAVE_NG_HEADER);
					break;

			}
		}

	} else {
		SetResponse_CmdErr(SLAVE_NG_HEADER);
	}

}


/****************************************************************************
FUNCTION	: SetResponse_CmdErr
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/10/19
*****************************************************************************/
void SetResponse_CmdErr(UCHAR tx0)
{
	UARTTxInfo.ucTxData[0u] = tx0;
	UARTTxInfo.usTxLen = 1u;
}

/****************************************************************************
FUNCTION	: SetResponse_nodata
DESCRIPTION	:
INPUT		: UCHAR tx0, UCHAR tx1
OUTPUT		:
UPDATE		:
DATE		: 2020/10/19
*****************************************************************************/
void SetResponse_nodata(UCHAR tx0, UCHAR tx1)
{
	UCHAR crc = 0u;
	UARTTxInfo.ucTxData[0u] = tx0;
	UARTTxInfo.ucTxData[1u] = tx1;
	UARTTxInfo.ucTxData[2u] = 0u;
	crc = ucGetCRC8(UARTTxInfo.ucTxData, 3u);
	UARTTxInfo.ucTxData[3u] = crc;
	UARTTxInfo.usTxLen = 4u;
}

/****************************************************************************
FUNCTION	: SetResponse_1data
DESCRIPTION	:
INPUT		: UCHAR tx0, UCHAR tx1, UCHAR data
OUTPUT		:
UPDATE		:
DATE		: 2020/10/19
*****************************************************************************/
void SetResponse_1data(UCHAR tx0, UCHAR tx1, UCHAR data)
{
	UCHAR crc = 0u;
	UARTTxInfo.ucTxData[0u] = tx0;
	UARTTxInfo.ucTxData[1u] = tx1;
	UARTTxInfo.ucTxData[2u] = 1u;						/* len: 1 */
	UARTTxInfo.ucTxData[3u] = data;
	crc = ucGetCRC8(UARTTxInfo.ucTxData, 4u);
	UARTTxInfo.ucTxData[4u] = crc;
	UARTTxInfo.usTxLen = 5u;
}



/****************************************************************************
FUNCTION	: vClearTxData
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/10/29
*****************************************************************************/
void vClearTxData(void)
{
	UARTTxInfo.usTxLen = 0u;
	UARTTxInfo.usTxCnt = 0u;
	UARTTxInfo.ucTxInProcess = 0u;
}


/****************************************************************************
FUNCTION	: vSendResponse
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/10/19
*****************************************************************************/
static void vSendResponse(void)
{
#if(PCGUI_IF_USB)
	UARTTxInfo.ucTxInProcess = 1u;
	for(UARTTxInfo.usTxCnt = 0u; UARTTxInfo.usTxCnt < UARTTxInfo.usTxLen; UARTTxInfo.usTxCnt++){

		VCOM_USBDTransferOutData(UARTTxInfo.ucTxData[UARTTxInfo.usTxCnt]);
	}

#else

	UARTTxInfo.ucTxInProcess = 1u;

	#if(PCGUI_UART_TX_PDMA_USED)

	/* Select basic mode	*/
	PDMA_SetTransferMode(PDMA,PCGUI_UART_TX_PDMA_CH, PDMA_UART3_TX, 0, 0);
	/* Set data width and transfer count	*/
	PDMA_SetTransferCnt(PDMA,(ULONG)PCGUI_UART_TX_PDMA_CH, PDMA_WIDTH_8, (ULONG)UARTTxInfo.usTxLen);
	/* Set PDMA Transfer Address */
	PDMA_SetTransferAddr(PDMA,PCGUI_UART_TX_PDMA_CH, ((uint32_t) (&UARTTxInfo.ucTxData[0])), PDMA_SAR_INC, UART3_BASE, PDMA_DAR_FIX);
	/* Select Single Request */
	PDMA_SetBurstType(PDMA,PCGUI_UART_TX_PDMA_CH, PDMA_REQ_SINGLE, 0);

	/* Enable UART3 TXPDMAEN */
	UART3->INTEN |= UART_INTEN_TXPDMAEN_Msk;

	#else	/* PCGUI_UART_TX_PDMA_USED */

	UART_WRITE(UART3, UARTTxInfo.ucTxData[0]);
	UART_EnableInt(UART3, UART_INTEN_THREIEN_Msk);
	UARTTxInfo.usTxCnt ++;

	#endif	/* PCGUI_UART_TX_PDMA_USED */

#endif	/* PCGUI_IF_USB */
}


#if(PCGUI_IF_USB)
#else
#if(!PCGUI_UART_TX_PDMA_USED)
/****************************************************************************
FUNCTION	: bGetUartTxData
DESCRIPTION	:
INPUT		: UCHAR *tx_data
OUTPUT		:
UPDATE		:
DATE		: 2020/10/19
*****************************************************************************/
bool bGetUartTxData(UCHAR *tx_data)
{
	bool bRet = false;
	if(UARTTxInfo.usTxCnt < UARTTxInfo.usTxLen){
		bRet = true;
		*tx_data = UARTTxInfo.ucTxData[UARTTxInfo.usTxCnt];
		UARTTxInfo.usTxCnt ++;
	}else{
		UARTTxInfo.ucTxInProcess = 0u;
		UART_DisableInt(UART3, UART_INTEN_THREIEN_Msk);
	}
	return bRet;
}
#endif	/* !PCGUI_UART_TX_PDMA_USED */
#endif /* PCGUI_IF_USB */

/****************************************************************************
FUNCTION	: InitCOMMain
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/10/29
*****************************************************************************/
void vTskInit_gui_if(void)
{
	vClearCmdRx();
	vClearTxData();
#if(!PCGUI_IF_USB)
	vGui_if_uart_init();
#endif	/* !PCGUI_IF_USB */
}


/****************************************************************************
FUNCTION	: Main
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/10/29
*****************************************************************************/
void vTask_gui_if(void)
{
	if ((UARTRxInfo.ucRxNewCmd) 						/* Gui if new cmd received ? */
		&& (!UARTTxInfo.ucTxInProcess)					/* Not in Tx? */
	){
		vClearTxData();
		vRxCommandAna();			/*  analyze command */
		vSendResponse();			/*  return UART Tx */
		vClearCmdRx();
	}
}

