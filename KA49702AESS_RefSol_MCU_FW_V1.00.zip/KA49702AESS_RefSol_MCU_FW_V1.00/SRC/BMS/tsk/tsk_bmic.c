/****************************************************************************
#ifdef DOC
File Name		:tsk_bmic.c
Description		:
Remark			:
Date			:2020/10/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/
#include "NuMicro.h"
#include <stdbool.h>
#include "sys_type.h"
#include "main.h"
#include "drv_bmic.h"
#if(BMIC_IC_TYPE == BMIC_KA49702A)
#include "bmic_reg_702.h"
#else
#include "bmic_reg_701.h"
#endif /* BMIC_KA49702A */
#include "drv_timer.h"
#include "tsk_bmic.h"

/****************************************************************************
 define macro
*****************************************************************************/


/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/
typedef struct {
	USHORT	usMinCellVolLife_mV;				/* Pack lowest cell voltage (Life) 			*/
	USHORT	usMaxCellVolLife_mV;				/* Pack highest cell voltage (Life)			*/
	USHORT	usMinPackCurLife_10mA_300A;			/* Pack minimum current (fast speed) in 10mA with 300A offset (Life) */
	USHORT	usMaxPackCurLife_10mA_300A;			/* Pack maximum current (fast speed) in 10mA with 300A offset (Life) */
}TLifeBatInfo;

/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/

/****************************************************************************
 Variable declaration
*****************************************************************************/
static TLifeBatInfo 	LifeBatInfo;
static UCHAR ucBMIC_status1;
static UCHAR ucBMIC_status2;

/****************************************************************************
 Prototype declaration
*****************************************************************************/
void vTsk_bmic(void);
void vUpdateBMIC_Status(void);
#if(0/*BMS_STANDBYMODE_SUPPORT*/)
static USHORT usChk_LP_OPMode_intmsel(void);
#endif	/* BMS_STANDBYMODE_SUPPORT */
/****************************************************************************
FUNCTION	: UpdateLifeBatInfo
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2019/10/29
*****************************************************************************/
static void UpdateLifeBatInfo(void)
{
	if (BMIC_Info.BMICMeasured) {
		ULONG ultemp = BMIC_Info.ulBatPackMinBlkVol_uV;

		ultemp /= 1000u;
		if (ultemp < LifeBatInfo.usMinCellVolLife_mV) {
			LifeBatInfo.usMinCellVolLife_mV = (USHORT)ultemp;
		}

		ultemp = BMIC_Info.ulBatPackMaxBlkVol_uV;
		ultemp /= 1000u;
		if (ultemp > LifeBatInfo.usMaxCellVolLife_mV) {
			LifeBatInfo.usMaxCellVolLife_mV = (USHORT)ultemp;
		}

		if (BMIC_Info.usBatPackCur_10mA_300A < LifeBatInfo.usMinPackCurLife_10mA_300A) {
			LifeBatInfo.usMinPackCurLife_10mA_300A = BMIC_Info.usBatPackCur_10mA_300A;
		}
		if (BMIC_Info.usBatPackCur_10mA_300A > LifeBatInfo.usMaxPackCurLife_10mA_300A) {
			LifeBatInfo.usMaxPackCurLife_10mA_300A = BMIC_Info.usBatPackCur_10mA_300A;
		}
	}
}


/****************************************************************************
FUNCTION	: vTskInit_bmic
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		:
*****************************************************************************/
void vTskInit_bmic(void)
{
	LifeBatInfo.usMinCellVolLife_mV = 0xFFFFu;
	LifeBatInfo.usMaxCellVolLife_mV = 0u;
	LifeBatInfo.usMinPackCurLife_10mA_300A = 0xFFFFu;
	LifeBatInfo.usMaxPackCurLife_10mA_300A = 0u;

	vBMIC_InitParams();
}



/****************************************************************************
FUNCTION	: vTsk_bmic
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		:
*****************************************************************************/
void vTsk_bmic(void)
{
	UCHAR status;
#if(0/*BMS_STANDBYMODE_SUPPORT*/)
/*	static USHORT usActiveComm_cnt = 0; */
	USHORT usIntm_count = 0;
#endif	/* BMS_STANDBYMODE_SUPPORT */
	vBMIC_Clear_Spi_Err_counter();
	status = getBMIC_Ctrl_Status();
	switch (status) {
		case (UCHAR)BMIC_STARTUP:
			vBMIC_Ctrl_Startup();
			break;
#if(BMS_STANDBYMODE_SUPPORT)
		case (UCHAR)BMIC_LOWPOWER:
			vBMIC_Ctrl_RetToActive();
			if(getBMIC_Ctrl_Status() == (UCHAR)BMIC_NORMAL){
				vBMIC_ChgOpeMode((UCHAR)BMIC_OPEMODE_ACTIVE);
			}
#if(0)	/* LP mode continue SPI to get ADIL log */
			usIntm_count = usChk_LP_OPMode_intmsel();
			usActiveComm_cnt ++;
			if(usActiveComm_cnt >= usIntm_count){
				usActiveComm_cnt = 0;
			}else{
				break;
			}
#endif
#endif	/* BMS_STANDBYMODE_SUPPORT */
		case (UCHAR)BMIC_NORMAL:
			vBMIC_Ctrl_Normal();
			break;
		case (UCHAR)BMIC_SPIERR:
			vBMIC_Ctrl_SpiErr();
			break;
		case (UCHAR)BMIC_RESTART:
			vBMIC_Ctrl_Restart();
			break;

#if(BMS_STANDBYMODE_SUPPORT)
		case (UCHAR)BMIC_STANDBY:
			vBMIC_Ctrl_RetToActive();
			if(getBMIC_Ctrl_Status() == (UCHAR)BMIC_NORMAL){
				vBMIC_ChgOpeMode((UCHAR)BMIC_OPEMODE_ACTIVE);
			}
			break;
		case (UCHAR)BMIC_SLEEP:
			vBMIC_Ctrl_WakeupWait();
			if(getBMIC_Ctrl_Status() == (UCHAR)BMIC_NORMAL){
				vBMIC_ChgOpeMode((UCHAR)BMIC_OPEMODE_ACTIVE);
			}
			break;
#endif	/* BMS_STANDBYMODE_SUPPORT */

		case (UCHAR)BMIC_SHUTDOWN:
#if(BMS_STANDBYMODE_SUPPORT)
			vBMIC_Ctrl_ShdnWakeupWait();
#else
			vBMIC_Ctrl_Shutdown();
#endif
			break;
#if(BMS_DIAGNOSTIC_SUPPORT)
		case (UCHAR)BMIC_DIAGNOSTIC:
			vBMIC_Ctrl_Diagnostic();
			break;
#endif /* BMS_DIAGNOSTIC_SUPPORT */
	}
	UpdateLifeBatInfo();
#if(BMS_STANDBYMODE_SUPPORT)
	vBMIC_SetOpeModeExtChk();
#endif	/* BMS_STANDBYMODE_SUPPORT */
	vUpdateBMIC_Status();
}


/****************************************************************************
FUNCTION	: vUpdateBMIC_Status
DESCRIPTION	: Update ucBMIC_status1 & ucBMIC_status2 for LED display & GUI
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2022/06/22
*****************************************************************************/
void vUpdateBMIC_Status(void)
{
	UCHAR status;
	USHORT regdata = 0u;

	ucBMIC_status1 = 0u;
	ucBMIC_status2 = 0u;

	status = getBMIC_Ctrl_Status();

	switch(status){
		case (UCHAR)BMIC_NORMAL:
#if(BMS_STANDBYMODE_SUPPORT)
		case (UCHAR)BMIC_LOWPOWER:
		case (UCHAR)BMIC_STANDBY:
		case (UCHAR)BMIC_SLEEP:	/* Sleep mode */
#endif	/* BMS_STANDBYMODE_SUPPORT */
			ucBMIC_status1 |= BMIC_OPE_STATUS_NORMAL;
			if(bBMIC_ChkCellbalance()){
				ucBMIC_status1 |= BMIC_OPE_CELL_BALANCE;
			}

#if(BMIC_IC_TYPE == BMIC_KA49702A)
			regdata = usBMICReferRegData(MODESTAT_ADDR);			/* check STAT1 data */
#else
			regdata = usBMICReferRegData(STAT1_ADDR);			/* check STAT1 data */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
			if(regdata & FDRV_DIS_ST_MASK){	/* bp11 - FDRV_DIS_ST */
				ucBMIC_status1 |= BMIC_OPE_FET_DIS_ON;
			}

			if(regdata & FDRV_CHG_ST_MASK){	/* bp10 - FDRV_CHG_ST */
				ucBMIC_status1 |= BMIC_OPE_FET_CHG_ON;
			}
			ucBMIC_status1 |= ucGetBMIC_SpiErrDetail() & 0x0Fu;
			break;
		default:
			ucBMIC_status1 = ucGetBMIC_SpiErrDetail() & 0x0Fu;
			if(bBMIC_ChkSpiMiso()){
				ucBMIC_status1 |= BMIC_SPI_STATUS_WAKEUP_ERR;
			}
			break;
	}
}


/****************************************************************************
FUNCTION	: ucGetBMIC_status1
DESCRIPTION	:
INPUT		:
OUTPUT		: UCHAR
UPDATE		:
DATE		:2020/11/09
*****************************************************************************/
UCHAR	ucGetBMIC_status1(void)
{
	return(ucBMIC_status1);
}


/****************************************************************************
FUNCTION	: ucGetBMIC_status2
DESCRIPTION	:
INPUT		:
OUTPUT		: UCHAR
UPDATE		:
DATE		:2020/11/09
*****************************************************************************/
UCHAR	ucGetBMIC_status2(void)
{
	return(ucBMIC_status2);
}

#if(BMS_STANDBYMODE_SUPPORT)
/****************************************************************************
FUNCTION	: ucCheckOpeModeComm
DESCRIPTION	: check communication to BMIC is ON or OFF in current operating mode
INPUT		: UCHAR CurOpeMode, UCHAR register_adr, USHORT register_data
OUTPUT		: ON -> 1, OFF -> 0
UPDATE		:
DATE		: 2023/05/10
*****************************************************************************/
UCHAR ucCheckOpeModeComm(UCHAR CurOpeMode, UCHAR register_adr, USHORT register_data){

	UCHAR Comm_flg = ON;

	if(CurOpeMode == (UCHAR)BMIC_OPEMODE_SLEEP){
		Comm_flg = OFF;
	}

	if(CurOpeMode == BMIC_OPEMODE_STANDBY){
		if((register_adr == PWR_CTRL_ADDR)&&((register_data & MSET_MODE_MASK) == 0u)){ /* request to return from standby to active? */
			;
		}else{
			Comm_flg = OFF;
		}
	}

	return(Comm_flg);

}

/****************************************************************************
FUNCTION	: vChangeOpeModeReq
DESCRIPTION	: check for permission to change mode
INPUT		: UCHAR CurOpeMode, USHORT register_data
OUTPUT		: None
UPDATE		:
DATE		: 2023/05/10
*****************************************************************************/
void vChangeOpeModeReq(USHORT CurOpeMode, USHORT* register_data){

	USHORT ChgOpeModereq = (*register_data & MSET_MODE_MASK);
	USHORT data = *register_data;
	UCHAR ucChgOpeMode = 0xFF;

	if((data & MSET_SHDN) == MSET_SHDN){					/* BMIC shutdown have highest priority over LowPwr/STB/Sleep */
		ucChgOpeMode = BMIC_OPEMODE_SHUTDOWN;
		*register_data = data & ~MSET_MODE_MASK;
		*register_data |= usBMICReferRegData(PWR_CTRL_ADDR) & MSET_MODE_MASK;
	}else{
		if(ChgOpeModereq !=0){
			if(CurOpeMode == (UCHAR)BMIC_OPEMODE_ACTIVE){

				/* in event when more than 1 mode are written as "1" at the same time, higher priority
				is given to Low power mode followed by STB mode and then Sleep mode */
				if((ChgOpeModereq & MSET_LP) == MSET_LP){
					ucChgOpeMode = (UCHAR)BMIC_OPEMODE_LOWPOWER;
				}else if((ChgOpeModereq & MSET_STB) == MSET_STB){
					ucChgOpeMode = (UCHAR)BMIC_OPEMODE_STANDBY;
				}else{
					ucChgOpeMode = (UCHAR)BMIC_OPEMODE_SLEEP;
				}
				*register_data = data & ~MSET_MODE_MASK;

			}
		}else{
			if(CurOpeMode != (UCHAR)BMIC_OPEMODE_ACTIVE){
				ucChgOpeMode = (UCHAR)BMIC_OPEMODE_ACTIVE;
			}
		}
	}
	if(ucChgOpeMode!=0xFF){
		vBMIC_ChgOpeMode(ucChgOpeMode);
		vBMIC_Set_OpeMode_Req(1u);
	}
}

#if(0)
/****************************************************************************
FUNCTION	: usChk_LP_OPMode_intmsel
DESCRIPTION	: during Lower Power mode, check Intermittent mode selection to determine
              when MCU to SPI comm with BMIC
INPUT		: None
OUTPUT		: USHORT
UPDATE		: 2023/11/30
DATE		: 2023/11/02
*****************************************************************************/
USHORT usChk_LP_OPMode_intmsel(void){

	USHORT usregdata = usBMICReferRegData(PWR_CTRL_ADDR);
	USHORT usIntm_count;

	switch(usregdata&INTM_TIM2_MASK){
		case(INTM_TIM2_1S):
			usIntm_count = BMS_CTL_TM_1SEC;
			break;
		case(INTM_TIM2_2S):
			usIntm_count = BMS_CTL_TM_2SEC;
			break;
		case(INTM_TIM2_4S):
			usIntm_count = BMS_CTL_TM_4SEC;
			break;
		case(INTM_TIM2_8S):
			usIntm_count = BMS_CTL_TM_8SEC;
			break;
	}

	return(usIntm_count);
}
#endif /* #if(0) */
#endif /* BMS_STANDBYMODE_SUPPORT */
