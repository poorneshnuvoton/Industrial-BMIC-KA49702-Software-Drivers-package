/****************************************************************************
#ifdef DOC
File Name		:tsk_sys.c
Description		:
Remark			:
Date			:2020/10/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/
#include "NuMicro.h"
#include <stdbool.h>
#include "sys_type.h"
#include "main.h"
#include "drv_timer.h"
#include "drv_bmic.h"
#include "tsk_bmic.h"
#include "portio.h"
#if(BMIC_IC_TYPE == BMIC_KA49702A)
#include "bmic_reg_702.h"
#else
#include "bmic_reg_701.h"
#endif /* BMIC_KA49702A */

#if(BMS_FETSTATE_CTRL)
/****************************************************************************
 define macro
*****************************************************************************/
/* =====Protection Option Bits Definition Start===== */
/*#define						((USHORT)(0x0001u))*/ /* bp0: Reserved */
/*#define						((USHORT)(0x0002u))*/ /* bp1: Reserved */
/*#define						((USHORT)(0x0004u))*/ /* bp2: Reserved */
/*#define						((USHORT)(0x0008u))*/ /* bp3: Reserved */
#define	PROTECT_HOTC			((USHORT)(0x0010u))	/* bp4: Hard Over Temperature Charge Protection 0 - OFF, 1 - ON */
#define	PROTECT_HOTD			((USHORT)(0x0020u))	/* bp5: Hard Over Temperature Discharge Protection 0 - OFF, 1 - ON */
#define	PROTECT_HUTC			((USHORT)(0x0040u))	/* bp6: Hard Under Temperature Charge Protection 0 -OFF, 1 - ON */
#define	PROTECT_HUTD			((USHORT)(0x0080u))	/* bp7: Hard Under Temperature Discharge Protection 0 - OFF, 1 - ON */
/*#define						((USHORT)(0x0100u))*/ /* bp8: Reserved */
/*#define						((USHORT)(0x0200u))*/ /* bp9: Reserved */
/*#define						((USHORT)(0x0400u))*/ /* bp10: Reserved */
/*#define	PROTECT_HOV			((USHORT)(0x0800u))*/ /* bp11: Hard Over Voltage Protection 0 - OFF, 1 - ON *//* Reserved, HOV protection always enabled */
/*#define	PROTECT_HUV			((USHORT)(0x1000u))*/ /* bp12: Hard Under Voltage Protection 0 - OFF, 1 - ON *//* Reserved, HUV protection always enabled */
/*#define	PROTECT_HOCC		((USHORT)(0x2000u))*/ /* bp13: Hard Over Current Charge Protection 0 - OFF, 1 - ON *//* Reserved, HOCC proteciton always enabled */
/*#define	PROTECT_HOCD		((USHORT)(0x4000u))*/ /* bp14: Hard Over Current Discharge Protection 0 - OFF, 1 - ON *//* Reserved, HOCD protection always enabled */
/*#define	PROTECT_HSCD		((USHORT)(0x8000u))*/ /* bp15: Hard Short Circuit Discharge Current Protection 0 - OFF< 1 - ON *//* Reserved, HSCD protection always enabled */
#define	PROTECT_HOTUT		(PROTECT_HOTC | PROTECT_HOTD | PROTECT_HUTC | PROTECT_HUTD)
/* =====Protection Option Bits Definition End===== */

/* =====BMS Error (usBMS_ErrorStatus) Bits Definition Start===== */
/*#define						((USHORT)(0x0001u))*/ /* bp0: Reserved */
/*#define						((USHORT)(0x0002u))*/ /* bp1: Reserved */
/*#define						((USHORT)(0x0004u))*/ /* bp2: Reserved */
/*#define						((USHORT)(0x0008u))*/ /* bp3: Reserved */
#define	ERR_HOTC				((USHORT)(0x0010u))	/* bp4: Hard Over Temperature Charge Error */
#define	ERR_HOTD				((USHORT)(0x0020u))	/* bp5: Hard Over Temperature Discharge Error */
#define	ERR_HUTC				((USHORT)(0x0040u))	/* bp6: Hard Under Temperature Charge Error */
#define	ERR_HUTD				((USHORT)(0x0080u))	/* bp7: Hard Under Temperature Discharge Error */
/*#define						((USHORT)(0x0100u))*/ /* bp8: Reserved */
/*#define						((USHORT)(0x0200u))*/ /* bp9: Reserved */
/*#define						((USHORT)(0x0400u))*/ /* bp10: Reserved */
#define	ERR_HOV					((USHORT)(0x0800u))	/* bp11: Hard Over Voltage Error */
#define	ERR_HUV					((USHORT)(0x1000u))	/* bp12: Hard Under Voltage Error */
#define	ERR_HOCC				((USHORT)(0x2000u))	/* bp13: Hard Over Charge Current Error */
#define	ERR_HOCD				((USHORT)(0x4000u))	/* bp14: Hard Over Current Discharge Error */
#define	ERR_HSCD				((USHORT)(0x8000u))	/* bp15: Hard Short Circuit Detection at Discharge Error */

#define	ERR_TEMPERATURE			(ERR_HOTC | ERR_HOTD | ERR_HUTC | ERR_HUTD)
#define	ERR_CURRENT				(ERR_HOCC | ERR_HOCD | ERR_HSCD)
#define	ERR_CHARGE				(ERR_HOCC | ERR_HOV | ERR_HOTC | ERR_HUTC)					/* Errors will turn off CHG FET */
#define	ERR_DISCHARGE			(ERR_HOCD | ERR_HSCD | ERR_HUV | ERR_HOTD | ERR_HUTD)		/* Errors will turn off DIS FET */
/* =====BMS Error (usBMS_ErrorStatus) Bits Definition End===== */

/* =====BMS Error (usBMS_ShutdownErrSts) Bits Definition Start===== */
#define	ERR_SHDN_SVT			((USHORT)(0x0001u))	/* bp0: Shutdown Voltage Error */
#define	ERR_SHDN_PFOV			((USHORT)(0x0002u))	/* bp1: Permanent Fail Over Voltage Error */
/* =====BMS Error (usBMS_ShutdownErrSts) Bits Definition End===== */

#define SETTING_RANGE_CHECK(th, min, max)	if(th < min){\
												th = min;\
											}else if(th > max){\
												th = max;\
											}else{\
												;\
											}



/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/
typedef struct{
	USHORT	usPROTECT_OptionBits;		/* Protection Options Bits */

	USHORT	usReserved_01;				/* Reserved */
	USHORT	usReserved_02;				/* Reserved */
	USHORT	usPFOV_THmV;				/* Permanent Fail Over Voltage Threshold in mV */
	USHORT	usReserved_03;				/* Reserved */
	USHORT	usSVDET_DLYms;				/* Soft Voltage Detection Delay in ms for SOV/SOVR/PFOV/SUV/SVT */
	USHORT	usHOV_THmV;					/* Hard Over Voltage Threshold in mV */
	USHORT	usHUV_THmV;					/* Hard Under Voltage Threshold in mV */
	USHORT	usSVT_THmV;					/* Shutdown Voltage Threshod in mV */

	USHORT	usShunt_uOhm;				/* Current sensing resistor value in uOhm */

	USHORT	usReserved_04;				/* Reserved */
	USHORT	usReserved_05;				/* Reserved */
	USHORT	usReserved_06;				/* Reserved */
	USHORT	usReserved_07;				/* Reserved */
	USHORT	usHOCC_THA;					/* Hard Over Current Charge Threshold in A */
	USHORT	usHOCD_THA;					/* Hard Over Current Discharge Threshold in A */
	USHORT	usHSCD_THA;					/* Hard Short Circuit Detection at Discharge Threshold in A */

	SHORT	sHOTC1_TH01Cdeg;			/* Hard Over Temperature Charge Threshold for Group1 in 0.1Cdegree */
	SHORT	sHOTC2_TH01Cdeg;			/* Hard Over Temperature Charge Threshold for Group2 in 0.1Cdegree */
	SHORT	sHUTC1_TH01Cdeg;			/* Hard Under Temperature Charge Threshold for Group1 in 0.1Cdegree */
	SHORT	sHUTC2_TH01Cdeg;			/* Hard Under Temperature Charge Threshold for Group2 in 0.1Cdegree */
	SHORT	sHOTD1_TH01Cdeg;			/* Hard Over Temperature Discharge Threshold for Group1 in 0.1Cdegree */
	SHORT	sHOTD2_TH01Cdeg;			/* Hard Over Temperature Discharge Threshold for Group2 in 0.1Cdegree */
	SHORT	sHUTD1_TH01Cdeg;			/* Hard Under Temperature Disharge Threshold for Group1 in 0.1Cdegree */
	SHORT	sHUTD2_TH01Cdeg;			/* Hard Under Temperature Disharge Threshold for Group2 in 0.1Cdegree */
	USHORT	usReserved_08;				/* Reserved */

	USHORT	usFCV_THmV;					/* Full Charge Voltage Threshold in mV */
	USHORT	usOTUT_ITHmA;				/* Current Threshold to switch between Charging and Discharging in mA */
	USHORT	usReserved_09;				/* Reserved */
	USHORT	usDSV_THmV;					/* Discharge Starting Voltage Threshold in mA */

}TBMS_PROTECT_SETTING;

typedef	struct{
	USHORT	usMin;
	USHORT	usMax;
}TBMS_PROTECT_RANGE1;

typedef struct{
	SHORT	sMin;
	SHORT	sMax;
}TBMS_PROTECT_RANGE2;

/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/
typedef enum{
	BMS_FETMODE_AUTO_SHDN = 0u,				/* 0x00 Shutdown mode */
	BMS_FETMODE_AUTO_STARTING,				/* 0x01 Starting mode */
	BMS_FETMODE_AUTO_NORMAL,				/* 0x02 Normal mode */
	BMS_FETMODE_AUTO_FAILURE,				/* 0x03 Failure mode */
	BMS_FETMODE_MANUAL						/* 0x04 Manual mode */
}BMS_FETMODE;

typedef enum{
	BMS_FETSTATE_SHDN = 0u,					/* 0x00 Shutdown state */
	BMS_FETSTATE_STB,						/* 0x01 Standby state */
	BMS_FETSTATE_PRECHARGE,					/* 0x02 Precharge state */
	BMS_FETSTATE_DISCHARGING,				/* 0x03 Discharge state */
	BMS_FETSTATE_CHARGING,					/* 0x04 Charge state */
	BMS_FETSTATE_CHG_COMPLETE,				/* 0x05 Charge complete state */

	BMS_FETSTATE_TEMP_FAILURE1,				/* 0x06 Temporary failure 1 (UV or OCD/SCD or OTD/UTD error) */
	BMS_FETSTATE_TEMP_FAILURE2,				/* 0x07 Temporary failure 2 (OV or OCC or OTC/UTC error) */
	BMS_FETSTATE_TEMP_FAILURE3,				/* 0x08 Temporary failure 3 (UV&OCC or OV&OCD/SCD or OT/UT error) */
	BMS_FETSTATE_PERM_FAILURE,				/* 0x09 Permanent failure (PFOV or PFCHT error) */

	BMS_FETSTATE_MANUAL = 0xFFu				/* 0xFF Manual state */
}BMS_FETSTATE;

/****************************************************************************
 Variable declaration
*****************************************************************************/
TBMS_PROTECT_SETTING BMS_ProtectSetting = {
#if(ESS_DEMO_EVB)
	(PROTECT_HOTC|PROTECT_HOTD),	/* HOTD, HOTC default ON */
#else
	0x0000u,				/* usPROTECT_OptionBits	default:  */
#endif	/* ESS_DEMO_EVB */

	0u,						/* Reserved		*/
	0u,                 	/* Reserved		*/
	4500u,                  /* usPFOV_THmV		default: 4500mV		*/
	0u,                  	/* Reserved		*/
	500u,                   /* usSVDET_DLYms	default: 500ms		*/
	4200u,                  /* usHOV_THmV		default: 4200mV		*/
#if(ESS_DEMO_EVB)
	2000u,                  /* usHUV_THmV		default: 2000mV		*/
#else
	1800u,                  /* usHUV_THmV		default: 1800mV		*/
#endif	/* ESS_DEMO_EVB */
	1000u,                  /* usSVT_THmV		default: 1000mV		*/

	1000u,					/* usShunt_uOhm		default: 1000uOhm (1mOhm)	*/

	0u,						/* Reserved	*/
	0u,                     /* Reserved	*/
	0u,                   	/* Reserved */
	0u,                   	/* Reserved */
#if(ESS_DEMO_EVB)
	20u,                    /* usHOCC_THA		default: 20A (20000mA)	*/
	60u,                    /* usHOCD_THA		default: 60A (60000mA)	*/
	260u,                   /* usHSCD_THA		default: 260A (260000mA)	*/
#else
	10u,                    /* usHOCC_THA		default: 10A (10000mA)	*/
	20u,                    /* usHOCD_THA		default: 20A (20000mA)	*/
	40u,                    /* usHSCD_THA		default: 40A (40000mA)	*/
#endif	/* ESS_DEMO_EVB */

#if(ESS_DEMO_EVB)
	600,					/* sHOTC1_TH01Cdeg	default: 600 .1Cdeg		*/
	600,                    /* sHOTC2_TH01Cdeg	default: 600 .1Cdeg		*/
	-100,                   /* sHUTC1_TH01Cdeg	default: -100 .1Cdeg	*/
	-100,                   /* sHUTC2_TH01Cdeg  default: -100 .1Cdeg	*/
	600,                    /* sHOTD1_TH01Cdeg  default: 600 .1Cdeg		*/
	600,                    /* sHOTD2_TH01Cdeg	default: 600 .1Cdeg		*/
	-100,                   /* sHUTD1_TH01Cdeg  default: -100 .1Cdeg	*/
	-100,                   /* sHUTD2_TH01Cdeg	default: -100 .1Cdeg	*/
#else
	800,					/* sHOTC1_TH01Cdeg	default: 800 .1Cdeg		*/
	800,                    /* sHOTC2_TH01Cdeg	default: 800 .1Cdeg		*/
	-100,                   /* sHUTC1_TH01Cdeg	default: -100 .1Cdeg	*/
	-100,                   /* sHUTC2_TH01Cdeg  default: -100 .1Cdeg	*/
	800,                    /* sHOTD1_TH01Cdeg  default: 800 .1Cdeg		*/
	800,                    /* sHOTD2_TH01Cdeg	default: 800 .1Cdeg		*/
	-100,                   /* sHUTD1_TH01Cdeg  default: -100 .1Cdeg	*/
	-100,                   /* sHUTD2_TH01Cdeg	default: -100 .1Cdeg	*/
#endif	/* ESS_DEMO_EVB */

	0u,                   	/* Reserved	*/

	3800u,					/* usFCV_THmV		default: 3800mV		*/
	1400u,          		/* usOTUT_ITHmA		default: 175mA * 8 = 1400mA */
	0u,                    	/* Reesrved	*/
#if(ESS_DEMO_EVB)
	2000u                   /* usDSV_THmV		default: 2000mV		*/
#else
	3100u                   /* usDSV_THmV		default: 3100mV		*/
#endif	/* ESS_DEMO_EVB */
};

/* voltage protection threshold min/max */
const TBMS_PROTECT_RANGE1	cBMS_HOV_THRange = {4050u, 4250u};		/* HOV threshold range: 4050mV ~ 4250mV */
const TBMS_PROTECT_RANGE1	cBMS_PFOV_THRange = {4300u, 4500u};		/* PFOV threshold range: 4300mV ~ 4500mV */
const TBMS_PROTECT_RANGE1	cBMS_FCV_THRange = {3200u, 4000u};		/* FCV threshold range: 3200mV ~ 4000mV */
#if(ESS_DEMO_EVB)
const TBMS_PROTECT_RANGE1	cBMS_DSV_THRange = {2000u, 3100u};		/* DSV threshold range: 2000mV ~ 3100mV */
const TBMS_PROTECT_RANGE1	cBMS_HUV_THRange = {1200u, 2000u};		/* HUV threshold range: 1200mV ~ 2000mV */
#else
const TBMS_PROTECT_RANGE1	cBMS_DSV_THRange = {2600u, 3100u};		/* DSV threshold range: 2600mV ~ 3100mV */
const TBMS_PROTECT_RANGE1	cBMS_HUV_THRange = {1200u, 1800u};		/* HUV threshold range: 1200mV ~ 1800mV */
#endif	/* ESS_DEMO_EVB */
const TBMS_PROTECT_RANGE1	cBMS_SVT_THRange = {800u, 1000u};		/* SVT threshold range: 800mV 	 1000mV */

/* current protection threshold min/max */
#if(ESS_DEMO_EVB)
const TBMS_PROTECT_RANGE1	cBMS_HOCC_THRange = {10u, 30u};			/* HOCC threshold range: 10A ~ 30A */
const TBMS_PROTECT_RANGE1	cBMS_HOCD_THRange = {60u, 90u};			/* HOCD threshold range: 60A ~ 90A */
const TBMS_PROTECT_RANGE1	cBMS_HSCD_THRange = {260u, 320u};		/* HSCD threshold range: 260A ~ 320A */
const TBMS_PROTECT_RANGE1	cBMS_OTUT_ITHRange = {0u, 3500u};		/* OTUT_ITH range: 0mA ~ 3500mA */
#else
const TBMS_PROTECT_RANGE1	cBMS_HOCC_THRange = {5u, 20u};			/* HOCC threshold range: 5A ~ 20A */
const TBMS_PROTECT_RANGE1	cBMS_HOCD_THRange = {10u, 40u};			/* HOCD threshold range: 10A ~ 40A */
const TBMS_PROTECT_RANGE1	cBMS_HSCD_THRange = {20u, 100u};		/* HSCD threshold range: 20A ~ 100A */
const TBMS_PROTECT_RANGE1	cBMS_OTUT_ITHRange = {0u, 3500u};		/* OTUT_ITH range: 0mA ~ 3500mA */
#endif	/* ESS_DEMO_EVB */

const TBMS_PROTECT_RANGE1	cBMS_SOFT_DLYRange = {200u, 1000u};		/* Soft protection delay time range: 200ms ~ 1000ms */

/* temperature protection threshold min/max */
const TBMS_PROTECT_RANGE2	cBMS_OT_THRange = {600, 900};			/* Over Temperature threshold range: 600 ~ 900 .1Cdegree */
const TBMS_PROTECT_RANGE2	cBMS_UT_THRange = {-200, 0};			/* Under Temperature threshold range: -200 ~ 0 .1Cdegree */

static BMS_FETMODE eBMS_FetMode;
static UCHAR ucBMS_Mode_ChgTime;

static BMS_FETSTATE eBMS_FetState;
static BMS_FETSTATE eBMS_FetStateBackup;

static USHORT usBMS_ErrorStatus;
static USHORT usBMS_ShutdownErrSts;

static UCHAR ucPreChargeComplete;

static UCHAR ucErrCnt_PFOV_On;
static UCHAR ucErrCnt_PFOV_Off;
static UCHAR ucErrCnt_SVT_On;
static UCHAR ucErrCnt_SVT_Off;

/****************************************************************************
 Prototype declaration
*****************************************************************************/
static void vBMS_ProtectSetting_Init(void);
static void vVoltageThresholdsCheck(void);
static void vCurrentThresholdCheck(void);
static void vTemperatureThresholdCheck(void);
static void vCheckVoltageError(void);
static void vCheckCurrentError(void);
static void vCheckTemperatureError(void);
static void vErrChkCnt_init(void);
static void vSys_BMS_SetState(BMS_FETSTATE eState);
static void vSys_BMS_SetMode(BMS_FETMODE eMode);
static void vSys_BMS_ModeCtrl(void);
static void vSys_ChgDisFET_ctrl(void);


/****************************************************************************
 define data table
*****************************************************************************/


/****************************************************************************
FUNCTION	: vTsk_sys
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/10/16
*****************************************************************************/
void vTsk_sys(void)
{
	vSys_BMS_ModeCtrl();

	vSys_ChgDisFET_ctrl();

}



/****************************************************************************
FUNCTION	: vTskInit_sys
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/02/03
*****************************************************************************/
void vTskInit_sys(void)
{
	eBMS_FetMode = BMS_FETMODE_AUTO_STARTING;
	ucBMS_Mode_ChgTime = 0u;

	eBMS_FetState = BMS_FETSTATE_STB;
	eBMS_FetStateBackup = BMS_FETSTATE_MANUAL;

	vBMS_ProtectSetting_Init();

	usBMS_ErrorStatus = 0u;
	usBMS_ShutdownErrSts = 0u;
}

/****************************************************************************
FUNCTION	: vBMS_ProtectSetting_Init
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/02/03
*****************************************************************************/
static void vBMS_ProtectSetting_Init(void)
{

	vVoltageThresholdsCheck();

	vCurrentThresholdCheck();

	vTemperatureThresholdCheck();

	vErrChkCnt_init();

}


/****************************************************************************
FUNCTION	: vVoltageThresholdCheck
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/02/03
*****************************************************************************/
static void vVoltageThresholdsCheck(void)
{
	UCHAR ucVolHardProtectChg = 0u;
	UCHAR bmic_status = getBMIC_Ctrl_Status();

	/* HOV threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.usHOV_THmV, cBMS_HOV_THRange.usMin, cBMS_HOV_THRange.usMax);

	/* PFOV threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.usPFOV_THmV, cBMS_PFOV_THRange.usMin, cBMS_PFOV_THRange.usMax);

	/* FCV threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.usFCV_THmV, cBMS_FCV_THRange.usMin, cBMS_FCV_THRange.usMax);

	/* DSV threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.usDSV_THmV, cBMS_DSV_THRange.usMin, cBMS_DSV_THRange.usMax);

	/* HUV threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.usHUV_THmV, cBMS_HUV_THRange.usMin, cBMS_HUV_THRange.usMax);

	/* SVT threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.usSVT_THmV, cBMS_SVT_THRange.usMin, cBMS_SVT_THRange.usMax);

	/* SVDET delay range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.usSVDET_DLYms, cBMS_SOFT_DLYRange.usMin, cBMS_SOFT_DLYRange.usMax);

	/* HOV threshold compare with BMIC hard OV setting, if not same, update BMIC hard OV setting */
	if(BMS_ProtectSetting.usHOV_THmV != BMICSetParam.usOVInfo_vol){
		BMICSetParam.usOVInfo_vol = BMS_ProtectSetting.usHOV_THmV;
		ucVolHardProtectChg = 1u;
	}

	/* HUV threshold compare with BMIC hard UV setting, if not same, update BMIC hard UV setting */
	if(BMS_ProtectSetting.usHUV_THmV != BMICSetParam.usUVInfo_vol){
		BMICSetParam.usUVInfo_vol = BMS_ProtectSetting.usHUV_THmV;
		ucVolHardProtectChg = 1u;
	}

	if(ucVolHardProtectChg){
		if((bmic_status == (UCHAR)BMIC_NORMAL)
#if(BMS_STANDBYMODE_SUPPORT)
		|| (bmic_status == (UCHAR)BMIC_LOWPOWER)
#endif	/* BMS_STANDBYMODE_SUPPORT */
		){
          vBMIC_Send_OVCTL1();
          vBMIC_Send_UVCTL1();
		}
	}
}

/****************************************************************************
FUNCTION	: vCurrentThresholdCheck
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/02/09
*****************************************************************************/
static void vCurrentThresholdCheck(void)
{
	UCHAR ucCurHardProtectionChg = 0u;
	UCHAR bmic_status = getBMIC_Ctrl_Status();

	/* HOCC threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.usHOCC_THA, cBMS_HOCC_THRange.usMin, cBMS_HOCC_THRange.usMax);

	/* HOCD threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.usHOCD_THA, cBMS_HOCD_THRange.usMin, cBMS_HOCD_THRange.usMax);

	/* HSCD threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.usHSCD_THA, cBMS_HSCD_THRange.usMin, cBMS_HSCD_THRange.usMax);

	/* fixed Shunt Resistor value to 1000uOhm if not 1000uOhm */
	if(BMS_ProtectSetting.usShunt_uOhm != 1000u){
		BMS_ProtectSetting.usShunt_uOhm	= 1000u;
	}

	/* OTUT_ITH threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.usOTUT_ITHmA, cBMS_OTUT_ITHRange.usMin, cBMS_OTUT_ITHRange.usMax);

	/* HOCC threshold compare with BMIC driver setting, if not same, update BMIC hard current protect setting */
	if(BMS_ProtectSetting.usHOCC_THA != BMICSetParam.usOCCInfo_cur){
		BMICSetParam.usOCCInfo_cur = BMS_ProtectSetting.usHOCC_THA;
		ucCurHardProtectionChg = 1u;
	}

	/* HOCD threshold compare with BMIC driver setting, if not same, update BMIC hard current protect setting */
	if(BMS_ProtectSetting.usHOCD_THA != BMICSetParam.usOCDInfo_cur){
		BMICSetParam.usOCDInfo_cur = BMS_ProtectSetting.usHOCD_THA;
		ucCurHardProtectionChg = 1u;
	}

	/* HSCD threshold compare with BMIC driver setting, if not same, update BMIC hard current protect setting */
	if(BMS_ProtectSetting.usHSCD_THA != BMICSetParam.usSCDInfo_cur){
		BMICSetParam.usSCDInfo_cur = BMS_ProtectSetting.usHSCD_THA;
		ucCurHardProtectionChg = 1u;
	}

	if(ucCurHardProtectionChg){
		if((bmic_status == (UCHAR)BMIC_NORMAL)
#if(BMS_STANDBYMODE_SUPPORT)
		|| (bmic_status == (UCHAR)BMIC_LOWPOWER)
#endif	/* BMS_STANDBYMODE_SUPPORT */
		){
			vBMIC_Send_ALARM_CTL3();
		}
	}

	if(BMICSetParam.usOTUT_ITHInfo_mA != BMS_ProtectSetting.usOTUT_ITHmA){
		BMICSetParam.usOTUT_ITHInfo_mA = BMS_ProtectSetting.usOTUT_ITHmA;

		if((bmic_status == (UCHAR)BMIC_NORMAL)
#if(BMS_STANDBYMODE_SUPPORT)
		|| (bmic_status == (UCHAR)BMIC_LOWPOWER)
#endif	/* BMS_STANDBYMODE_SUPPORT */
		){
			vBMIC_Send_OTUTITH();
		}
	}

}

/****************************************************************************
FUNCTION	: vTemperatureThresholdCheck
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		: 2023/11/02
DATE		: 2020/02/17
*****************************************************************************/
static void vTemperatureThresholdCheck(void)
{
	UCHAR ucHardProtChg = 0u;
	UCHAR bmic_status = getBMIC_Ctrl_Status();
	short sData1, sData2;
	USHORT usOTUTProtOption = ((BMS_ProtectSetting.usPROTECT_OptionBits & PROTECT_HOTUT) << 4u );

	if((bmic_status == (UCHAR)BMIC_NORMAL)
#if(BMS_STANDBYMODE_SUPPORT)
	|| (bmic_status == (UCHAR)BMIC_LOWPOWER)
#endif	/* BMS_STANDBYMODE_SUPPORT */
	){
		ucHardProtChg = 1u;
	}

	/* HOTC1 threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.sHOTC1_TH01Cdeg, cBMS_OT_THRange.sMin, cBMS_OT_THRange.sMax);

	/* HOTC2 threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.sHOTC2_TH01Cdeg, cBMS_OT_THRange.sMin, cBMS_OT_THRange.sMax);

	/* HOTD1 threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.sHOTD1_TH01Cdeg, cBMS_OT_THRange.sMin, cBMS_OT_THRange.sMax);

	/* HOTD2 threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.sHOTD2_TH01Cdeg, cBMS_OT_THRange.sMin, cBMS_OT_THRange.sMax);

	/* HUTC1 threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.sHUTC1_TH01Cdeg, cBMS_UT_THRange.sMin, cBMS_UT_THRange.sMax);

	/* HUTC2 threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.sHUTC2_TH01Cdeg, cBMS_UT_THRange.sMin, cBMS_UT_THRange.sMax);

	/* HUTD1 threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.sHUTD1_TH01Cdeg, cBMS_UT_THRange.sMin, cBMS_UT_THRange.sMax);

	/* HUTD2 threshold valid range check & adjust */
	SETTING_RANGE_CHECK(BMS_ProtectSetting.sHUTD2_TH01Cdeg, cBMS_UT_THRange.sMin, cBMS_UT_THRange.sMax);

	/* HOTC1 threshold compare with BMIC driver setting, if not same, update BMIC hard temperature protect setting */
	sData1 = BMS_ProtectSetting.sHOTC1_TH01Cdeg/(short)10;
	if((BMICSetParam.sOTC1Info_temp != sData1)){
		BMICSetParam.sOTC1Info_temp = sData1;

		if(ucHardProtChg){
			vBMIC_Send_OTCCTL1();
		}

	}

	/* HOTD1 threshold compare with BMIC driver setting, if not same, update BMIC hard temperature protect setting */
	sData1 = BMS_ProtectSetting.sHOTD1_TH01Cdeg/(short)10;
	if(BMICSetParam.sOTD1Info_temp != sData1){
		BMICSetParam.sOTD1Info_temp = sData1;

		if(ucHardProtChg){
			vBMIC_Send_OTDCTL1();
		}

	}

	/* HUTC1 threshold compare with BMIC driver setting, if not same, update BMIC hard temperature protect setting */
	sData1 = BMS_ProtectSetting.sHUTC1_TH01Cdeg/(short)10;
	if(BMICSetParam.sUTC1Info_temp != sData1){
		BMICSetParam.sUTC1Info_temp = sData1;

		if(ucHardProtChg){
			vBMIC_Send_UTCCTL1();
		}

	}

	/* HUTD1 threshold compare with BMIC driver setting, if not same, update BMIC hard temperature protect setting */
	sData1 = BMS_ProtectSetting.sHUTD1_TH01Cdeg/(short)10;
	if(BMICSetParam.sUTD1Info_temp != sData1){
		BMICSetParam.sUTD1Info_temp = sData1;

		if(ucHardProtChg){
			vBMIC_Send_UTDCTL1();
		}

	}

	/* HOTC2 & HOTD2 threshold compare with BMIC driver setting, if not same, update BMIC hard temperature protect setting */
	sData1 = BMS_ProtectSetting.sHOTC2_TH01Cdeg/(short)10;
	sData2 = BMS_ProtectSetting.sHOTD2_TH01Cdeg/(short)10;
	if((BMICSetParam.sOTC2Info_temp != sData1)
	|| (BMICSetParam.sOTD2Info_temp != sData2)
	){
		BMICSetParam.sOTC2Info_temp = sData1;
		BMICSetParam.sOTD2Info_temp = sData2;

		if(ucHardProtChg){
			vBMIC_Send_OTCTL2();
		}

	}

	/* HUTC2 & HUTD2 threshold compare with BMIC driver setting, if not same, update BMIC hard temperature protect setting */
	sData1 = BMS_ProtectSetting.sHUTC2_TH01Cdeg/(short)10;
	sData2 = BMS_ProtectSetting.sHUTD2_TH01Cdeg/(short)10;
	if((BMICSetParam.sUTC2Info_temp != sData1)
	|| (BMICSetParam.sUTD2Info_temp != sData2)
	){
		BMICSetParam.sUTC2Info_temp = sData1;
		BMICSetParam.sUTD2Info_temp = sData2;

		if(ucHardProtChg){
			vBMIC_Send_UTCTL2();
		}

	}

	/* check BMIC OTC, OTD, UTC, UTD protection settings & update is setting change */
	usOTUTProtOption = (~usOTUTProtOption) & OTUTMSK_MASK;
	if(BMICSetParam.usOTUT_MSK != usOTUTProtOption){
		BMICSetParam.usOTUT_MSK = usOTUTProtOption;

		if(ucHardProtChg){
			vBMIC_Send_OTUTMSK();
		}
	}

}

/****************************************************************************
FUNCTION	: vCheckVoltageError
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/02/17
*****************************************************************************/
static void vCheckVoltageError(void)
{
	USHORT usVcell_min_mV;
	USHORT usVcell_max_mV;
	UCHAR ucSVdet_delay_100ms = (UCHAR)(BMS_ProtectSetting.usSVDET_DLYms / BMS_CTL_TM_BASE);

	usVcell_min_mV = (USHORT)(BMIC_Info.ulBatPackMinBlkVol_uV / 1000u);
	usVcell_max_mV = (USHORT)(BMIC_Info.ulBatPackMaxBlkVol_uV / 1000u);

	/* HUV error check */
	if(((BMIC_Info.ulBatPackErr & (ULONG)ERR_UNDER_VOLTAGE) == (ULONG)ERR_UNDER_VOLTAGE)
	&& (ucGetBMIC_ALARM1_In() == LOW)						/* ALARM1 - low for HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error */
	){
		usBMS_ErrorStatus |= ERR_HUV;
	}else{
		if(usBMS_ErrorStatus & ERR_HUV){
			if((ucGetBMIC_ALARM1_In() == HIGH)				/* ALARM1 - high for all HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error release */
			|| ((BMIC_Info.ulBatPackErr & (ULONG)ERR_UNDER_VOLTAGE) == (ULONG)0u)	/* HUV error release? */
			){
				usBMS_ErrorStatus &= (USHORT)(~ERR_HUV);
			}
		}
	}

	/* HOV error check */
	if(((BMIC_Info.ulBatPackErr & (ULONG)ERR_OVER_VOLTAGE) == (ULONG)ERR_OVER_VOLTAGE)
	&& (ucGetBMIC_ALARM1_In() == LOW)						/* ALARM1 - low for HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error */
	){
		usBMS_ErrorStatus |= ERR_HOV;
	}else{
		if(usBMS_ErrorStatus & ERR_HOV){
			if((ucGetBMIC_ALARM1_In() == HIGH)				/* ALARM1 - high for all HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error release */
			|| ((BMIC_Info.ulBatPackErr & (ULONG)ERR_OVER_VOLTAGE) == (ULONG)0u)	/* HOV error release? */
			){
				usBMS_ErrorStatus &= (USHORT)(~ERR_HOV);
			}
		}
	}

	/* PFOV error check */
	if(usVcell_max_mV > BMS_ProtectSetting.usPFOV_THmV){
		if((usBMS_ShutdownErrSts & ERR_SHDN_PFOV) == 0u){
			ucErrCnt_PFOV_On++;
			if(ucErrCnt_PFOV_On >= ucSVdet_delay_100ms){
				usBMS_ShutdownErrSts |= ERR_SHDN_PFOV;
			}
		}
		ucErrCnt_PFOV_Off = 0u;
	}else{
		if(usBMS_ShutdownErrSts & ERR_SHDN_PFOV){
			ucErrCnt_PFOV_Off++;
			if(ucErrCnt_PFOV_Off >= ucSVdet_delay_100ms){
				usBMS_ShutdownErrSts &= (USHORT)(~ERR_SHDN_PFOV);
			}
		}
		ucErrCnt_PFOV_On = 0u;
	}

	/* SVT error check */
	if(usVcell_min_mV < BMS_ProtectSetting.usSVT_THmV){
		if((usBMS_ShutdownErrSts & ERR_SHDN_SVT) == 0u){
			ucErrCnt_SVT_On++;
			if(ucErrCnt_SVT_On >= ucSVdet_delay_100ms){
				usBMS_ShutdownErrSts |= ERR_SHDN_SVT;
			}
		}
		ucErrCnt_SVT_Off = 0u;
	}else{
		if(usBMS_ShutdownErrSts & ERR_SHDN_SVT){
			ucErrCnt_SVT_Off++;
			if(ucErrCnt_SVT_Off >= ucSVdet_delay_100ms){
				usBMS_ShutdownErrSts &= (USHORT)(~ERR_SHDN_SVT);
			}
		}
		ucErrCnt_SVT_On = 0u;
	}

}


/****************************************************************************
FUNCTION	: vCheckCurrentError
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/02/18
*****************************************************************************/
static void vCheckCurrentError(void)
{

	/* HOCC error check */
	if(((BMIC_Info.ulBatPackErr & (ULONG)ERR_OVER_CURRENT_CHARGE) == (ULONG)ERR_OVER_CURRENT_CHARGE)
	&& (ucGetBMIC_ALARM1_In() == LOW)					/* ALARM1 - low for HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error */
	){
		usBMS_ErrorStatus |= ERR_HOCC;
	}else{
		if(usBMS_ErrorStatus & ERR_HOCC){
			if((ucGetBMIC_ALARM1_In() == HIGH)			/* ALARM1 - high for all HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error release */
			|| ((BMIC_Info.ulBatPackErr & (ULONG)ERR_OVER_CURRENT_CHARGE) == (ULONG)0u)	/* HOCC error release? */
			){
				usBMS_ErrorStatus &= (USHORT)(~ERR_HOCC);
			}
		}
	}

	/* HOCD error check */
	if(((BMIC_Info.ulBatPackErr & (ULONG)ERR_OVER_CURRENT_DISCHARGE) == (ULONG)ERR_OVER_CURRENT_DISCHARGE)
	&& (ucGetBMIC_ALARM1_In() == LOW)					/* ALARM1 - low for HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error */
	){
		usBMS_ErrorStatus |= ERR_HOCD;
	}else{
		if(usBMS_ErrorStatus & ERR_HOCD){
			if((ucGetBMIC_ALARM1_In() == HIGH)			/* ALARM1 - high for all HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error release */
			|| ((BMIC_Info.ulBatPackErr & (ULONG)ERR_OVER_CURRENT_DISCHARGE) == (ULONG)0u)		/* HOCD error release? */
			){
				usBMS_ErrorStatus &= (USHORT)(~ERR_HOCD);
			}
		}
	}

	/* HSCD error check */
	if(((BMIC_Info.ulBatPackErr & (ULONG)ERR_SHORT_CIRCUIT_DET) == (ULONG)ERR_SHORT_CIRCUIT_DET)
	&& (ucGetBMIC_ALARM1_In() == LOW)					/* ALARM1 - SCD error */
	){
		usBMS_ErrorStatus |= ERR_HSCD;
	}else{
		if(usBMS_ErrorStatus & ERR_HSCD){
			if(((BMIC_Info.ulBatPackErr & (ULONG)ERR_SHORT_CIRCUIT_DET) == (ULONG)0u)
			|| (ucGetBMIC_ALARM1_In() == HIGH)			/* ALARM1 - high for all HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error release */
			){
				usBMS_ErrorStatus &= (USHORT)(~ERR_HSCD);
			}
		}
	}

}

/****************************************************************************
FUNCTION	: vCheckTemperatureError
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2023/11/02
*****************************************************************************/
static void vCheckTemperatureError(void)
{
	/* HOTC error check */
	if(((BMIC_Info.ulBatPackErr & (ULONG)ERR_OVER_TEMP_CHARGE) == (ULONG)ERR_OVER_TEMP_CHARGE)
	&& (ucGetBMIC_ALARM1_In() == LOW)						/* ALARM1 - low for HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error */
	){
		usBMS_ErrorStatus |= ERR_HOTC;
	}else{
		if(usBMS_ErrorStatus & ERR_HOTC){
			if((ucGetBMIC_ALARM1_In() == HIGH)				/* ALARM1 - high for all HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error release */
			|| ((BMIC_Info.ulBatPackErr & (ULONG)ERR_OVER_TEMP_CHARGE) == (ULONG)0u)	/* HOTC error release? */
			){
				usBMS_ErrorStatus &= (USHORT)(~ERR_HOTC);
			}
		}
	}

	/* HOTD error check */
	if(((BMIC_Info.ulBatPackErr & (ULONG)ERR_OVER_TEMP_DISCHARGE) == (ULONG)ERR_OVER_TEMP_DISCHARGE)
	&& (ucGetBMIC_ALARM1_In() == LOW)						/* ALARM1 - low for HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error */
	){
		usBMS_ErrorStatus |= ERR_HOTD;
	}else{
		if(usBMS_ErrorStatus & ERR_HOTD){
			if((ucGetBMIC_ALARM1_In() == HIGH)				/* ALARM1 - high for all HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error release */
			|| ((BMIC_Info.ulBatPackErr & (ULONG)ERR_OVER_TEMP_DISCHARGE) == (ULONG)0u)	/* HOTD error release? */
			){
				usBMS_ErrorStatus &= (USHORT)(~ERR_HOTD);
			}
		}
	}

	/* HUTC error check */
	if(((BMIC_Info.ulBatPackErr & (ULONG)ERR_UNDER_TEMP_CHARGE) == (ULONG)ERR_UNDER_TEMP_CHARGE)
	&& (ucGetBMIC_ALARM1_In() == LOW)						/* ALARM1 - low for HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error */
	){
		usBMS_ErrorStatus |= ERR_HUTC;
	}else{
		if(usBMS_ErrorStatus & ERR_HUTC){
			if((ucGetBMIC_ALARM1_In() == HIGH)				/* ALARM1 - high for all HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error release */
			|| ((BMIC_Info.ulBatPackErr & (ULONG)ERR_UNDER_TEMP_CHARGE) == (ULONG)0u)		/* HUTC error release? */
			){
				usBMS_ErrorStatus &= (USHORT)(~ERR_HUTC);
			}
		}
	}

	/* HUTD error check */
	if(((BMIC_Info.ulBatPackErr & (ULONG)ERR_UNDER_TEMP_DISCHARGE) == (ULONG)ERR_UNDER_TEMP_DISCHARGE)
	&& (ucGetBMIC_ALARM1_In() == LOW)						/* ALARM1 - low for HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error */
	){
		usBMS_ErrorStatus |= ERR_HUTD;
	}else{
		if(usBMS_ErrorStatus & ERR_HUTD){
			if((ucGetBMIC_ALARM1_In() == HIGH)				/* ALARM1 - high for all HOV/HUV/HOCC/HOCD/HSCD/HOTC/HOTD/HUTC/HUTD error release */
			|| ((BMIC_Info.ulBatPackErr & (ULONG)ERR_UNDER_TEMP_DISCHARGE) == (ULONG)0u)	/* HUTD error release */
			){
				usBMS_ErrorStatus &= (USHORT)(~ERR_HUTD);
			}
		}
	}


}

/****************************************************************************
FUNCTION	: vErrChkCnt_init
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/02/22
*****************************************************************************/
static void vErrChkCnt_init(void)
{
	ucErrCnt_PFOV_On = 0u;
	ucErrCnt_PFOV_Off = 0u;
	ucErrCnt_SVT_On = 0u;
	ucErrCnt_SVT_Off = 0u;
}


/****************************************************************************
FUNCTION	: vSys_BMS_SetState
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/02/04
*****************************************************************************/
static void vSys_BMS_SetState(BMS_FETSTATE eState)
{
	eBMS_FetState = eState;
}


/****************************************************************************
FUNCTION	: vSys_BMS_SetMode
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/02/08
*****************************************************************************/
static void vSys_BMS_SetMode(BMS_FETMODE eMode){
	eBMS_FetMode = eMode;
	ucBMS_Mode_ChgTime = 0u;
}


/****************************************************************************
FUNCTION	: vSys_BMS_ModeCtrl
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		: 2020/02/08
*****************************************************************************/
static void vSys_BMS_ModeCtrl(void)
{
	if(BMIC_Info.BMICMeasured){
		USHORT usVcell_min_mV;
		USHORT usVcell_max_mV;
		LONG lPackCur_mA;

		UCHAR ucChgDisSt = 0u;

#if(BMIC_IC_TYPE == BMIC_KA49702A)
		if((usBMICReferRegData(STAT_ADDR) & ST_CHG_DIS) == ST_CHG_DIS){			/* ST_CHG_DIS "1" Charging */
			ucChgDisSt = 1u;
		}
#else
		if((usBMICReferRegData(OTHSTAT_ADDR) & ST_CHG_DIS) == ST_CHG_DIS){		/* ST_CHG_DIS "1" Charging */
			ucChgDisSt = 1u;
		}
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

		usVcell_min_mV = (USHORT)(BMIC_Info.ulBatPackMinBlkVol_uV / 1000u);
		usVcell_max_mV = (USHORT)(BMIC_Info.ulBatPackMaxBlkVol_uV / 1000u);
		lPackCur_mA = (LONG)(BMIC_Info.lBatPackCur_100uA / 10);				/* slow current */
		vCheckVoltageError();
		vCheckCurrentError();
		vCheckTemperatureError();
		switch(eBMS_FetMode){
			case BMS_FETMODE_AUTO_SHDN:
				if((usBMS_ShutdownErrSts & ERR_SHDN_SVT) == 0u){
					ucBMS_Mode_ChgTime ++;
					if(ucBMS_Mode_ChgTime >= BMS_CTL_TM_1SEC){
						vSys_BMS_SetMode(BMS_FETMODE_AUTO_STARTING);
						vSys_BMS_SetState(BMS_FETSTATE_STB);
					}
				}else{
					ucBMS_Mode_ChgTime = 0u;
				}
				break;

			case BMS_FETMODE_AUTO_STARTING:
				if((usBMS_ShutdownErrSts & ERR_SHDN_SVT) == 0u){
					ucBMS_Mode_ChgTime ++;
					if(ucBMS_Mode_ChgTime >= BMS_CTL_TM_1SEC){
						vSys_BMS_SetMode(BMS_FETMODE_AUTO_NORMAL);
						ucPreChargeComplete = 0u;
						if(usVcell_min_mV >= BMS_ProtectSetting.usDSV_THmV){
							vSys_BMS_SetState(BMS_FETSTATE_CHARGING);
							ucPreChargeComplete = 1u;
						}else{
							vSys_BMS_SetState(BMS_FETSTATE_PRECHARGE);
						}
					}
				}else{
					vSys_BMS_SetMode(BMS_FETMODE_AUTO_SHDN);
					vSys_BMS_SetState(BMS_FETSTATE_SHDN);
				}
				break;

			case BMS_FETMODE_AUTO_NORMAL:
				if(usBMS_ShutdownErrSts & ERR_SHDN_SVT){					/* SVT error -> shutdown */
					vSys_BMS_SetMode(BMS_FETMODE_AUTO_SHDN);
					vSys_BMS_SetState(BMS_FETSTATE_SHDN);
				}else
 				if((usBMS_ShutdownErrSts & (ERR_SHDN_PFOV)) != 0u){					/* PFOV error -> Failure (Permanent failure) */
					vSys_BMS_SetMode(BMS_FETMODE_AUTO_FAILURE);
					vSys_BMS_SetState(BMS_FETSTATE_PERM_FAILURE);
				}else
				if((((usBMS_ErrorStatus & ERR_HOCC) != 0u) && ((usBMS_ErrorStatus & ERR_HUV) != 0u))				/* OC & UV error same time -> Failure (Temporary failure 3) */
				|| (((usBMS_ErrorStatus & (ERR_HOCD | ERR_HSCD)) != 0u) && ((usBMS_ErrorStatus & ERR_HOV) != 0u))	/* UC & OV error same time -> Failure (Temporary failure 3) */
				|| (((usBMS_ErrorStatus & (ERR_HOTC | ERR_HUTC)) != 0u) && ((usBMS_ErrorStatus & ERR_HUV) != 0u))	/* HOTC or HUTC error and UV same time -> Failure (Temporary failure 3) */
				|| (((usBMS_ErrorStatus & (ERR_HOTD | ERR_HUTD)) != 0u) && ((usBMS_ErrorStatus & ERR_HOV) != 0u))	/* HOTD or HUTD error and OV same time -> Failure (Temporary failure 3) */
				){
					vSys_BMS_SetMode(BMS_FETMODE_AUTO_FAILURE);
					vSys_BMS_SetState(BMS_FETSTATE_TEMP_FAILURE3);
				}else
				if(((usBMS_ErrorStatus & ERR_HOCC) != 0u)					/* OCC errors? -> Failure (Temporary failure 2) */
				|| ((usBMS_ErrorStatus & (ERR_HOTC | ERR_HUTC)) != 0u)					/* OTC/UTC errors? -> Failure (Temporary failure 1) */
				|| ((usBMS_ErrorStatus & ERR_HOV) != 0u)){								/* OV errors -> Failure (Temporary failure 2) */
						vSys_BMS_SetMode(BMS_FETMODE_AUTO_FAILURE);
						if(usVcell_min_mV >= BMS_ProtectSetting.usDSV_THmV){			/* complete precharge (DIS FET allow turn on)? */
							vSys_BMS_SetState(BMS_FETSTATE_TEMP_FAILURE2);				/* -> Failure 2 (CHG FET OFF & DIS FET ON */
						}else{
							vSys_BMS_SetState(BMS_FETSTATE_TEMP_FAILURE3);				/* -> Failure 3 (both CHG & DIS FET OFF */
						}
				}else
				if(((usBMS_ErrorStatus & (ERR_HOCD | ERR_HSCD)) != 0u)		/* OCD/SCD errors? -> Failure (Temporary failure 1) */
				|| ((usBMS_ErrorStatus & (ERR_HOTD | ERR_HUTD)) != 0u))	{				/* OTD/UTD errors? -> Failure (Temporary failure 1) */
						vSys_BMS_SetMode(BMS_FETMODE_AUTO_FAILURE);
						if(usVcell_max_mV < BMS_ProtectSetting.usFCV_THmV){				/* Charge not complete (CHG FET ON)? */
							vSys_BMS_SetState(BMS_FETSTATE_TEMP_FAILURE1);				/* -> Failure 1 (CHG FET ON & DIS FET OFF) */
						}else{
							vSys_BMS_SetState(BMS_FETSTATE_TEMP_FAILURE3);				/* -> Failure 3 (both CHG & DIS FET OFF) */
						}
				}else
				if((usBMS_ErrorStatus & ERR_HUV) != 0u){						/* UV errors -> Failure (Temporary failure 1) */
					if((ucPreChargeComplete != 0u)										/* not in PRECHARGE from Starting? (PRECHARGE from Starting, remain PRECHARGE when UV) */
					){
						vSys_BMS_SetMode(BMS_FETMODE_AUTO_FAILURE);
						vSys_BMS_SetState(BMS_FETSTATE_TEMP_FAILURE1);
					}
				}else{
					switch(eBMS_FetState){
						case BMS_FETSTATE_PRECHARGE:
							if(usVcell_min_mV >= BMS_ProtectSetting.usDSV_THmV){
								ucBMS_Mode_ChgTime ++;
								if(ucBMS_Mode_ChgTime >= BMS_CTL_TM_1SEC){
									vSys_BMS_SetState(BMS_FETSTATE_CHARGING);
									ucPreChargeComplete = 1u;
								}
							}else{
								ucBMS_Mode_ChgTime = 0u;
							}
							break;
						case BMS_FETSTATE_CHARGING:
							if(usVcell_min_mV < BMS_ProtectSetting.usDSV_THmV){
								vSys_BMS_SetState(BMS_FETSTATE_PRECHARGE);
							}else
							if((usVcell_max_mV >= BMS_ProtectSetting.usFCV_THmV)
							 && (lPackCur_mA > ((LONG)(BMS_ProtectSetting.usOTUT_ITHmA) * (-1)))
							 && (lPackCur_mA < (LONG)(BMS_ProtectSetting.usOTUT_ITHmA))
							){
								vSys_BMS_SetState(BMS_FETSTATE_CHG_COMPLETE);
							}else
							if(!ucChgDisSt){
								vSys_BMS_SetState(BMS_FETSTATE_DISCHARGING);
							}
							break;
						case BMS_FETSTATE_DISCHARGING:
							if(usVcell_min_mV < BMS_ProtectSetting.usDSV_THmV){
								vSys_BMS_SetState(BMS_FETSTATE_PRECHARGE);
							}else
							if(ucChgDisSt){
								vSys_BMS_SetState(BMS_FETSTATE_CHARGING);
							}
							break;
						case BMS_FETSTATE_CHG_COMPLETE:
							/*if(usVcell_min_mV < BMS_ProtectSetting.usDSV_THmV){
								vSys_BMS_SetState(BMS_FETSTATE_PRECHARGE);
							}else*/
							if(!ucChgDisSt){
								vSys_BMS_SetState(BMS_FETSTATE_DISCHARGING);
							}
							break;
						default:
							break;
					}
				}
				break;

			case BMS_FETMODE_AUTO_FAILURE:
				if(usBMS_ShutdownErrSts & ERR_SHDN_SVT){					/* SVT error -> shutdown */
					vSys_BMS_SetMode(BMS_FETMODE_AUTO_SHDN);
					vSys_BMS_SetState(BMS_FETSTATE_SHDN);
				}else
				if((eBMS_FetState != BMS_FETSTATE_PERM_FAILURE)				/* not PERMANENT_FAILURE? */
				&& ((usBMS_ShutdownErrSts & (ERR_SHDN_PFOV)) != 0u)			/* PFOV error occur? */
				){
					vSys_BMS_SetState(BMS_FETSTATE_PERM_FAILURE);			/* -> PERMANENT_FAILURE */
				}else{
					switch(eBMS_FetState){
						case BMS_FETSTATE_TEMP_FAILURE1:
						case BMS_FETSTATE_TEMP_FAILURE2:
						case BMS_FETSTATE_TEMP_FAILURE3:
							if((usBMS_ErrorStatus & (ERR_CHARGE | ERR_DISCHARGE )) == 0u){					/* all errors release? */
								vSys_BMS_SetMode(BMS_FETMODE_AUTO_STARTING);								/* Tansit to normal via Standby */
								vSys_BMS_SetState(BMS_FETSTATE_STB);
							}
							else if(((usBMS_ErrorStatus & ERR_CHARGE) != 0u)								/* errors, which turn off CHG FET, occur ? */
							&& ((usBMS_ErrorStatus & ERR_DISCHARGE) != 0u)									/* errors, which turn off DIS FET, occur ? */
							){
								if(eBMS_FetState != BMS_FETSTATE_TEMP_FAILURE3){
									vSys_BMS_SetState(BMS_FETSTATE_TEMP_FAILURE3);
								}
								ucBMS_Mode_ChgTime = 0u;
							}
							else if(((usBMS_ErrorStatus & ERR_CHARGE) != 0u)								/* errors, which turn off CHG FET, remain ? */
							&& ((usBMS_ErrorStatus & ERR_DISCHARGE) == 0u)									/* errors, which turn off DIS FET, release ? */
							){
								if(eBMS_FetState != BMS_FETSTATE_TEMP_FAILURE2){
									if(usVcell_min_mV >= BMS_ProtectSetting.usDSV_THmV){						/* Vcell > DSV (Allow DIS FET ON)? -> go to Failure 2 */
										ucBMS_Mode_ChgTime ++;
										if(ucBMS_Mode_ChgTime >= BMS_CTL_TM_1SEC){
											vSys_BMS_SetState(BMS_FETSTATE_TEMP_FAILURE2);
										}
									}
								}
							}
							else if(((usBMS_ErrorStatus & ERR_CHARGE) == 0u)								/* errors, which turn off CHG FET, release ? */
							&& ((usBMS_ErrorStatus & ERR_DISCHARGE) != 0u)									/* errors, which turn off DIS FET, remain ? */
							){
								if(eBMS_FetState != BMS_FETSTATE_TEMP_FAILURE1){
									if(usVcell_max_mV < BMS_ProtectSetting.usFCV_THmV){						/* Vcell max < FCV (Allow CHG FET ON)? -> go to Failure 1 */
										ucBMS_Mode_ChgTime ++;
										if(ucBMS_Mode_ChgTime >= BMS_CTL_TM_1SEC){
											vSys_BMS_SetState(BMS_FETSTATE_TEMP_FAILURE1);
										}
									}
								}
								else if(ucPreChargeComplete == 0u){											/* Precharge from starting? -> Standby (Transit to normal) when other discharge errors release except SUV/HUV */
									if((usBMS_ErrorStatus & (ERR_HOCD | ERR_HSCD | ERR_HOTD | ERR_HUTD)) == 0u){
										vSys_BMS_SetMode(BMS_FETMODE_AUTO_STARTING);
										vSys_BMS_SetState(BMS_FETSTATE_STB);
									}
								}
							}
							break;
						case BMS_FETSTATE_PERM_FAILURE:
							/* do nothing until SVT to transit to Shutdown */
							break;
						default:
							break;
					}
				}
				break;

			case BMS_FETMODE_MANUAL:
				break;

		}
	}

}


/****************************************************************************
FUNCTION	: vSys_ChgDisFET_ctrl
DESCRIPTION	: CHG FET / DIS FET on/off control based on eBMS_FetState
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2021/02/02
*****************************************************************************/
static void vSys_ChgDisFET_ctrl(void)
{
	if(eBMS_FetStateBackup != eBMS_FetState){

		switch(eBMS_FetState){
			case BMS_FETSTATE_SHDN:
			case BMS_FETSTATE_STB:
				vBMIC_Charge_FET_Out(FET_OFF);					/* CHG FET OFF */
				vBMIC_Discharge_FET_Out(FET_OFF);				/* DIS FET OFF */
				break;

			case BMS_FETSTATE_PRECHARGE:
				vBMIC_Charge_FET_Out(FET_ON);					/* CHG FET ON */
				vBMIC_Discharge_FET_Out(FET_OFF);				/* DIS FET OFF */
				break;

			case BMS_FETSTATE_DISCHARGING:
			case BMS_FETSTATE_CHARGING:
				vBMIC_Charge_FET_Out(FET_ON);					/* CHG FET ON */
				vBMIC_Discharge_FET_Out(FET_ON);				/* DIS FET ON */
				break;

			case BMS_FETSTATE_CHG_COMPLETE:
				vBMIC_Charge_FET_Out(FET_OFF);					/* CHG FET OFF */
				vBMIC_Discharge_FET_Out(FET_ON);				/* DIS FET ON */
				break;

			case BMS_FETSTATE_TEMP_FAILURE1:
				vBMIC_Charge_FET_Out(FET_ON);					/* CHG FET ON */
				vBMIC_Discharge_FET_Out(FET_OFF);				/* DIS FET OFF */
				break;

			case BMS_FETSTATE_TEMP_FAILURE2:
				vBMIC_Charge_FET_Out(FET_OFF);					/* CHG FET OFF */
				vBMIC_Discharge_FET_Out(FET_ON);				/* DIS FET ON */
				break;

			case BMS_FETSTATE_TEMP_FAILURE3:
			case BMS_FETSTATE_PERM_FAILURE:
				vBMIC_Charge_FET_Out(FET_OFF);					/* CHG FET OFF */
				vBMIC_Discharge_FET_Out(FET_OFF);				/* DIS FET OFF */
				break;

			case BMS_FETSTATE_MANUAL:               /* BMS_FETSTATE_MANUAL - CHG/DIS FET manually controlled by PC GUI */
				break;
		}
		eBMS_FetStateBackup = eBMS_FetState;
	}
}

/****************************************************************************
FUNCTION	: ucGetBMIC_status3
DESCRIPTION	:
INPUT		:
OUTPUT		: UCHAR
UPDATE		:
DATE		:2021/02/18
*****************************************************************************/
UCHAR	ucGetBMIC_status3(void)
{
	return((UCHAR)eBMS_FetState);
}


/****************************************************************************
FUNCTION	: bSetFETCtrlMode
DESCRIPTION	:
INPUT		: UCHAR
OUTPUT		: bool
UPDATE		:
DATE		: 2021/02/19
*****************************************************************************/
bool bSetFETCtrlMode(UCHAR ucMode)
{
	bool bRet = true;

	UCHAR cellbalON = 0u;
	UCHAR cellbalOFF = 0u;

	if(ucMode){									/* Enable FET SW control */
		if(eBMS_FetMode == BMS_FETMODE_MANUAL){		/* now is manual mode? */
			vTskInit_sys();						/* start from initial */

			#if(BMS_STANDBYMODE_SUPPORT)
			if(ucGet_BMICOpeMode() != (UCHAR)BMIC_OPEMODE_ACTIVE){	/* Not in Active mode?  */
				vBMIC_ChgOpeMode((UCHAR)BMIC_OPEMODE_ACTIVE);		/* Request to change Active mode */
				vBMIC_Set_OpeMode_Req(1u);
			}
			#endif	/* BMS_STANDBYMODE_SUPPORT */
		}
	}else{										/* Disable FET SW control */
		vSys_BMS_SetMode(BMS_FETMODE_MANUAL);
		vSys_BMS_SetState(BMS_FETSTATE_MANUAL);

		/* If CB is on, disable CB */
		if(ulBMIC_GetCellbalanceReq() != 0x00000000u){
			vBMIC_GetCellbalanceONOFFtime(&cellbalON,&cellbalOFF);		/* Get current CB ON/OFF time settings */
			vBMIC_SetCellbalanceReq(0x00000000u,cellbalON,cellbalOFF);	/* Disable CB and remain current CB ON/OFF time settings */
		}
	}
	return(bRet);
}


/****************************************************************************
FUNCTION	: ucGetFETCtrlMode
DESCRIPTION	:
INPUT		:
OUTPUT		: UCHAR
UPDATE		:
DATE		: 2021/02/19
*****************************************************************************/
UCHAR ucGetFETCtrlMode(void)
{
	UCHAR ucMode = 0u;
	if(eBMS_FetMode != BMS_FETMODE_MANUAL){
		ucMode = 1u;
	}
	return(ucMode);
}


/****************************************************************************
FUNCTION	: vGetCurrentProtectSetting
DESCRIPTION	:
INPUT		: UCHAR *destadr, UCHAR *size
OUTPUT		:
UPDATE		:
DATE		: 2021/02/19
*****************************************************************************/
void vGetCurrentProtectSetting(UCHAR *destadr, UCHAR *size)
{
	USHORT *srcadr;
	UCHAR ucCnt = 0u;
	USHORT usData;

	for(srcadr = &BMS_ProtectSetting.usPROTECT_OptionBits; srcadr <= &BMS_ProtectSetting.usDSV_THmV;){
		usData =  *srcadr;

		if(((srcadr >= (USHORT *)&BMS_ProtectSetting.sHOTC1_TH01Cdeg ) && (srcadr <= (USHORT *)&BMS_ProtectSetting.sHUTD2_TH01Cdeg))
		){
			usData += 400u;			/* add offset 400 (400 01degree) to temperature thresholds */
		}

		*(destadr+ucCnt) = (UCHAR)(usData & 0x00FFu);
		ucCnt ++;
		*(destadr+ucCnt) = (UCHAR)((usData & 0xFF00u)>>8u);
		ucCnt ++;
		srcadr ++;
	}
	*size += ucCnt;
}

/****************************************************************************
FUNCTION	: ucSetProtectSetting
DESCRIPTION	:
INPUT		: UCHAR *srcadr, UCHAR size
OUTPUT		:
UPDATE		:
DATE		: 2021/02/19
*****************************************************************************/
UCHAR ucSetProtectSetting(UCHAR *srcadr, UCHAR size)
{
	USHORT *destadr;
	USHORT usData;
	SHORT sTempData;

	UCHAR ucRet = 1u;

	for(destadr = &BMS_ProtectSetting.usPROTECT_OptionBits; destadr <= &BMS_ProtectSetting.usDSV_THmV;){
		usData = ((USHORT)*(srcadr) & (USHORT)0x00FF) | (((USHORT)(*(srcadr + 1)) & (USHORT)0x00FF) << 8u);
		if(destadr == (USHORT *)&BMS_ProtectSetting.usPROTECT_OptionBits ){
			usData &= (USHORT)0x00F0u;				/* bp0~3, bp15~bp8 reserved: fixed 0 */
		}else
		if(((destadr >= (USHORT *)&BMS_ProtectSetting.sHOTC1_TH01Cdeg ) && (destadr <= (USHORT *)&BMS_ProtectSetting.sHUTD2_TH01Cdeg))
		){
			sTempData = (SHORT)usData;
			sTempData -= 400;				/* remove offset 400 (400 01degree) to temperature thresholds */
			usData = (USHORT)sTempData;
		}
		*destadr = usData;
		destadr ++;
		srcadr += 2u;
	}
	if(eBMS_FetMode != BMS_FETMODE_MANUAL){				/* FET not Manual control? */
		vTskInit_sys();
	}

	return(ucRet);
}
#endif	/* BMS_FETSTATE_CTRL */

