/****************************************************************************
#ifdef DOC
File Name		: upd_prepare.c
Description		:
Remark			:
Date			:
Copyright		: Nuvoton Technology Singapore
#endif
*****************************************************************************/
#include <stdbool.h>
#include "NuMicro.h"
#include "sys_type.h"
#include "main.h"
#include "drv_spi.h"
#include "tsk_gui_if.h"
#include "drv_timer.h"
#include "vcom_serial.h"

#if defined(SUPPORT_FWUPDATE)
/****************************************************************************
 define macro
*****************************************************************************/
#define APROM_PAGE_SIZE			FMC_FLASH_PAGE_SIZE
#define	APROM_BLOCK_SIZE		(APROM_PAGE_SIZE * 4)

//#define	APROM_START_ADDR	FMC_APROM_BASE
#define	APROM_START_ADDR		(0x00004000u)
#define	APROM_END_ADDR			(0x00020000u)		/* 128KB, 0x0000_0000 ~ 0x0001_FFFF */
//#define	APROM_END_ADDR		(0x00040000u)		/* 256KB, 0x0000_0000 ~ 0x0003_FFFF */
#define	APROM_CHKSUM_ADDR		(APROM_END_ADDR - APROM_PAGE_SIZE)


#define	UPD_ERR_NONE			((UCHAR)0x00u)
#define	UPD_ERR_ERASE			((UCHAR)0x01u)
#define	UPD_ERR_WRITE			((UCHAR)0x02u)
#define	UPD_ERR_CRC				((UCHAR)0x08u)
/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/


/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/


/****************************************************************************
 Variable declaration
*****************************************************************************/
UCHAR ucUPD_Error;
UCHAR ucFMC_OpenFlg;
UCHAR ucFWUpdPrepare;
/****************************************************************************
 Prototype declaration
*****************************************************************************/


/****************************************************************************
 define data table
*****************************************************************************/


/****************************************************************************
FUNCTION	: vSetUPD_PrepareReq
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		:
*****************************************************************************/
void vSetUPD_PrepareReq(void)
{

	ucFWUpdPrepare = 1;

}


/****************************************************************************
FUNCTION	: vUPD_OpenFMC
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		:
*****************************************************************************/
void vUPD_OpenFMC(void)
{

	FMC_Open();

//	FMC_ENABLE_CFG_UPDATE();				/* Enable CONFIG update. */
	FMC_ENABLE_AP_UPDATE();					/* Enable APROM update. */

	ucFMC_OpenFlg = 1u;

}

/****************************************************************************
FUNCTION	: vUPD_CloseFMC
DESCRIPTION	:
INPUT		:
OUTPUT		:
UPDATE		:
DATE		:
*****************************************************************************/
void vUPD_CloseFMC(void)
{
	FMC_DISABLE_AP_UPDATE();				/* Disable APROM update. */
//	FMC_DISABLE_CFG_UPDATE();				/* Disable CONFIG update. */

	FMC_Close();							/* Disable FMC ISP function */

	ucFMC_OpenFlg = 0u;

}

/****************************************************************************
FUNCTION	: vUPD_EraseChksum
DESCRIPTION	: Erases the firmware checksum page and sets an error flag if erase fails.
INPUT		: None
OUTPUT		: None
UPDATE		:
DATE		: 2025/04/25
*****************************************************************************/
void vUPD_EraseChksum(void)
{

	/* Page Erase */
	if(FMC_Erase(APROM_CHKSUM_ADDR) != 0){
		ucUPD_Error |= UPD_ERR_ERASE;
	}

}

/****************************************************************************
FUNCTION	: vSetUPD_Prepare
DESCRIPTION	: Prepares for firmware update by disabling peripherals, enabling ISP, 
              erasing checksum, and triggering auto reset
INPUT		: None
OUTPUT		: None
UPDATE		: 
DATE		: 2025/04/25
*****************************************************************************/
void vUPD_Prepare(void)
{

	static UCHAR ucWaitCnt = 0u;

	if(ucFWUpdPrepare){

		if(ucWaitCnt < 25u){							/* 25 * 8 = 200ms */
			ucWaitCnt ++;
		}else
		if((gu32TxSize == 0) && (comRbytes == 0)){		/* Wait for response sent to GUI */

			TIMER_Stop(TIMER0);

#if(ESS_DEMO_EVB)
			SPI_Close(SPI2);
#else
			SPI_Close(SPI1);
#endif	/* ESS_DEMO_EVB */

			NVIC_DisableIRQ(TMR0_IRQn);
			NVIC_DisableIRQ(USBD_IRQn);
#if(PDMA_USED)
			NVIC_DisableIRQ(PDMA_IRQn);
#endif
			/* Unlock protected registers */
			SYS_UnlockReg();

			/* Enable FMC ISP function */
			CLK->AHBCLK |= CLK_AHBCLK_ISPCKEN_Msk;

			vUPD_OpenFMC();								/* Enable APROM update */
			vUPD_EraseChksum();							/* Erase Firmware Checksum page */

			SYS->IPRST0 = SYS_IPRST0_CHIPRST_Msk;		/* Perform chip reset to switch to loader */

			while(1){
				;
			}
		}

	}

}

#endif	/* SUPPORT_FWUPDATE */
