/****************************************************************************
#ifdef DOC
File Name		:main.c
Description		:main file for 49702 BMS Reference Solution using M480 MCU.
Remark			:
Date			:2024/03/01
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/
#include <stdbool.h>
#include <stdio.h>
#include "NuMicro.h"
#include "sys_type.h"
#include "main.h"
#include "portio.h"
#include "tsk_bmic.h"
#include "drv_bmic.h"
#include "drv_timer.h"
#include "drv_spi.h"
#if(PCGUI_IF_USB)
#include "drv_usbd.h"
#else
#include "drv_uart.h"
#endif	/* PCGUI_IF_USB */
#include "tsk_gui_if.h"


/****************************************************************************
 define macro
*****************************************************************************/
#define PLL_CLOCK           192000000u

/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/

/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/

/****************************************************************************
 Variable declaration
*****************************************************************************/

/****************************************************************************
 Prototype declaration
*****************************************************************************/
void vSYS_Init(void);
void vPORT_Init(void);
/*void vEnable_EINT(void);*/
#if(PDMA_USED)
void PDMA_Init(void);
#endif	/* PDMA_USED */


/*************/
/*************/
void vSOC_Init(void);
void vSOC_Task(void);
/*************/
/*************/


/****************************************************************************
 define data table
*****************************************************************************/


/*---------------------------------------------------------------------------------------------------------*/
/* System init 																								*/
/*---------------------------------------------------------------------------------------------------------*/
void vSYS_Init(void)
{
	/*---------------------------------------------------------------------------------------------------------*/
	/* Init System Clock                                                                                       */
	/*---------------------------------------------------------------------------------------------------------*/
	/* Unlock protected registers */
	SYS_UnlockReg();

#if(HXT_DISABLE)

	/* Set core clock as PLL_CLOCK from PLL */
	CLK_SetCoreClock(PLL_CLOCK);

#else

	/* When HXT enabled, GPIO must set to input mode */
	/* Set XT1_OUT(PF.2) and XT1_IN(PF.3) to input mode */
	PF->MODE &= ~(GPIO_MODE_MODE2_Msk | GPIO_MODE_MODE3_Msk);

	/* When LXT enabled, GPIO must set to input mode */
	/* Set X32_OUT(PF.4) and X32_IN(PF.5) to input mode */
	PF->MODE &= ~(GPIO_MODE_MODE4_Msk | GPIO_MODE_MODE5_Msk);

	/* Enable External XTAL (4~24 MHz) *//* Enable External LXT (32kHz) */
	CLK_EnableXtalRC(CLK_PWRCTL_HXTEN_Msk | CLK_PWRCTL_LXTEN_Msk);

	/* Waiting for 12MHz clock ready *//* Waiting for 32kHz clock ready */
	CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk | CLK_STATUS_LXTSTB_Msk);

	/* Set core clock as PLL_CLOCK from PLL */
	CLK_SetCoreClock(PLL_CLOCK);

#endif	/* HXT_DISABLE */

	/* Set HCLK from PLL, divide 4 */
	CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_PLL, CLK_CLKDIV0_HCLK(4u) );

	/* Set PCLK0/PCLK1 to HCLK/2 */
	CLK->PCLKDIV = (CLK_PCLKDIV_APB0DIV_DIV2 | CLK_PCLKDIV_APB1DIV_DIV2);

/*************/
/*************/


    CLK_EnableModuleClock(UART2_MODULE);
    CLK_SetModuleClock(UART2_MODULE, CLK_CLKSEL3_UART2SEL_HIRC, CLK_CLKDIV4_UART2(1));



	/* Update System Core Clock */
	/* User can use SystemCoreClockUpdate() to calculate SystemCoreClock. */
	SystemCoreClockUpdate();
	
	
	  /* PB.0 RXD, PB.1 TXD */
    SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB0MFP_Msk | SYS_GPB_MFPL_PB1MFP_Msk);
    SYS->GPB_MFPL |=  (SYS_GPB_MFPL_PB0MFP_UART2_RXD |
                      SYS_GPB_MFPL_PB1MFP_UART2_TXD);


    SYS_ResetModule(UART2_RST);
    UART_Open(UART2, 115200);

    printf("\r\n=== KA49702A: BMIC_STARTUP -> BMIC_NORMAL (UART2) ===\r\n");

/*************/
/*************/


#if(PCGUI_IF_USB)
	/* M480LD support crystal-less */
	if (((SYS->CSERVER & SYS_CSERVER_VERSION_Msk) == 0x1) && (CRYSTAL_LESS))
	{
		CLK->PWRCTL |= CLK_PWRCTL_HIRC48MEN_Msk;
		/* Select IP clock source */
		CLK->CLKSEL0 &= ~CLK_CLKSEL0_USBSEL_Msk;
	}
	else
	{
		/* Select IP clock source */
		CLK->CLKSEL0 |= CLK_CLKSEL0_USBSEL_Msk;

#if(PLL_CLOCK == 192000000u)
		/* CLKDIV0_USB: 192MHz / 48MHz = 4 */
		CLK->CLKDIV0 = (CLK->CLKDIV0 & ~CLK_CLKDIV0_USBDIV_Msk) | CLK_CLKDIV0_USB(4);
#elif(PLL_CLOCK == 144000000u)
		/* CLKDIV0_USB: 144MHz / 48MHz = 3 */
		CLK->CLKDIV0 = (CLK->CLKDIV0 & ~CLK_CLKDIV0_USBDIV_Msk) | CLK_CLKDIV0_USB(3);
#else
		!error
		printf("USB Clock source from PLL, please set CLKDIV0_USBDIV properly! \n");
#endif
	}

	/* Select USBD */
	SYS->USBPHY = (SYS->USBPHY & ~SYS_USBPHY_USBROLE_Msk) | SYS_USBPHY_USBEN_Msk | SYS_USBPHY_SBO_Msk;

	/* Enable IP clock */
	CLK_EnableModuleClock(USBD_MODULE);
#endif	/* PCGUI_IF_USB */

	/* Configure WDT settings and start WDT counting *//* Enable WDT time-out reset, disable WDT wake-up */
	WDT_Open(WDT_TIMEOUT_2POW12, WDT_RESET_DELAY_3CLK, TRUE, FALSE );		/* runaway detection time: 409.6ms + 0.3ms = 409.9ms  */

	/* Lock protected registers */
	SYS_LockReg();
}

/*
 * This is a template project for M480 series MCU. Users could based on this project to create their
 * own application without worry about the IAR/Keil project settings.
*/

int main(void)
{

	vSYS_Init();

	vPORT_Init();
#if(!PCGUI_IF_USB)
	vUART_Init();
#endif	/* !PCGUI_IF_USB */
	vSPI_Init();

	vTIMER_Init();

#if(PDMA_USED)
	PDMA_Init();
#endif	/* PDMA_USED */

#if(PCGUI_IF_USB)
	vUSBD_Init();
#endif	/* PCGUI_IF_USB */

	vTskInit_bmic();

#if(BMS_FETSTATE_CTRL)
	vTskInit_sys();
#endif	/* BMS_FETSTATE_CTRL */

	vTskInit_gui_if();

	vTskInit_led();
	
/*************/
/*************/
	vSOC_Init();
	
/*************/
/*************/


/*	vEnable_EINT();		*/

#if(PCGUI_IF_USB)
	NVIC_EnableIRQ(USBD_IRQn);
#endif	/* PCGUI_IF_USB */

	/* Enable Timer0 NVIC */
	NVIC_EnableIRQ(TMR0_IRQn);

	/* Enable WDT NVIC */
	NVIC_EnableIRQ(WDT_IRQn);

	/* Start Timer0 counting */
	TIMER_Start(TIMER0);

	while(1){
#if(PCGUI_IF_USB)
		vUSBD_main();
#endif	/* PCGUI_IF_USB */
		if(ucMainLoopFlg){
//			PC0 = ~PC0;
			ucMainLoopFlg = 0u;

			vTsk_bmic();
			
			
			/*************/
			/*************/
			vSOC_Task();
			/*************/
			/*************/	

			
			vTsk_led();

#if(BMS_FETSTATE_CTRL)
			vTsk_sys();
#endif	/* BMS_FETSTATE_CTRL */

			vTask_gui_if();

			#if(BMS_TESTMODE)
	        {
	        	extern void vBMIC_Test(void);
	        	vBMIC_Test();
			}
			#endif /* BMS_TESTMODE */

#if(ESS_DEMO_CB)
			ucLoop1secFlg = 0u;
#endif	/* ESS_DEMO_CB */

#if defined(SUPPORT_FWUPDATE)
			vUPD_Prepare();
#endif	/* SUPPORT_FWUPDATE */


			WDT_RESET_COUNTER();
		}

	}
}



/* ---------------------------------------------------------------------------------------------------*/

/* --------------------------------------------------------- */
/* USER SETTINGS                                             */
/* --------------------------------------------------------- */

/* Samsung 25R, 2P pack = 5000mAh nominal pack capacity */
#define SOC_PACK_CAPACITY_MAH   (5000.0f)

/* Reference software main loop period = 25ms */
#define SOC_DT_MS               (25.0f)

/* Ignore very small current around zero to avoid SOC drift */
#define SOC_DEADBAND_MA         (50.0f)

/* Print once every 1 second
   1000ms / 25ms = 40 loops
*/
#define SOC_PRINT_COUNT         (40)

/* --------------------------------------------------------- */
/* SIMPLE OCV TABLE                                          */
/* Voltage is in mV                                          */
/* SOC is in %                                               */
/* --------------------------------------------------------- */
static const uint16_t ocv_table_mV[] =
{
    4200, 4150, 4110, 4000, 3920, 3850,
    3790, 3740, 3680, 3600, 3400, 3000
};

static const uint8_t ocv_table_soc[] =
{
    100,  95,   90,   80,   70,   60,
     50,  40,   30,   20,   10,    0
};

/* --------------------------------------------------------- */
/* MODULE VARIABLES                                          */
/* --------------------------------------------------------- */

/* 0 = startup OCV initialization not done yet
   1 = startup OCV initialization already done
*/
static uint8_t g_soc_init_done = 0U;

/* SOC value stored in percent */
static float g_soc_percent = 0.0f;

/* Remaining capacity stored in mAh */
static float g_remaining_mAh = 0.0f;

/* Counter used to slow down UART printing */
static uint16_t g_print_counter = 0U;

/* --------------------------------------------------------- */
/* OCV LOOKUP FUNCTION                                       */
/* Converts one cell voltage in mV into SOC in %             */
/* --------------------------------------------------------- */
static float fSOC_FromOCV(uint16_t cell_mV)
{
    uint32_t i;      /* Loop counter for table search */
    uint32_t count;  /* Number of OCV table points */
    float v1;        /* Upper voltage point */
    float v2;        /* Lower voltage point */
    float s1;        /* Upper SOC point */
    float s2;        /* Lower SOC point */
    float ratio;     /* Interpolation ratio */

    /* Count the number of voltage points in the OCV table */
    count = sizeof(ocv_table_mV) / sizeof(ocv_table_mV[0]);

    /* If the measured voltage is above the top table point,
       force SOC = 100%
    */
    if (cell_mV >= ocv_table_mV[0])
    {
        return 100.0f;
    }

    /* If the measured voltage is below the bottom table point,
       force SOC = 0%
    */
    if (cell_mV <= ocv_table_mV[count - 1U])
    {
        return 0.0f;
    }

    /* Search the matching voltage band in the OCV table */
    for (i = 0; i < (count - 1U); i++)
    {
        /* Check if cell_mV is inside the voltage band
           between point i and point i+1
        */
        if ((cell_mV <= ocv_table_mV[i]) && (cell_mV > ocv_table_mV[i + 1U]))
        {
            /* Read the upper voltage point */
            v1 = (float)ocv_table_mV[i];

            /* Read the lower voltage point */
            v2 = (float)ocv_table_mV[i + 1U];

            /* Read the upper SOC point */
            s1 = (float)ocv_table_soc[i];

            /* Read the lower SOC point */
            s2 = (float)ocv_table_soc[i + 1U];

            /* Calculate interpolation ratio */
            ratio = ((float)cell_mV - v2) / (v1 - v2);

            /* Return interpolated SOC */
            return s2 + (ratio * (s1 - s2));
        }
    }

    /* Safety fallback */
    return 0.0f;
}

/* --------------------------------------------------------- */
/* LIMIT FUNCTION                                            */
/* Keeps remaining capacity and SOC inside valid range       */
/* --------------------------------------------------------- */
static void vSOC_Clamp(void)
{
    /* If remaining capacity goes below zero, force it to zero */
    if (g_remaining_mAh < 0.0f)
    {
        g_remaining_mAh = 0.0f;
    }

    /* If remaining capacity goes above pack capacity,
       force it back to full capacity
    */
    if (g_remaining_mAh > SOC_PACK_CAPACITY_MAH)
    {
        g_remaining_mAh = SOC_PACK_CAPACITY_MAH;
    }

    /* Recalculate SOC from remaining capacity */
    g_soc_percent = (g_remaining_mAh / SOC_PACK_CAPACITY_MAH) * 100.0f;

    /* Limit SOC low */
    if (g_soc_percent < 0.0f)
    {
        g_soc_percent = 0.0f;
    }

    /* Limit SOC high */
    if (g_soc_percent > 100.0f)
    {
        g_soc_percent = 100.0f;
    }
}

/* --------------------------------------------------------- */
/* INIT FUNCTION                                             */
/* Call once during startup                                  */
/* --------------------------------------------------------- */
void vSOC_Init(void)
{
    /* Startup OCV initialization has not happened yet */
    g_soc_init_done = 0U;

    /* Start with SOC = 0 until valid BMIC data arrives */
    g_soc_percent = 0.0f;

    /* Start with remaining capacity = 0 until OCV init is done */
    g_remaining_mAh = 0.0f;

    /* Reset print counter */
    g_print_counter = 0U;
}

/* --------------------------------------------------------- */
/* MAIN SOC TASK                                             */
/* Call after vTsk_bmic() every 25ms                         */
/* --------------------------------------------------------- */
void vSOC_Task(void)
{
    uint16_t max_cell_mV;      /* Highest measured cell voltage in mV */
    float current_mA;          /* Raw BMIC current converted to mA */
    float delta_mAh;           /* Capacity change during one 25ms loop */
    const char *direction;     /* CHARGE / DISCHARGE / IDLE */

    /* Do nothing until BMIC measurement data is valid */
    if (BMIC_Info.BMICMeasured == 0U)
    {
        return;
    }

    /* ----------------------------------------------------- */
    /* FIRST TIME ONLY: startup OCV initialization           */
    /* ----------------------------------------------------- */
    if (g_soc_init_done == 0U)
{
    /* Read maximum cell voltage from BMIC_Info
       ulBatPackMaxBlkVol_uV is in microvolts
       Convert uV to mV by dividing by 1000
    */
    max_cell_mV = (uint16_t)(BMIC_Info.ulBatPackMaxBlkVol_uV / 1000UL);

    /* If the first wake-up measurement is 0 mV,
       skip this loop and try again in the next 25ms loop
    */
    if (max_cell_mV == 0U)
    {
        return;
    }

    /* Convert maximum cell voltage to startup SOC */
    g_soc_percent = fSOC_FromOCV(max_cell_mV);

    /* Initialize remaining capacity from startup SOC */
    g_remaining_mAh = (SOC_PACK_CAPACITY_MAH * g_soc_percent) / 100.0f;

    /* Mark startup initialization as done */
    g_soc_init_done = 1U;

    /* Print startup debug only once */
    printf("[SOC INIT] MaxCell=%u mV | SOC=%.1f %% | RemCap=%.1f mAh\r\n",
           max_cell_mV,
           g_soc_percent,
           g_remaining_mAh);

    /* Exit now; runtime coulomb counting starts next loop */
    return;
}

    /* ----------------------------------------------------- */
    /* RUNTIME CURRENT READING                               */
    /* lBatPackCur_100uA is stored in 100uA units            */
    /* 100uA = 0.1mA                                         */
    /* ----------------------------------------------------- */
    current_mA = ((float)BMIC_Info.lBatPackCur_100uA) * 0.1f;

    /* Ignore very small current around zero */
    if ((current_mA < SOC_DEADBAND_MA) && (current_mA > (-SOC_DEADBAND_MA)))
    {
        current_mA = 0.0f;
    }

    /* ----------------------------------------------------- */
    /* SIMPLE COULOMB COUNTING FOR THIS BOARD SIGN           */
    /* On this board:                                        */
    /*   discharge current = negative                        */
    /*   charge current    = positive                        */
    /* Therefore:                                            */
    /*   delta_mAh becomes negative during discharge         */
    /*   delta_mAh becomes positive during charge            */
    /* ----------------------------------------------------- */
    delta_mAh = current_mA * (SOC_DT_MS / 3600000.0f);

    /* Update remaining capacity directly for this board sign */
    g_remaining_mAh = g_remaining_mAh + delta_mAh;

    /* Clamp result and recalculate SOC */
    vSOC_Clamp();

    /* Determine direction text from raw board current sign */
    if (current_mA < (-SOC_DEADBAND_MA))
    {
        direction = "DISCHARGE";
    }
    else if (current_mA > SOC_DEADBAND_MA)
    {
        direction = "CHARGE";
    }
    else
    {
        direction = "IDLE";
    }

    /* Count loops for slow UART printing */
    g_print_counter++;

    /* Print once every 1 second */
    if (g_print_counter >= SOC_PRINT_COUNT)
    {
        /* Reset print counter */
        g_print_counter = 0U;

        /* Print runtime debug */
        printf("[SOC] Current=%.1f mA | Dir=%s | RemCap=%.1f mAh | SOC=%.1f %%\r\n",
               current_mA,
               direction,
               g_remaining_mAh,
               g_soc_percent);
    }
}


/*---------------------------------------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------------------------------------*/





/*---------------------------------------------------------------------------------------------------------*/
/* PORT init 																								*/
/*---------------------------------------------------------------------------------------------------------*/
void vPORT_Init(void)
{

#if(PCGUI_IF_USB)
	/* Set PA.12 ~ PA.14 to input mode */
	PA->MODE &= ~(GPIO_MODE_MODE12_Msk | GPIO_MODE_MODE13_Msk | GPIO_MODE_MODE14_Msk);
	SYS->GPA_MFPH &= ~(SYS_GPA_MFPH_PA12MFP_Msk|SYS_GPA_MFPH_PA13MFP_Msk|SYS_GPA_MFPH_PA14MFP_Msk|SYS_GPA_MFPH_PA15MFP_Msk);
	SYS->GPA_MFPH |= (SYS_GPA_MFPH_PA12MFP_USB_VBUS|SYS_GPA_MFPH_PA13MFP_USB_D_N|SYS_GPA_MFPH_PA14MFP_USB_D_P|SYS_GPA_MFPH_PA15MFP_USB_OTG_ID);
#else
	/* UART3 for PC-GUI I/F */
	/* PC.2, PC.3 output set to L */
	PC2 = 0u;
	PC3 = 0u;
	/* Set GPB multi-function pins for UART3 RXD and TXD */
	SYS->GPC_MFPL &= ~(SYS_GPC_MFPL_PC3MFP_Msk | SYS_GPC_MFPL_PC2MFP_Msk);
	SYS->GPC_MFPL |= (SYS_GPC_MFPL_PC3MFP_UART3_TXD | SYS_GPC_MFPL_PC2MFP_UART3_RXD);
#endif	/* PCGUI_IF_USB */

	/* SPI0 for EEPROM I/F */
	/* PA.0, PA.1, PA.2, PA.3 output set to L */
	GPIO_ENABLE_DOUT_MASK(PA, 0x0000FFF0);		/* PA.4~PA.15 DOUT write protect enabled */
	GPIO_SET_OUT_DATA(PA, 0x00000000u);
	GPIO_DISABLE_DOUT_MASK(PA, (ULONG)0x0000FFF0);		/* PA.4~PA.15 DOUT write protect disabled */
	/* Set GPA multi-function pins for SPI0_SS, SPI0_CLK, SPI0_MISO and SPI0_MOSI */
	SYS->GPA_MFPL &= ~(SYS_GPA_MFPL_PA3MFP_Msk | SYS_GPA_MFPL_PA2MFP_Msk | SYS_GPA_MFPL_PA1MFP_Msk | SYS_GPA_MFPL_PA0MFP_Msk);
	SYS->GPA_MFPL |= (SYS_GPA_MFPL_PA3MFP_SPI0_SS | SYS_GPA_MFPL_PA2MFP_SPI0_CLK | SYS_GPA_MFPL_PA1MFP_SPI0_MISO | SYS_GPA_MFPL_PA0MFP_SPI0_MOSI);

#if(ESS_DEMO_EVB)
	/* SPI2 ports: pin 8,9,10 & 11 */
	/* SPI2_SS(PA.11), SPI2_CLK(PA.10), SPI2_MISO(PA.9), SPI2_MOSI(PA.8) output set to L */
	GPIO_ENABLE_DOUT_MASK(PA, 0x0000F0FFu);		/* PA.0~PA.7, PA.12~PA.15 DOUT write protect enabled */
	GPIO_SET_OUT_DATA(PA, 0x00000000u);
	GPIO_DISABLE_DOUT_MASK(PA, (ULONG)0x0000F0FF);		/* PA.0~PA.7, PA.12~PA.15 DOUT write protect disabled */

	/* SPI2 for BMIC comm I/F */ 
	/* Configure PA.11 (pin8) SEN as output *//*Default: H, init: L */
	GPIO_SetMode(PA, BIT11, GPIO_MODE_OUTPUT);
	/* Set GPA multi-function pins for SPI2_CLK */
	SYS->GPA_MFPH &= ~(SYS_GPA_MFPH_PA10MFP_Msk);
	SYS->GPA_MFPH |= (SYS_GPA_MFPH_PA10MFP_SPI2_CLK);
	/* Set GPA multi-function pins for SPI2_MISO & SPI2_MOSI */
	SYS->GPA_MFPH &= ~(SYS_GPA_MFPH_PA9MFP_Msk | SYS_GPA_MFPH_PA8MFP_Msk);
	SYS->GPA_MFPH |= (SYS_GPA_MFPH_PA9MFP_SPI2_MISO | SYS_GPA_MFPH_PA8MFP_SPI2_MOSI);
	
#else
	/* SPI1 for BMIC SPI I/F */
	/* SPI1 ports: pin 18, 19, 20 & 21 */
	/* SEN(PA.6), SCL(PA.7) output set to L */
	GPIO_ENABLE_DOUT_MASK(PA, 0x0000FF3Fu);		/* PA.0~PA.5, PA.8~PA.15 DOUT write protect enabled */
	GPIO_SET_OUT_DATA(PA, 0x00000000u);
	GPIO_DISABLE_DOUT_MASK(PA, (ULONG)0x0000FF3F);		/* PA.0~PA.5, PA.8~PA.15 DOUT write protect disabled */

	/* SDI(PC.6), SDO(PC.7) output set to L */
	GPIO_ENABLE_DOUT_MASK(PC, 0x0000FF3Fu);		/* PC.0~PC.5, PC.8~PC.15 DOUT write protect enabled */
	GPIO_SET_OUT_DATA(PC, 0x00000000u);
	GPIO_DISABLE_DOUT_MASK(PC, (ULONG)0x0000FF3F);		/* PC.0~PC.5, PC.8~PC.15 DOUT write protect disabled */

	/* Configure PA.6 (pin21) SEN as output *//*Default: H, init: L */
	GPIO_SetMode(PA, BIT6, GPIO_MODE_OUTPUT);
	/* Set GPA multi-function pins for SPI1_CLK */
	SYS->GPA_MFPL &= ~(SYS_GPA_MFPL_PA7MFP_Msk);
	SYS->GPA_MFPL |= (SYS_GPA_MFPL_PA7MFP_SPI1_CLK);
	/* Set GPC multi-function pins for SPI1_MISO & SPI1_MOSI */
	SYS->GPC_MFPL &= ~(SYS_GPC_MFPL_PC7MFP_Msk | SYS_GPC_MFPL_PC6MFP_Msk);
	SYS->GPC_MFPL |= (SYS_GPC_MFPL_PC7MFP_SPI1_MISO | SYS_GPC_MFPL_PC6MFP_SPI1_MOSI);
#endif /* ESS_DEMO_EVB */
	/* CAN0 for CAN TRANCEIVER I/F */
	/* PB10, PB11 output set to L */
	PB10 = 0u;
	PB11 = 0u;
	/* Set GPB multi-function pins for CAN0_TXD and CAN0_RXD */
	SYS->GPB_MFPH &= ~(SYS_GPB_MFPH_PB11MFP_Msk | SYS_GPB_MFPH_PB10MFP_Msk);
	SYS->GPB_MFPH |= (SYS_GPB_MFPH_PB11MFP_CAN0_TXD | SYS_GPB_MFPH_PB10MFP_CAN0_RXD);

#if(0)	/* PB8(INT6), PB7(INT5), PB6(INT4) reserved INT, not use INT function, remain GPIO port */
	/* Set GPB multi-function pins for INT4, INT5, INT6 */
	SYS->GPB_MFPH &= ~(SYS_GPB_MFPH_PB8MFP_Msk);
	SYS->GPB_MFPH |= (SYS_GPB_MFPH_PB8MFP_INT6);
	SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB7MFP_Msk | SYS_GPB_MFPL_PB6MFP_Msk);
	SYS->GPB_MFPL |= (SYS_GPB_MFPL_PB7MFP_INT5 | SYS_GPB_MFPL_PB6MFP_INT4);
#endif

	/* Configure PB.8(BMIC_GPIO1) as input */
	GPIO_SetMode(PB, BIT8, GPIO_MODE_INPUT);
	/*GPIO_EnableInt(PB, 8, GPIO_INT_FALLING);*/

	/* Configure PB.7(BMIC_GPIO2) as input */
	GPIO_SetMode(PB, BIT7, GPIO_MODE_INPUT);
	/*GPIO_EnableInt(PB, 7, GPIO_INT_FALLING);*/

	/* Configure PB.2(BMIC_GPIO3) as input */
	GPIO_SetMode(PB, BIT2, GPIO_MODE_INPUT);

	/* Configure PB.6 (BMIC_GPIO4) as input */
	GPIO_SetMode(PB, BIT6, GPIO_MODE_INPUT);
	/*GPIO_EnableInt(PB, 6, GPIO_INT_RISING);*/

	/* Configure PB.5 (pin2) BMIC ALARM1 as input */
	GPIO_SetMode(PB, BIT5, GPIO_MODE_INPUT);

	/* Configure PD.3 (pin 41) DIP_SW1 as input mode */
	GPIO_SetMode(PD, BIT3, GPIO_MODE_INPUT);
	/* Configure PD.2 (pin 42) DIP_SW2 as input mode */
	GPIO_SetMode(PD, BIT2, GPIO_MODE_INPUT);
	/* Configure PD.1 (pin 43) DIP_SW3 as input mode */
	GPIO_SetMode(PD, BIT1, GPIO_MODE_INPUT);
	/* Configure PD.0 (pin 44) DIP_SW4 as input mode */
	GPIO_SetMode(PD, BIT0, GPIO_MODE_INPUT);

	/* Configure PB.4 (pin3) LED as output *//*Default: H, init: H(LED off) */
	GPIO_SetMode(PB, BIT4, GPIO_MODE_OUTPUT);
	/* Configure PB.3 (pin4) LED as output *//*Default: H, init: H(LED off) */
	GPIO_SetMode(PB, BIT3, GPIO_MODE_OUTPUT);
	/* Configure PF.6 (pin12) LED as output *//*Default: H, init: H(LED off) */
	GPIO_SetMode(PF, BIT6, GPIO_MODE_OUTPUT);
	/* Configure PC.5 (pin35) LED as output *//*Default: H, init: H(LED off) */
	GPIO_SetMode(PC, BIT5, GPIO_MODE_OUTPUT);

	/* Configure PC.4 (pin36) BMIC_SHDN as output *//*Default: H, init: L (active) */
	/*PC4*/GPIO_PORT_BMIC_SHDN = 0u;
	GPIO_SetMode(PC, BIT4, GPIO_MODE_OUTPUT);

	/* Configure PC.1 (pin39) BMIC_FETOFF as output *//*Default: H, init: L (normal) */
	/*PC1*/GPIO_PORT_BMIC_FETOFF = 0u;
	GPIO_SetMode(PC, BIT1, GPIO_MODE_OUTPUT);

	/* Configure PC.0 (pin40) as output *//*Default: H, init: L */
	PC0 = 0u;
	GPIO_SetMode(PC, BIT0, GPIO_MODE_OUTPUT);

	/* Configure PA.4 (pin26) I2C0_DAT as Open Drain Outport mode */
	GPIO_SetMode(PA, BIT4, GPIO_MODE_OPEN_DRAIN);
	/* Configure PA.5 (pin25) I2C0_CLK as Open Drain Outport mode */
	GPIO_SetMode(PA, BIT5, GPIO_MODE_OPEN_DRAIN);

	/* Configure PB.9 (pin62) CAN_STBY as output *//*Default: L, active: H */
	/*PB9*/GPIO_PORT_CAN_STBY = 0u;
	GPIO_SetMode(PB, BIT9, GPIO_MODE_OUTPUT);

#if(ESS_DEMO_EVB)
	GPIO_ENABLE_DOUT_MASK(PA, 0x00000F3Fu);			/* PA.0~PA.5, PA.8~PA.11 DOUT write protect enabled */
	GPIO_SET_OUT_DATA(PA, 0x00000000u);
	GPIO_DISABLE_DOUT_MASK(PA, (ULONG)0x00000F3F);			/* PA.0~PA.5, PA.8~PA.11 DOUT write protect disable */
	GPIO_SetMode(PA, BIT6 | BIT7 | BIT12 | BIT13 | BIT14 | BIT15, GPIO_MODE_OUTPUT);  /* PA.6, PA.7, PA.12~PA.15 set to output mode */

#else
	/* NC ports set to output L & output mode */
	/* NC ports: PA.8, PA.9, PA.10, PA.11, PA.12, PA.13, PA.14, PA.15 */
	GPIO_ENABLE_DOUT_MASK(PA, 0x000000FFu);			/* PA.0~PA.7 DOUT write protect enabled */
	GPIO_SET_OUT_DATA(PA, 0x00000000u);
	GPIO_DISABLE_DOUT_MASK(PA, (ULONG)0x000000FF);			/* PA.0~PA.7 DOUT write protect disable */
	GPIO_SetMode(PA, BIT8 | BIT9 | BIT10 | BIT11, GPIO_MODE_OUTPUT);  /* PA.8~PA.11 set to output mode */
	GPIO_SetMode(PA, BIT12 | BIT13 | BIT14 | BIT15, GPIO_MODE_OUTPUT);  /* PA.12~PA.15 set to output mode */
#endif /* ESS_DEMO_EVB */

	/* NC ports: PB.0, PB.1, PB.12, PB.13, PB.14, PB.15 */
	GPIO_ENABLE_DOUT_MASK(PB, 0x00000FFCu);			/* PB.2~PB.11 DOUT write protect enabled */
	GPIO_SET_OUT_DATA(PB, 0x00000000u);
	GPIO_DISABLE_DOUT_MASK(PB, (ULONG)0x00000FFC);			/* PB.2~PB.11 DOUT write protect disable */
	GPIO_SetMode(PB, BIT0 | BIT1 | BIT12 | BIT13 | BIT14 | BIT15, GPIO_MODE_OUTPUT);  /* PB.0, PB.1, PB.12~PB.15 set to output mode */

#if(ESS_DEMO_EVB)
	GPIO_ENABLE_DOUT_MASK(PC, 0x0000BF3Fu);		/* PC.0~PC.5, PC.8~PC.13, PC.15 DOUT write protect enabled */
	GPIO_SET_OUT_DATA(PC, 0x00000000u);
	GPIO_DISABLE_DOUT_MASK(PC, (ULONG)0x0000BF3F);		/* PC.0~PC.5, PC.8~PC.15 DOUT write protect disabled */
	/* NC Port: PC.6, PC.7, PC.14 (pin52) */
	GPIO_SetMode(PC, BIT6 | BIT7 | BIT14, GPIO_MODE_OUTPUT); /*PC.6, PC.7, PC.14 set to output mode */
#else
	PC14 = 0u;
	GPIO_SetMode(PC, BIT14, GPIO_MODE_OUTPUT);		/*PC.14 set to output mode */
#endif /* ESS_DEMO_EVB */

}

#if(0)
/*---------------------------------------------------------------------------------------------------------*/
/* Enable external interrupt 																				*/
/*---------------------------------------------------------------------------------------------------------*/
void vEnable_EINT(void)
{

	/* Enable interrupt de-bounce function and select de-bounce sampling cycle time is 1024 clocks of LIRC clock */
	GPIO_SET_DEBOUNCE_TIME(GPIO_DBCTL_DBCLKSRC_LIRC, GPIO_DBCTL_DBCLKSEL_1024);
	/* GPIO_ENABLE_DEBOUNCE(PB, BIT6); */
	/* GPIO_ENABLE_DEBOUNCE(PB, BIT7); */
	GPIO_ENABLE_DEBOUNCE(PB, BIT8);

	/* Set EIRQ4 priority */
	/*NVIC_SetPriority(EINT4_IRQn, 3);*/
	/* Set EIRQ5 priority */
	/* NVIC_SetPriority(EINT5_IRQn, 3);*/
	/* Set EIRQ6 priority */
	NVIC_SetPriority(EINT6_IRQn, 3);

	/* NVIC_EnableIRQ(EINT4_IRQn); */
	/* NVIC_EnableIRQ(EINT5_IRQn); */
	NVIC_EnableIRQ(EINT6_IRQn);

}
#endif

#if(0)
/****************************************************************************
FUNCTION	: EINT4_IRQHandler
DESCRIPTION	: MCU external interrupt from BMIC's GPIO3 - GPIO(default)/ADIRQ2 output state
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		:2023/04/28
*****************************************************************************/
void EINT4_IRQHandler(void)
{

    /* To check if PB.6 external interrupt occurred */
    if(GPIO_GET_INT_FLAG(PB, BIT6))
    {
        GPIO_CLR_INT_FLAG(PB, BIT6);
    }

}
#endif

#if(0)
/****************************************************************************
FUNCTION	: EINT5_IRQHandler
DESCRIPTION	: MCU external interrupt from BMIC's GPIO2 - ALARM2 output state
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		:2023/04/28
*****************************************************************************/
void EINT5_IRQHandler(void)
{

    /* To check if PB.7 external interrupt occurred */
    if(GPIO_GET_INT_FLAG(PB, BIT7))
    {
        GPIO_CLR_INT_FLAG(PB, BIT7);
    }

}
#endif

#if(0)
/****************************************************************************
FUNCTION	: EINT6_IRQHandler
DESCRIPTION	: MCU external interrupt from BMIC's GPIO1 - MCU INT OR output state
INPUT		: NONE
OUTPUT		: NONE
UPDATE		:
DATE		:2023/04/28
*****************************************************************************/
void EINT6_IRQHandler(void)
{

	/* To check if PB.8 external interrupt occurred */
	if(GPIO_GET_INT_FLAG(PB, BIT8))
	{
		GPIO_CLR_INT_FLAG(PB, BIT8);
	}

}
#endif

#if(PDMA_USED)
/*---------------------------------------------------------------------------------------------------------*/
/* PDMA init 																								*/
/*---------------------------------------------------------------------------------------------------------*/
void PDMA_Init(void)
{
	/* Enable PDMA clock source */
	CLK_EnableModuleClock(PDMA_MODULE);

	/* Open PDMA Channel */
	PDMA_Open(PDMA, 0u
#if(PCGUI_UART_TX_PDMA_USED)
	/* Channel 2 : UART3 TX - PC_GUI */
	|(1u << PCGUI_UART_TX_PDMA_CH)
#endif	/* PCGUI_UART_TX_PDMA_USED */
	);
	/* Enable PDMA interrupt */
#if(PCGUI_UART_TX_PDMA_USED)
	PDMA_EnableInt(PDMA,PCGUI_UART_TX_PDMA_CH, PDMA_INT_TRANS_DONE);
#endif	/* PCGUI_UART_TX_PDMA_USED */
	/* Set PDMA IRQ priority */
	NVIC_SetPriority(PDMA_IRQn, 10u);
	NVIC_EnableIRQ(PDMA_IRQn);
}

/**
 * @brief       DMA IRQ
 *
 * @param       None
 *
 * @return      None
 *
 * @details     The DMA default IRQ, declared in startup_M480.s.
 */
void PDMA_IRQHandler(void)
{
	uint32_t status = PDMA_GET_INT_STATUS(PDMA);

	if (status & 0x1u)   		/* abort */
	{

		#if(PCGUI_UART_TX_PDMA_USED)
		if (PDMA_GET_ABORT_STS(PDMA) & (1u << PCGUI_UART_TX_PDMA_CH))		/* PDMA Channel 2: PC GUI UART Tx */
		{
			vClearTxData();
			/* Disable UART3 TXPDMAEN */
			UART3->INTEN &= ~UART_INTEN_TXPDMAEN_Msk;
		}
		#endif	/* PCGUI_UART_TX_PDMA_USED */
		PDMA_CLR_ABORT_FLAG(PDMA,PDMA_GET_ABORT_STS(PDMA));
	}
	else if (status & 0x2u)     /* done */
	{

		#if(PCGUI_UART_TX_PDMA_USED)
		if ( PDMA_GET_TD_STS(PDMA) & (1u << PCGUI_UART_TX_PDMA_CH) )	/* PDMA Channel 2: PC GUI UART Tx */
		{
			vClearTxData();
			/* Disable UART3 TXPDMAEN */
			UART3->INTEN &= ~UART_INTEN_TXPDMAEN_Msk;
		}
		#endif	/* PCGUI_UART_TX_PDMA_USED */
		PDMA_CLR_TD_FLAG(PDMA,PDMA_GET_TD_STS(PDMA));
	}
	else if (status & 0x300u)     /* channel 0 & 1 timeout */
	{
		PDMA_CLR_TMOUT_FLAG(PDMA,0u);
		PDMA_CLR_TMOUT_FLAG(PDMA,1u);
	}
	#if(0)
	else{
		printf("unknown interrupt !!\n");
	}
	#endif
}
#endif	/* PDMA_USED */

/*** (C) COPYRIGHT 2016 Nuvoton Technology Corp. ***/
