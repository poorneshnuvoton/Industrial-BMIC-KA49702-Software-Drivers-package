/****************************************************************************
#ifdef DOC
File Name		:version.c
Description		:
Remark			:
Date			:2025/07/10
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/

/* application version info allocated to section .version *//* VER_MAJOR: 0~99, VER_MINOR: 0~99 */
const char appliversion[] __attribute__((section(".version"), used)) = "NuvotonBMSTotSolKA49702A\
V01.03\0";
