#ifndef DRV_TIMER_H_
#define DRV_TIMER_H_
/****************************************************************************
#ifdef DOC
File Name		:drv_timer.h
Description		:
Remark			:
Date			:2023/06/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/

/****************************************************************************
 define macro
*****************************************************************************/
#define	MAIN_LOOP_CNT		(25u)			/* 25ms main loop counter based on 1ms timer, 25ms/1ms  */

#define	BMS_CTL_TM_BASE		(MAIN_LOOP_CNT)				/* 25ms */
#define	BMS_CTL_TM_50MSEC	(50u/BMS_CTL_TM_BASE)		/* 50ms  */
#define	BMS_CTL_TM_75MSEC	(75u/BMS_CTL_TM_BASE)		/* 75ms  */
#define	BMS_CTL_TM_100MSEC	(100u/BMS_CTL_TM_BASE)		/* 100ms  */
#define	BMS_CTL_TM_125MSEC	(125u/BMS_CTL_TM_BASE)		/* 125ms  */
#define	BMS_CTL_TM_150MSEC	(150u/BMS_CTL_TM_BASE)		/* 150ms  */
#define	BMS_CTL_TM_200MSEC	(200u/BMS_CTL_TM_BASE)		/* 200ms  */
#define	BMS_CTL_TM_250MSEC	(250u/BMS_CTL_TM_BASE)		/* 250ms  */
#define	BMS_CTL_TM_300MSEC	(300u/BMS_CTL_TM_BASE)		/* 300ms  */
#define	BMS_CTL_TM_400MSEC	(400u/BMS_CTL_TM_BASE)		/* 400ms  */
#define	BMS_CTL_TM_500MSEC	(500u/BMS_CTL_TM_BASE)		/* 500ms  */
#define	BMS_CTL_TM_600MSEC	(600u/BMS_CTL_TM_BASE)		/* 600ms  */
#define	BMS_CTL_TM_700MSEC	(400u/BMS_CTL_TM_BASE)		/* 700ms  */
#define	BMS_CTL_TM_800MSEC	(800u/BMS_CTL_TM_BASE)		/* 800ms  */
#define	BMS_CTL_TM_900MSEC	(900u/BMS_CTL_TM_BASE)		/* 900ms  */
#define	BMS_CTL_TM_1SEC		(1000u/BMS_CTL_TM_BASE)		/* 1sec */
#define	BMS_CTL_TM_2SEC		(2000u/BMS_CTL_TM_BASE)		/* 2sec */
#define	BMS_CTL_TM_4SEC		(4000u/BMS_CTL_TM_BASE)		/* 4sec */
#define	BMS_CTL_TM_8SEC		(8000u/BMS_CTL_TM_BASE)		/* 8sec */

/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/


/****************************************************************************
 Variable declaration
*****************************************************************************/
extern volatile UCHAR ucMainLoopFlg;
extern volatile UCHAR ucLoop500msFlg;
extern volatile UCHAR ucLoop1secFlg;

/****************************************************************************
 Prototype declaration
*****************************************************************************/
extern void vTIMER_Init(void);

#endif /* DRV_TIMER_H_ */
