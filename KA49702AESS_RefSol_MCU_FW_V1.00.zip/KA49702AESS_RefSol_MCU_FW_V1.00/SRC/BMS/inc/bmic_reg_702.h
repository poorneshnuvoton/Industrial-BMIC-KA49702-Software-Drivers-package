#ifndef BMIC_REG_H
#define BMIC_REG_H
/****************************************************************************
#ifdef DOC
File Name		:bmic_reg_702.h
Description		:
Remark			:
Date			:2024/02/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/

/****************************************************************************
 define macro
*****************************************************************************/
/* BMIC 49702 Register Definition Start */
/* 					 				((UCHAR)0x00u) */	/* Reserved */
#define		PWR_CTRL_ADDR			((UCHAR)0x01u)	/* Operation mode control, ADC operation setting, LDM/VPC pin control */
#define		REG_INT_EN_ADDR			((UCHAR)0x02u)	/* INTx control, REG_EXT & VDD50 setting when standby/sleep/intermitten mode */
#define		SPIWD_CTRL_ADDR			((UCHAR)0x03u)	/* SPI watchdog timer setting/control, REG_EXT status when WDT expire */
#define		FDRV_CTRL_ADDR			((UCHAR)0x04u)	/* FDRV control settings */

#define		CVSEL1_ADDR				((UCHAR)0x05u)	/* Cell 01 ~ Cell 16 voltage measurement on/off select */
#define		CVSEL2_ADDR				((UCHAR)0x06u)	/* Cell 17 voltage measurement on/off select */
#define		GVSEL_ADDR				((UCHAR)0x07u)	/* VPACK_AD, TMONI1~6, VDD50, GPIOH1~2, VDD15, REGEXT, VREF2 voltage measurement on/off select */

#define		FUSE_CTL1_ADDR			((UCHAR)0x08u)	/* Chemical fuse control setting1 */
#define		FUSE_CTL2_ADDR			((UCHAR)0x09u)	/* Chemical fuse control setting2 */
#define		FUSE_CTL3_ADDR			((UCHAR)0x0Au)	/* Chemical fuse control setting3 */

#define		OVCTL1_ADDR				((UCHAR)0x0Bu)	/* OV detection threshold, hysteresis & delay setting */
#define		UVCTL1_ADDR				((UCHAR)0x0Cu)	/* UV detection threshold, hysteresis & delay setting */
#define		OTCCTL1_ADDR			((UCHAR)0x0Du)	/* OTC detection threshold, hysteresis & delay setting  */
#define		OTDCTL1_ADDR			((UCHAR)0x0Eu)	/* OTD detection threshold, hysteresis & delay setting  */
#define		UTCCTL1_ADDR			((UCHAR)0x0Fu)	/* UTC detection threshold, hysteresis & delay setting  */
#define		UTDCTL1_ADDR			((UCHAR)0x10u)	/* UTD detection threshold, hysteresis & delay setting  */


#define		OP_MODE_ADDR			((UCHAR)0x11u)	/* OV/UV detection on/off, CB on/off, ADC trigger, ADC result latch */

#define		GPIO_CTL1_ADDR			((UCHAR)0x12u) 	/* GPIO1 settings */
#define		GPIO_CTL2_ADDR			((UCHAR)0x13u)	/* GPIO2 settings */
#define		GPIO_CTL3_ADDR			((UCHAR)0x14u)	/* GPIO3 settings */
#define		GPIO_CTL4_ADDR			((UCHAR)0x15u)	/* GPIO4 settings */
#define		OSC_CTL_ADDR			((UCHAR)0x16u)	/* TMONI1~6 pull-up setting, OSCH_DIV/OSCL_DIV setting etc */

#define		ALARM_CTL1_ADDR			((UCHAR)0x17u)	/* ALARM1 pin select, SCD/OCD/OCC/CP enable */
#define		ALARM_CTL2_ADDR			((UCHAR)0x18u)	/* ALARM1 pin select, SCD/OCD/OCC/OTC/OTD/UTC/UTD enable */
#define		ALARM_CTL3_ADDR			((UCHAR)0x19u)	/* SCD/OCD/OCC detection threshold settings */
#define		ALARM_CTL4_ADDR			((UCHAR)0x1Au)	/* SCD/OCD/OCC delay settings */

#define		CBSEL_ADDR				((UCHAR)0x1Bu)	/* Cell balance select: Cell 01 ~ Cell 16 */
#define		CBSEL_17_ADDR			((UCHAR)0x1Cu)	/* Cell balance select: Cell 17, Meas-oriented CB enable & CB mask */

#define		ADCTL1_ADDR				((UCHAR)0x1Du)	/* SPI SEN/SCL/SDI pull-down settings, VDD50 regulator setting */
#define		ADCTL2_ADDR				((UCHAR)0x1Eu)	/* HS/LS Current ADC on/off select, V-I Sync setting, HS/LS ADC latch timigng setting */
#define		GPOH_CTL_ADDR			((UCHAR)0x1Fu) 	/* GPOH control settings */

#define		DIAG_EN_ADDR			((UCHAR)0x20u)	/* LS current ADC diagnosis on/off */

#define		MODESTAT_ADDR			((UCHAR)0x21u)	/* operation mode status, HS/LS current ADC & voltage ADC completion flag, charge/discharge FET status, GPOH1/2 state, GPIO1~4 input state */
#define		CELL1STAT_ADDR			((UCHAR)0x22u)	/* Cell 01 ~ Cell 16 voltage measurement on/off status */
#define		CELL2STAT_ADDR			((UCHAR)0x23u)	/* Cell 17 voltage measurement on/off status */
#define		PWRSTAT_ADDR			((UCHAR)0x24u)	/* VREF2, VDD50, REGEXT, VDD15, VPACK_AD, GPIOH1/2, TMONI1~6 voltage measurement on/off status */

#define		ANA_CTL_ADDR			((UCHAR)0x25u)	/* Transition to shutdown when abnormal high or low voltage detected at REGEXT, NPD_IND controls */

#define		STAT_ADDR				((UCHAR)0x26u)	/* TSD detection flag, OCC/OCD/SCD detection flags, sequence diagnosis result, SPI error flag, Fuse blow status */

#define		OVSTAT1_ADDR			((UCHAR)0x27u)	/* Cell 01 ~ Cell 16 OV detection status */
#define		OVSTAT2_ADDR			((UCHAR)0x28u)	/* Cell 17 OV detection status, OTD/OTC detection status */
#define		UVSTAT1_ADDR			((UCHAR)0x29u)	/* Cell 01 ~ Cell 16 UV detection status */
#define		UVSTAT2_ADDR			((UCHAR)0x2Au)	/* Cell 17 UV detection status, UTD/UTC detection status */

#define		BIASSTAT_ADDR			((UCHAR)0x2Bu)	/* VDD50, REG_EXT, VDD15, VREF1/2 OV/UV status flag */

#define		OTUTSTAT_ADDR			((UCHAR)0x2Cu)	/* OV/UV status, BIAS fault status, other fault status, UTC/UTD/OTC/OTD status, VPC event status, current event status, WDT timeout status */

#define		CV01_AD_ADDR			((UCHAR)0x2Du)	/* Cell01 Voltage measurement result */
#define		CV02_AD_ADDR			((UCHAR)0x2Eu)	/* Cell02 Voltage measurement result */
#define		CV03_AD_ADDR			((UCHAR)0x2Fu)	/* Cell03 Voltage measurement result */
#define		CV04_AD_ADDR			((UCHAR)0x30u)	/* Cell04 Voltage measurement result */
#define		CV05_AD_ADDR			((UCHAR)0x31u)	/* Cell05 Voltage measurement result */
#define		CV06_AD_ADDR			((UCHAR)0x32u)	/* Cell06 Voltage measurement result */
#define		CV07_AD_ADDR			((UCHAR)0x33u)	/* Cell07 Voltage measurement result */
#define		CV08_AD_ADDR			((UCHAR)0x34u)	/* Cell08 Voltage measurement result */
#define		CV09_AD_ADDR			((UCHAR)0x35u)	/* Cell09 Voltage measurement result */
#define		CV10_AD_ADDR			((UCHAR)0x36u)	/* Cell10 Voltage measurement result */
#define		CV11_AD_ADDR			((UCHAR)0x37u)	/* Cell11 Voltage measurement result */
#define		CV12_AD_ADDR			((UCHAR)0x38u)	/* Cell12 Voltage measurement result */
#define		CV13_AD_ADDR			((UCHAR)0x39u)	/* Cell13 Voltage measurement result */
#define		CV14_AD_ADDR			((UCHAR)0x3Au)	/* Cell14 Voltage measurement result */
#define		CV15_AD_ADDR			((UCHAR)0x3Bu)	/* Cell15 Voltage measurement result */
#define		CV16_AD_ADDR			((UCHAR)0x3Cu)	/* Cell16 Voltage measurement result */
#define		CV17_AD_ADDR			((UCHAR)0x3Du)	/* Cell17 Voltage measurement result */
#define		VPACK_AD_ADDR			((UCHAR)0x3Eu)	/* VPACK Voltage measurement result */
#define		TMONI1_AD_ADDR			((UCHAR)0x3Fu)	/* TMONI1 Voltage measurement result */
#define		TMONI2_AD_ADDR			((UCHAR)0x40u)	/* TMONI2 Voltage measurement result */
#define		TMONI3_AD_ADDR			((UCHAR)0x41u)	/* TMONI3 Voltage measurement result */
#define		TMONI4_AD_ADDR			((UCHAR)0x42u)	/* TMONI4 Voltage measurement result */
#define		TMONI5_AD_ADDR			((UCHAR)0x43u)	/* TMONI5 Voltage measurement result */
#define		TMONI6_AD_ADDR			((UCHAR)0x44u)	/* TMONI6 Voltage measurement result */
#define		GPIOH1_AD_ADDR			((UCHAR)0x45u)	/* GPIOH1 Voltage measurement result */
#define		GPIOH2_AD_ADDR			((UCHAR)0x46u)	/* GPIOH2 Voltage measurement result */
#define		CVIL_AD_ADDR			((UCHAR)0x47u)	/* Low-speed current ADC(Coulomb Counter) measurement result */
#define		CVIL2_AD_ADDR			((UCHAR)0x48u)	/* Low-speed current ADC(Wake Up Detector) measurement result */
#define		VDD15_AD_ADDR			((UCHAR)0x49u)	/* VDD18 Voltage measurement result */
#define		REGEXT_AD_ADDR			((UCHAR)0x4Au)	/* REGEXT Voltage measurement result */
#define		VREF2_AD_ADDR			((UCHAR)0x4Bu)	/* VREF2 Voltage measurement result */
#define		VDD50_AD_ADDR			((UCHAR)0x4Cu)	/* VDD50 Voltage measurement result */

#define		OVL_STAT1_ADDR			((UCHAR)0x4Du)	/* Cell OV detection flag (Cell 1 ~ Cell 16) */
#define		OVL_STAT2_ADDR			((UCHAR)0x4Eu)	/* Cell OV detection flag (Cell 17), OTD/OTD 1~5 */

#define		UVL_STAT1_ADDR			((UCHAR)0x4Fu)	/* Cell UV detection flag (Cell 1 ~ Cell 16) */
#define		UVL_STAT2_ADDR			((UCHAR)0x50u)	/* Cell UV detection flag (Cell 17) UTD/UTD 1~5 */

#define		CBSTAT1_ADDR			((UCHAR)0x51u)	/* Cell Balance control status 1 (Cell 1~16)*/
#define		CBSTAT2_ADDR			((UCHAR)0x52u)	/* Cell Balance control status 2 (Cell 17) */

#define		FUSE_BLOW_ADDR			((UCHAR)0x53u)	/* Fuse blow function activation */
#define		AUTO_CTL_ADDR			((UCHAR)0x54u)	/* det cur lvl to exit STB/LP mode, Period of cur measurement & no. of times to judge the lvl in STB/LB mode */
#define		OTUT_CTRL_ADDR			((UCHAR)0x55u)	/* CHG/DIS FET response to ALARM(OTC/OTC/UTC/UTD) Condition, current threshold for switching between charging & discharging */
/*#define							((UCHAR)0x56u) */	/* Reserved */
#define		TMONI1_ADDR				((UCHAR)0x57u)	/* TMONI1 pin pull-up resistance value (absolute value) */
#define		TMONI23_ADDR			((UCHAR)0x58u)	/* TMONI2 & TMONI3 pin pull-up resistance value (difference) */
#define		TMONI45_ADDR			((UCHAR)0x59u)	/* TMONI4 & TMONI5 pin pull-up resistance value (difference) */
#define		TMONI6_ADDR				((UCHAR)0x5Au)	/* TMONI6 pin pull-up resistance value (difference) */
#define		OTCTL2_ADDR				((UCHAR)0x5Bu)	/* Over-Temperature-in-Discharge/Charge Detection Threshold */
#define		UTCTL2_ADDR				((UCHAR)0x5Cu)	/* Under-Temperature-in-Discharge/Charge Detection Threshold */

#define		BMIC_REG_MAX_ADDR		UTCTL2_ADDR
#define		BMIC_REG_TOTNUM			(BMIC_REG_MAX_ADDR - PWR_CTRL_ADDR + 1u)		/* total number of BMIC registers: 0x01 ~ 0x5C (92) */
/* BMIC 49702 Register Definition End */

/* BMIC 49702 Control / Status Register Bit Definition Start */
/* PWR_CTRL_ADDR(0x01u) */
#define		NPD_RST						((USHORT)0x0000u)	/* b0: Soft Reset */
#define		NPD_RST_MASK				((USHORT)0x0001u)	/* b0: Soft Reset Mask */
#define		MSET_SHDN					((USHORT)0x0002u)	/* b1: Shutdown control  */
#define		MSET_SHDN_MASK				((USHORT)0x0002u)	/* b1: Shutdown control MASK */
#define		MSET_SLP					((USHORT)0x0004u)	/* b2: Sleep mode control */
#define		MSET_SLP_MASK				((USHORT)0x0004u)	/* b2: Sleep mode control MASK */
#define		MSET_LP						((USHORT)0x0008u)	/* b3: Low power mode control */
#define		MSET_LP_MASK				((USHORT)0x0008u)	/* b3: Low power mode control MASK */
#define		MSET_STB					((USHORT)0x0010u)	/* b4: Standby mode control */
#define		MSET_STB_MASK				((USHORT)0x0010u)	/* b4: Standby mode control MASK */

#define		MSET_MODE_MASK				((USHORT)0x001Eu)	/* b4~b1: mode MASK */

#define		ADC_CONT					((USHORT)0x8000u)	/* b15: ADC Operation Setting, 1 - Continuous mode (Voltage and HS current measurement done repeatedly during Active mode), 0 - Oneshot mode (Voltage and HS current measurement only when ADC_TRG is set) */
#define		INTM_TIM2_MASK				((USHORT)0x0060u)	/* b[6:5] : intermittent operation in Stby/LP mode setting time */
#define		INTM_TIM2_1S				((USHORT)0x0000u)	/* b[6:5] : 00 : 1 sec */
#define		INTM_TIM2_2S				((USHORT)0x0020u)	/* b[6:5] : 01 : 2 sec */
#define		INTM_TIM2_4S				((USHORT)0x0040u)	/* b[6:5] : 10 : 4 sec */
#define		INTM_TIM2_8S				((USHORT)0x0060u)	/* b[6:5] : 11 : 8 sec */

/* FDRV_CTRL_ADDR(0x04u) */
#define		FDRVH_EN					((USHORT)0x0080u)	/* b7: FDRVH: ON (FDRVH enable), OFF (FDRVH disable) */
#define		FDRV_STBY_OFF				((USHORT)0x0000u)	/* b8: FET standby mode : OFF (Normal)(default) */
#define		FDRV_STBY_ON				((USHORT)0x0100u)	/* b8: FET standby mode : ON (Standby) */
#define		FDRV_STBY_MASK				((USHORT)0x0100u)	/* b8: FET standby MASK */
#define		FDRV_DIS_FET_OFF			((USHORT)0x0000u)	/* b9: DIS FET control : OFF(default) */
#define		FDRV_DIS_FET_ON				((USHORT)0x0200u)	/* b9: DIS FET control : ON */
#define		FDRV_DIS_FET_MASK			((USHORT)0x0200u)	/* b9: DIS FET MASK */
#define		FDRV_CHG_FET_OFF			((USHORT)0x0000u)	/* b10: CHG FET control : OFF(default) */
#define		FDRV_CHG_FET_ON				((USHORT)0x0400u)	/* b10: CHG FET control : ON */
#define		FDRV_CHG_FET_MASK			((USHORT)0x0400u)	/* b10: CHG FET MASK */
#define		FDRV_ALM_CLR				((USHORT)0x2000u)	/* b13: FDRV_ALM_CLR 1: CHG/DIS FET and GPOH pins recover */

/* OP_MODE_ADDR(0x11u) */
#define		ADV_LATCH_ON				((USHORT)0x0001u)	/* b0: ADC value latch request : Cell voltage ON */
#define		ADIL_LATCH_ON				((USHORT)0x0004u)	/* b2: ADC value latch request : Low speed current ON */
#define		ADC_TRG_ON					((USHORT)0x0010u)	/* b4: ADC 1 shot trigger : ON */
#define		OVMSK_ON					((USHORT)0x0000u)	/* b6: OV detection : ON (default) */
#define		OVMSK_OFF					((USHORT)0x0040u)	/* b6: OV detection : OFF */
#define		UVMSK_ON					((USHORT)0x0000u)	/* b7: UV detection : ON (default) */
#define		UVMSK_OFF					((USHORT)0x0080u)	/* b7: UV detection : OFF */
#define		OTCMSK_ON					((USHORT)0x0000u)	/* b8: OTC detection : ON (default) */
#define		OTCMSK_OFF					((USHORT)0x0100u)	/* b8: OTC detection : OFF */
#define		OTDMSK_ON					((USHORT)0x0000u)	/* b9: OTD detection : ON (default) */
#define		OTDMSK_OFF					((USHORT)0x0200u)	/* b9: OTD detection : OFF */
#define		UTCMSK_ON					((USHORT)0x0000u)	/* b10: UTC detection : ON (default) */
#define		UTCMSK_OFF					((USHORT)0x0400u)	/* b10: UTC detection : OFF */
#define		UTDMSK_ON					((USHORT)0x0000u)	/* b11: UTD detection : ON (default) */
#define		UTDMSK_OFF					((USHORT)0x0800u)	/* b11: UTD detection : OFF */
#define		OTUTMSK_MASK				((USHORT)0x0F00u)	/* b8~11: UTD|UTC|OTD|OTC detection ON/OFF */
#define		CB_SET_ON					((USHORT)0x1000u)	/* b12: Cell balancing operation : ON */
#define		CB_SET_OFF					((USHORT)0x0000u)	/* b12: Cell balancing operation : OFF (default) */
#define		TMONISEL_MSK				((USHORT)0x4000u)	/* b14: TMONISEL 0: (GROUP1)TMONI1,2,3,5, (GROUPT2)TMONI4,6, 1: (GROUP1)TMONI1,2,5, (GROUT2)TMONI3,4,6 */

/* GPIO_CTL1_ADDR(0x12u) */
/* GPIO_CTL2_ADDR(0x13u) */
/* GPIO_CTL3_ADDR(0x14u) */
/* GPIO_CTL4_ADDR(0x15u) */
#define		GPIO_IE						((USHORT)0x0001u)	/* b0: GPIOx Pin Input Enable */
#define		GPIO_NOE					((USHORT)0x0002u)	/* b1: GPIOx Pin Output Enable */
#define		GPIO_OD						((USHORT)0x0008u)	/* b3: GPIOx Pin Output Configuration */
#define		GPIO_OUT					((USHORT)0x0010u)	/* b4: GPIOx Pin digital output data */
#define		GPIO_CHDRV					((USHORT)0x0020u)	/* b5: GPIOx Pin Output drivability */
#define		GPIOSEL_MASK				((USHORT)0x1F00u)	/* b8~b12: GPIOx Pin Output selection */
#define		GPIOSEL_GPIO				((USHORT)0x0000u)	/* b8~b12: GPIOx Pin Output selection - 00000 GPIO(General) (Default) */
#define		GPIOSEL_GPOH1				((USHORT)0x0100u)	/* b8~b12: GPIOx Pin Output selection - 00001 GPOH1 Data output */
#define		GPIOSEL_GPOH2				((USHORT)0x0200u)	/* b8~b12: GPIOx Pin Output selection - 00010 GPOH2 Data output */
#define		GPIOSEL_ADIRQ1				((USHORT)0x0300u)	/* b8~b12: GPIOx Pin Output selection - 00011 ADIRQ1 output */
#define		GPIOSEL_ADIRQ2				((USHORT)0x0400u)	/* b8~b12: GPIOx Pin Output selection - 00100 ADIRQ2 output */
#define		GPIOSEL_HOSC				((USHORT)0x0500u)	/* b8~b12: GPIOx Pin Output selection - 00101 High speed OSC divided output */
#define		GPIOSEL_LOSC				((USHORT)0x0600u)	/* b8~b12: GPIOx Pin Output selection - 00110 Low speed OSC divided output */
#define		GPIOSEL_ACT					((USHORT)0x0700u)	/* b8~b12: GPIOx Pin Output selection - 00111 Active mode state output */
#define		GPIOSEL_STB					((USHORT)0x0800u)	/* b8~b12: GPIOx Pin Output selection - 01000 Standby mode state output */
#define		GPIOSEL_LP					((USHORT)0x0900u)	/* b8~b12: GPIOx Pin Output selection - 01001 Low Power mode state output */
#define		GPIOSEL_FUSEFET				((USHORT)0x0A00u)	/* b8~b12: GPIOx Pin Output selection - 01010 FUSE FET output */
#define		GPIOSEL_ALARM2				((USHORT)0x0B00u)	/* b8~b12: GPIOx Pin Output selection - 01011 Alarm2 output */
/*#define								((USHORT)0x0C00u) */	/* b8~b12: GPIOx Pin Output selection - 01100 prohibited */
#define		GPIOSEL_MCUINTOR			((USHORT)0x0D00u)	/* b8~b12: GPIOx Pin Output selection - 01101 MCU INT OR output */
#define		GPIOSEL_FETOFF2IN			((USHORT)0x0E00u)	/* b8~b12: GPIO1 Pin selection - 01110 FETOFF2 input */
#define		GPIOSEL_CHGOFFBOOST			((USHORT)0x0E00u)	/* b8~b12: GPIO2/3/4 Pin selection - 01110 CHG fall_time boost */
/*#define								((USHORT)0x0F00u) */	/* b8~b12: GPIOx Pin Output selection - 01111 prohibited */
#define		GPIOSEL_TMONI				((USHORT)0x1000u)	/* b8~12:  GPIOx Pin function selection -10000 TMONIx */
#define		GPIOSEL2_MASK				((USHORT)0x1000u)	/* b12: GPIOx Pin function selection - 0 GPIOx (default), 1 TMONIx */

/* OSC_CTL_ADDR(0x16u) */
#define		OSCL_DIV_MASK				((USHORT)0x0100u)	/* b8 OSCL_DIV 1: 1/64=4.096kHz(Default) 0: 1/1=262.144kHz */
#define		OSCH_DIV_MASK				((USHORT)0x0200u)	/* b9 OSCH_DIV 1: 1/512=40kHz(Default) 0: 1/128=160kHz */
#define		OSCH_GATE_EN				((USHORT)0x0800u)
#define		TSD_F_SET_MASK				((USHORT)0x2000u)	/* b13 TSD_F_SET 1: No change(Default) 0: Shutdown immediately */
#define		OVP_F_SET_MASK				((USHORT)0x4000u)	/* b14 OVP_F_SET 1: No change(Default) 0: Shutdown immediately */

/* ALARM_CTL1_ADDR(0x17u) */
#define		EN_CP						((USHORT)0x0001u)	/* b0: Current Protection 1: Enable, 0: Disable */
#define		EN_OCC						((USHORT)0x0002u)	/* b1: Overcurrent detection at charge 1: Enable, 0: Disable */
#define		EN_OCD						((USHORT)0x0004u)	/* b2: Overcurrent detection at discharge 1: Enable, 0: Disable */
#define		EN_SCD						((USHORT)0x0008u)	/* b3: Short circuit detection at discharge 1: Enable, 0: Disable */

/* CBSEL_17_ADDR(0x1Cu) */
#define		EN_MSOCB					((USHORT)0x0100u)	/* CBSEL_17(0x1Cu): b[8] Measurement-oriented cell balance 1-enable, 0-disable(default) */
#define		CB_MSK2_MASK				((USHORT)0xFE00u)	/* CBSEL_17(0x1Cu): b[9~15] Duration to prevent cell balancing before cell voltage measurement */

/* ADCTL1_ADDR(0x1Du) */
#define		NPD_CB_NORMAL				((USHORT)0x0001u)	/* b0: NPD_CB cell balance control power down, 1 - Normal */
#define		NPD_CB_POWERDOWN			((USHORT)0x0000u)	/* b0: NPD_CB cell balance control power down, 0 - Power down(default) */
#define		NPD_CB_MASK					((USHORT)0x0001u)	/* b0: NPD_CB MASK */
#define		PD_REG50_ON					((USHORT)0x0040u)	/* b6: VDD50 regulator power down ON */
#define		PD_REG50_OFF				((USHORT)0x0000u)	/* b6: VDD50 regulator power down OFF (normal) */
#define		PD_REG50_MASK				((USHORT)0x0040u)	/* b6: VDD50 regulator power down */

/* ADCTL2_ADDR (0x1Eu) */
#define		ADIL2_ON					((USHORT)0x0001u)	/* b0: Enable current ADC(wake-up detector) operation */
#define		ADIL_ON						((USHORT)0x0002u)	/* b1: Enable current ADC(Coulomb Counter) operation */
#define		ADV_LATCH_SET				((USHORT)0x0004u)	/* b2: Voltage measurement ADC data latch timing setting: 1 (Synchronous update), 0 (Instant update - default) */
#define		ADV_AVE2_MASK				((USHORT)0x00C0u)	/* b6~7: ADV_AVE2 - voltage measurement average option for VPACK, GPIOH1, GPIOH2 */
#define		ADV_AVE_MASK				((USHORT)0x0600u)	/* b9~10: ADV_AVE - voltage measurement average option for cell voltage */
#define 	ADSWSD_EN					((USHORT)0x1000u)	/* b12: Current ADC input switch enable */
#define		ADILSEL_MASK				((USHORT)0x6000u)	/* b13~14: selection of current ADC converstion time */
#define		ADIL_STB_EN					((USHORT)0x8000u)	/* b15: ADIL_STB_EN Current ADC stop control in Standby/LowSpeed mode: 1(Continuous operation), 0(No operation - default) */

/* GPOH_CTL_ADDR(0x1Fu) */
#define		GPOH1_LOW					((USHORT)0x0001u)	/* b0 GPOH1 control : LOW */
#define		GPOH1_HIZ					((USHORT)0x0000u)	/* b0 GPOH1 control : HiZ */
#define		GPOH1_MASK					((USHORT)0x0001u)	/* b0 GPOH1 MASK */
#define		GPOH2_LOW					((USHORT)0x0002u)	/* b1 GPOH2 control : LOW */
#define		GPOH2_HIZ					((USHORT)0x0000u)	/* b1 GPOH2 control : HiZ */
#define		GPOH2_MASK					((USHORT)0x0002u)	/* b1 GPOH2 MASK */
#define		GPOH_FET_MASK				((USHORT)0x0004u)	/* b2 GPOH FET MASK */
#define		GPOH_FET_FET				((USHORT)0x0004u)	/* b2 GPOH FET : USE_FET */
#define		GPOH1_ALM_ST_LOW			((USHORT)0x0000u)	/* b4 GPOH1 data during ALARM: LOW output */
#define		GPOH1_ALM_ST_HI				((USHORT)0x0010u)	/* b4 GPOH1 data during ALARM: HIGH output */
#define		GPOH1_ALM_ST_MASK			((USHORT)0x0010u)	/* b4 GPOH1 data during ALARM MASK */
#define		GPOH2_ALM_ST_LOW			((USHORT)0x0000u)	/* b5 GPOH2 data during ALARM: LOW output */
#define		GPOH2_ALM_ST_HIZ			((USHORT)0x0020u)	/* b5 GPOH2 data during ALARM: HIGH output */
#define		GPOH2_ALM_ST_MASK			((USHORT)0x0020u)	/* b5 GPOH2 data during ALARM MASK */

/* DIAG_EN_ADDR(0x20u) */
#define		DIAG_ISD_EN					((USHORT)0x0020u)	/* b5 Diagnosis for Low Speed Current ADC */

/* MODESTAT_ADDR(0x21u) */
#define		MODE_ST_MASK				((USHORT)0x001Fu)	/* MODESTAT(0x21u) : Bit[4~0] operation mode flags */
#define		MODE_ST_ACT					((USHORT)0x0001u)	/* MODESTAT(0x21u) : Bit[0] Active Mode */
#define		MODE_ST_LP					((USHORT)0x0008u)	/* MODESTAT(0x21u) : Bit[3] Low Power Mode */
#define		MODE_ST_INTM				((USHORT)0x0010u)	/* MODESTAT(0x21u) : Bit[4] Intermitten Mode */
#define		VAD_DONE					((USHORT)0x0020u)	/* MODESTAT(0x21u) : Bit[5] Voltage measurement ADC completion flag */
#define		AUTO_ST						((USHORT)0x0040u)	/* MODESTAT(0x21u) : Bit[6] Current judgement status, 0: Low current (current < AUTO_ITHU), 1: High current (current > AUTO_ITHU) */
#define		IADS_DONE					((USHORT)0x0080u)	/* MODESTAT(0x21u) : Bit[7] Low speed current measurement ADC completion flag */
#define		GPOH1_ST_MASK				((USHORT)0x0100u)	/* MODESTAT(0x21u)	: Bit[8] GPOH1 state */
#define		GPOH2_ST_MASK				((USHORT)0x0200u)	/* MODESTAT(0x21u) : Bit[9] GPOH2 state */
#define		FDRV_CHG_ST_MASK			((USHORT)0x0400u)	/* MODESTAT(0x21u)	: Bit[10] FDRV_CHG_ST */
#define		FDRV_DIS_ST_MASK			((USHORT)0x0800u)	/* MODESTAT(0x21u)	: Bit[11] FDRV_DIS_ST */
#define		ST_GPIO3_MASK				((USHORT)0x4000u)	/* MODESTAT(0x21u)	: Bit[14] ST_GPIO3 */
#define		ST_GPIO4_MASK				((USHORT)0x8000u)	/* MODESTAT(0x21u)	: Bit[15] ST_GPIO4 */

/* ANA_CTL_ADDR(0x25u) */
#define		UVP_F_SET_REGEXT			((USHORT)0x0002u)	/* ANA_CTL(0x25u) : Bit[1] UVP_F_SET_REGEXT Transition to shutdown when abnormal low voltage is detected at REGEXT, 1: No change (Default), 0: Shutdown immediately */
#define		FDRVL_PD					((USHORT)0x0020u)	/* ANA_CTL(0x25u) : Bit[5] FDRVL_PD FDRV Low Side Driver CHG/DIS Output Pull-down Function, 0: Disable (Default), 1: Enable*/
#define		FDRVL_CPOFF					((USHORT)0x0040u)	/* ANA_CTL(0x25u) : Bit[6] FDRVL_CPOFF FDRV Low Side Driver Charge-Pump Operation, 0: Enable (Default), 1: Disable*/
#define		NPD_IND						((USHORT)0x0800u)	/* ANA_CTL(0x25u) : Bit[11] NPD_IND IND Enable control 0: Disable (Default), 1: Enable */
#define 	IND_SRPDIAG					((USHORT)0x1000u)	/* ANA_CTL(0x25u) : Bit[12] IND SRP diagnostic current enable control 0: Disable (Default), 1: Enable */
#define		IND_SRNDIAG					((USHORT)0x2000u)	/* ANA_CTL(0x25u) : Bit[13] IND SRN diagnostic current enable control 0: Disable (Default), 1: Enable */
#define		IND_SRPPD					((USHORT)0x4000u)	/* ANA_CTL(0x25u) : Bit[14] IND SRP diagnostic pull-down enable control 0: Disable (Default), 1: Enable */
#define		IND_SRNPD					((USHORT)0x8000u)	/* ANA_CTL(0x25u) : Bit[15] IND SRN diagnostic pull-down enable control 0: Disable (Default), 1: Enable */

/* STAT_ADDR(0x26u) */
#define		SPI_F_MASK					((USHORT)0x0100u)	/* STAT(0x26u) : Bit[8] SPI_F    					*/
#define		FUSEB_F						((USHORT)0x0200u)	/* STAT(0x26u) : Bit[9] FUSEB_F		*/
#define		MUX1A_F_MASK				((USHORT)0x0400u)	/* STAT(0x26u) : Bit[10] MUX1A_F						*/
#define		ST_CHG_DIS					((USHORT)0x1000u)	/* STAT(0x26u) : Bit[12] ST_CHG_DIS, 1: Charge, 0: Discharge */
#define		ST_OCC_MASK					((USHORT)0x2000u)	/* STAT(0x26u) : Bit[13] ST_OCC						*/
#define		ST_OCD_MASK					((USHORT)0x4000u)	/* STAT(0x26u) : Bit[14] ST_OCD						*/
#define		ST_SCD_MASK					((USHORT)0x8000u)	/* STAT(0x26u) : Bit[15] ST_SCD						*/
#define		STAT_SCD_OCD_OCC_MASK		((USHORT)0xE000u)	/* STAT(0x26u) : Bit[15~13] ST_SCD, ST_OCD, ST_OCC	*/

/* BIASSTAT_ADDR(0x2Bu) */
#define		LBIAS3D_MASK				((USHORT)0x0001u)	/* BIASSTAT(0x2Bu) : Bit[0] LBIAS3D */
#define		HBIAS3D_MASK				((USHORT)0x0002u)	/* BIASSTAT(0x2Bu) : Bit[1] HBIAS3D */
#define		HBIAS3A_MASK				((USHORT)0x0004u)	/* BIASSTAT(0x2Bu) : Bit[2] HBIAS3A */
#define		LBIAS2D_MASK				((USHORT)0x0008u)	/* BIASSTAT(0x2Bu) : Bit[3] LBIAS2D */
#define		HBIAS2D_MASK				((USHORT)0x0010u)	/* BIASSTAT(0x2Bu) : Bit[4] HBIAS2D */
#define		LBIAS2A_MASK				((USHORT)0x0020u)	/* BIASSTAT(0x2Bu) : Bit[5] LBIAS2A */
#define		LBIAS1D_MASK				((USHORT)0x0040u)	/* BIASSTAT(0x2Bu) : Bit[6] LBIAS1D */
#define		HBIAS1D_MASK				((USHORT)0x0080u)	/* BIASSTAT(0x2Bu) : Bit[7] HBIAS1D */
#define		HBIAS1A_MASK				((USHORT)0x0100u)	/* BIASSTAT(0x2Bu) : Bit[8] HBIAS1A */
#define		LVREF2_MASK					((USHORT)0x0200u)	/* BIASSTAT(0x2Bu) : Bit[9] LVREF2 */
#define		HVREF2_MASK					((USHORT)0x0400u)	/* BIASSTAT(0x2Bu) : Bit[10] HVREF2 */

/* OTUTSTAT_ADDR(0x2Cu) */
#define		ST_UV_MASK					((USHORT)0x0001u)	/* OTUTSTAT(0x2Cu): Bit[0] ST_UV			*/
#define		ST_OV_MASK					((USHORT)0x0002u)	/* OTUTSTAT(0x2Cu): Bit[1] ST_OV			*/
#define		ST_OVUV_MASK				((USHORT)0x0003u)	/* OTUTSTAT(0x2Cu): Bit[1~0] ST_OV, ST_UV	*/
#define		ST_BIAS						((USHORT)0x0004u)	/* OTUTSTAT(0x2Cu): Bit[2] ST_BIAS		*/
#define		ST_OTH						((USHORT)0x0008u)	/* OTUTSTAT(0x2Cu): Bit[3] ST_OTH		*/
#define		ST_UTC						((USHORT)0x0010u)	/* OTUTSTAT(0x2Cu): Bit[4] ST_UTC		*/
#define		ST_UTD                      ((USHORT)0x0020u)   /* OTUTSTAT(0x2Cu): Bit[5] ST_UTD		*/
#define		ST_OTC                      ((USHORT)0x0040u)   /* OTUTSTAT(0x2Cu): Bit[6] ST_OTC		*/
#define		ST_OTD                      ((USHORT)0x0080u)   /* OTUTSTAT(0x2Cu): Bit[7] ST_OTD		*/
#define		ST_OTUT_MASK				((USHORT)0x00F0u)	/* OTUTSTAT(0x2Cu): Bit[7~4] ST_OTD, ST_OTC, ST_UTD, ST_UTC */
#define		VPC_L_F						((USHORT)0x0100u)	/* OTUTSTAT(0x2Cu): Bit[8] VPC_L_F		*/
#define		VPC_H_F						((USHORT)0x0200u)	/* OTUTSTAT(0x2Cu): Bit[9] VPC_H_F		*/
/* #define		Reserved				((USHORT)0x0400u)	*//* OTUTSTAT(0x2Cu): Bit[10] Reserved	*/
/* #define		Reserved				((USHORT)0x0800u)	*//* OTUTSTAT(0x2Cu): Bit[11] Reserved	*/
#define		CUR_H_F						((USHORT)0x1000u)	/* OTUTSTAT(0x2Cu): Bit[12] CUR_H_F	*/
#define		WDT_F						((USHORT)0x2000u)	/* OTUTSTAT(0x2Cu): Bit[13] WDT_F		*/
#define		OTUTSTAT_VPC_CUR_WDT_MASK	((USHORT)0x3300u)	/* OTUTSTAT(0x2Cu): Bit[13~8] VPC, CUR, WDT flgs		*/
#define		VPC_DET_F					((USHORT)0x4000u)	/* OTUTSTAT(0x2Cu): Bit[14] VPC_DET_F*/
/* #define		Reserved				((USHORT)0x8000u)	*//* OTUTSTAT(0x2Cu): Bit[15] Reserved*/

/* OVL_STAT2_ADDR(0x4Eu) */
#define		OV17_LF_MASK				((USHORT)0x0001u)	/* OVL_STAT2(0x4Eu): Bit[0] OV17_LF */
#define		OTC_LF_MASK					((USHORT)0x007Eu)	/* OVL_STAT2(0x4Eu): Bit[6~1] OTC6_LF,OTC5_LF,OTC4_LF,OTC3_LF,OTC2_LF,OTC1_LF */
#define		OTD_LF_MASK					((USHORT)0x1F80u)	/* OVL_STAT2(0x4Eu): Bit[12~7] OTD6_LF,OTD5_LF,OTD4_LF,OTD3_LF,OTD2_LF,OTD1_LF */

/* UVL_STAT2_ADDR(0x50u) */
#define		UV17_LF_MASK				((USHORT)0x0001u)	/* UVL_STAT2(0x50u): Bit[0] UV17_LF */
#define		UTC_LF_MASK					((USHORT)0x007Eu)	/* UVL_STAT2(0x50u): Bit[6~1] UTC6_LF,UTC5_LF,UTC4_LF,UTC3_LF,UTC2_LF,UTC1_LF */
#define		UTD_LF_MASK					((USHORT)0x1F80u)	/* UVL_STAT2(0x50u): Bit[12~7] UTD6_LF,UTD5_LF,UTD4_LF,UTD3_LF,UTD2_LF,UTD1_LF */

/* AUTO_CTL_ADDR(0x54u) */
#define		AUTO_ITHU_MASK				((USHORT)0x00FFu)	/* AUTO_CTL(0x54u): Bit[0~7] AUTO_ITHU detection current level to exit Standby/LowPower mode */
#define		INTM_TIM3_MASK				((USHORT)0x0300u)	/* AUTO_CTL(0x54u): Bit[8~9] Period of current measurement (wake up) */
#define		AUTO_CNTL_MASK				((USHORT)0x3000u)	/* AUTO_CTL(0x54u): Bit[12~13] Number of times to judge the current level to exit Standby/LowPower mode */

/* OTUT_CTRL_ADDR(0x55u) */
#define		OTUT_ITH_MASK				((USHORT)0x00FFu)	/* OTUT_CTRL(0x55u): Bit[0~7] OTUT_ITH current threshold for switching between charging and discharging */
#define		FDRV_ALM_CLR2				((USHORT)0x2000u)	/* OTUT_CTRL(0x55u): Bit[13] CHG/DIS FET recover when Alarm(OTC/OTD/UTC/UTD) condition removed */
#define		FDRV_ALM_RCV2				((USHORT)0x4000u)	/* OTUT_CTRL(0x55u): Bit[14] CHG/DIS FET recover when Alarm(OTC/OTD/UTC/UTD) condition removed - depend on FDRV_ALM_CLR2 */
#define		FDRV_ALM_SD2				((USHORT)0x8000u)	/* OTUT_CTRL(0x55u): Bit[15] CHG/DIS FET response to Alarm(OTC/OTD/UTC/UTD) condition */

/* BMIC 49702 Control / Status Register Bit Definition End */

/* BMIC Control Register Initial value definition start */
#define	PWR_CTRL_INI		(0x9241u)		/* initial settings: ADC_CONT ON, bp14~13(INTM_TIM)"00", bp12~11 "10", bp9(DIS_AUTO_MODE)"1", bp6~5(INTM_TIM2) "10", bp0(NPD_RST) "1" */

#define	REG_INT_EN_INI		(0x0F00u)		/* initial settng: Enable INT1(charger detection), select REGEXT OV detection voltage 3.6V  */

#ifdef USE_BMIC_SPI_WDT
#define	SPIWD_CTRL_INI		(0x103Bu)		/* SPIWD used */
#else
#define	SPIWD_CTRL_INI		(0x003Bu)		/* SPIWD not use	*/
#endif

/*#define	FDRV_CTRL_INI	(0x1000u) */	/* initial setting: CHG/DIS not on */
/*#define	FDRV_CTRL_INI	(0x1600u) */	/* initial setting: CHG/DIS on */
/*#define	FDRV_CTRL_INI	(0xD000u) */	/* initial setting: CHG/DIS off, FDRV_ALM_SD, FDRV_ALM_RCV on */
#define	FDRV_CTRL_INI		(0xD080u)		/* initial setting: CHG/DIS off, FDRV_ALM_SD, FDRV_ALM_RCV on, NPD_FDRV '1', FDRVH_EN '1' */

#define	CVSEL1_INI			(0xFFFFu)
#define	CVSEL2_INI			(0x0001u)

#define	GVSEL_INI			(0x73E3u)		/* bp15 - reserved *//* TMON4SEL 'OFF', TMON3SEL 'OFF', TMON2SEL 'OFF' */

#define	FUSE_CTL1_INI		(0x0000u)		/* default settings */
#define	FUSE_CTL2_INI		(0x0000u)		/* default settings	*/
#define	FUSE_CTL3_INI		(0x000Au)		/* default settings	*/

#define	OVCTL1_INI			(0x302Eu)		/* OV_HYS: 100mV(default), OV_DLY2/OVDLY1 (default),OVTH: 4.20V */
#define	UVCTL1_INI			(0x301Au)		/* UV_HYS: 100mV(default), OV_DLY2/OVDLY1 (default), UVTH: 1.80V(default)*/
#if(1)	/* Thermistor: NCU18XH103F60RB */
#define	OTCCTL1_INI			(0x3025u)		/* OTC_HYS: 100mV(default), OTC_DLY2/OTC_DLY1 (default), OTCTH: 0x25 37 (0.71514V ~80 Cdegree ) */
#define	OTDCTL1_INI			(0x3025u)		/* OTD_HYS: 100mV(default), OTD_DLY2/OTD_DLY1 (default), OTDTH: 0x25 37 (0.71514V ~80 Cdegree ) */
#define	UTCCTL1_INI			(0x30CFu)		/* UTC_HYS: 100mV(default), UTC_DLY2/UTC_DLY1 (default), UTCTH: 0xCF 207 (4.04773V ~-10 Cdegree) */
#define	UTDCTL1_INI			(0x30CFu)		/* UTD_HYS: 100mV(default), UTD_DLY2/UTD_DLY1 (default), UTDTH: 0xCF 207 (4.04773V ~-10 Cdegree) */
#define	OTCTL2_INI			(0x2525u)		/* OTD2TH/OTC2TH: 0x25 36 (0.71514V ~80 Cdegree )  */
#define	UTCTL2_INI			(0xCFCFu)		/* UTD2TH/UTC2TH: 0xCF 207 (4.04773V ~-10 Cdegree) */
#else	/* Thermistor: JOYIN JSNB103F338FABXG */
#define	OTCCTL1_INI			(0x3025u)		/* OTC_HYS: 100mV(default), OTC_DLY2/OTC_DLY1 (default), OTCTH: 0x25 37 (0.71845V ~80 Cdegree ) */
#define	OTDCTL1_INI			(0x3025u)		/* OTD_HYS: 100mV(default), OTD_DLY2/OTD_DLY1 (default), OTDTH: 0x25 37 (0.71845V ~80 Cdegree ) */
#define	UTCCTL1_INI			(0x30CDu)		/* UTC_HYS: 100mV(default), UTC_DLY2/UTC_DLY1 (default), UTCTH: 0xCD 205 (4.00876V ~-10 Cdegree) */
#define	UTDCTL1_INI			(0x30CDu)		/* UTD_HYS: 100mV(default), UTD_DLY2/UTD_DLY1 (default), UTDTH: 0xCD 205 (4.04773V ~-10 Cdegree) */
#define	OTCTL2_INI			(0x2525u)		/* OTD2TH/OTC2TH: 0x25 36 (0.71845V ~80 Cdegree )  */
#define	UTCTL2_INI			(0xCDCDu)		/* UTD2TH/UTC2TH: 0xCD 205 (4.00876V ~-10 Cdegree) */
#endif


#define	OP_MODE_INI			(0x0F00u)		/* TMONISEL: 0, CB_SET: 0(CB OFF), UTDMSK, UTCMSK, OTDMSK, OTCMSK, UVMSK, OVMSK: 0(ON) - default	*/

#define	GPIO_CTL1_INI		(0x1000u)		/* GPIO1/TMONI1 share port: select TMONI1  */
#define	GPIO_CTL2_INI		(0x0008u)		/* GPIO2/TMONI2 share port: select GPIO2, output select - GPIO (default), GPIO2_OD Enabled (Nch Open Drain) */
#define	GPIO_CTL3_INI		(0x0008u)		/* GPIO3/TMONI3 share port: select GPIO3, output select - GPIO (default as init), use for LOSC/HOSC output, ADIRQ1 output, & LP/STBY mode, GPIO3_OD Enabled (Nch Open Drain)*/
#define GPIO3_SEL_INI		(UCHAR)((GPIO_CTL3_INI&GPIOSEL_MASK)>>8u)
#define	GPIO_CTL4_INI		(0x0D08u)		/* GPIO4/TMONI4 share port: select GPIO4, output select - output select - MCU INT OR, GPIO4_NOE Enabled, GPIO4_OD Enabled (Nch Open Drain) */

/*#define	OSC_CTL_INI			(0x6BFCu)*/		/* default 0x6B00 | 0x00FC (TMONI1~6 pull-up resistor: ON */
#define	OSC_CTL_INI			(0x6BC4u)		/* default 0x6B00 | 0x00C4 (TMONI1, 5 & 6 pull-up resistor: ON */

#define	ALARM_CTL1_INI		(0x500Fu)		/* ALARM1: enable when OV/UV, ALARM2: disable when OV/UV, SCD/OCD/OCC/CP detection: Enable */
#define	ALARM_CTL2_INI		(0x5515u)		/* ALARM1: enable when SCD/OCC/OCD/OTC/OTD/UTC/UTD, ALARM2: disable when SCD/OCC/OCD/OTC/OTD/UTC/UTD */
#define	ALARM_CTL3_INI		(0x0000u)		/* SCD TH: 20mV(min), OCD TH: 10mV(min), OCC TH: 5mV(min) */
#define	ALARM_CTL4_INI		(0x0800u)		/* SCD delay: 62.5us(default), OCD delay: 10ms(default), OCC delay: 10ms (default) */

#define	CBSEL_INI			(0x0000u)
#define	CBSEL_17_INI		(0x2700u)		/* CB_MSK2[6:0] 20msec, Measurement-oriented CB: enable */
#define	ADCTL1_INI 			(0x0000u)		/* PD_REG50: VDD50 normal, NPD_CHGPD: FDRVL pull-dwn switch control off, NPD_CB: CB control power off */

#define	ADCTL2_INI			(0x9003u)		/* ADIL_STB_EN: Continue Operation, ADIL_SEL: 250ms (default),ADSWSD_EN: ON, ADIL1&2: current ADC (Coulomb Counter) & (Wake Up Detector) Enable */
#define	GPOH_CTL_INI		(0x0000u)		/* Default */
#define	DIAG_EN_INI			(0x0000u)

#define	OTUT_CTRL_INI		(0xC008u)		/* FDRV_ALM_SD2 "1", FDRV_ALM_RCV2 "1": CHG/DIS FET response to OT/UT alarm condition; OTUT_ITH: 08h (0.17578mV * 8 = 1.40624mV) */
#define	OTUT_ITH_INI		(OTUT_CTRL_INI & OTUT_ITH_MASK)
/* BMIC Control Register Initial value definition end */


#define	BMIC_PACKET_BUF_SIZE	(200u)					/* BMS702 registers: 0x00 ~ 0x5C => 93, x2 => 186 byte, reserved 200 byte */
#define	DATA_ELEMENTSIZE		((UCHAR)0x60u)			/* BMS702 registers: 0x00 ~ 0x5C (93 elements), reserved 0x60 (96 elements) */

/* Cell Balance cell mask	*/
#define	CELL_ODD_MASK_ODDCELL	(0x00015555u)
#define	CELL_ODD_MASK_EVENCELL	(0x00009555u)

/*Cell connect bit pattern*/
#define BITPAT_4CELL			(0x00018003u)
#define BITPAT_5CELL			(0x00018007u)
#define BITPAT_6CELL			(0x0001800Fu)
#define BITPAT_7CELL			(0x0001801Fu)
#define BITPAT_8CELL			(0x0001803Fu)
#define BITPAT_9CELL			(0x0001807Fu)
#define BITPAT_10CELL			(0x000180FFu)
#define BITPAT_11CELL			(0x000181FFu)
#define BITPAT_12CELL			(0x000183FFu)
#define BITPAT_13CELL			(0x000187FFu)
#define BITPAT_14CELL			(0x00018FFFu)
#define BITPAT_15CELL			(0x00019FFFu)
#define BITPAT_16CELL			(0x0001BFFFu)
#define BITPAT_17CELL			(0x0001FFFFu)

#endif /* BMIC_REG_H */