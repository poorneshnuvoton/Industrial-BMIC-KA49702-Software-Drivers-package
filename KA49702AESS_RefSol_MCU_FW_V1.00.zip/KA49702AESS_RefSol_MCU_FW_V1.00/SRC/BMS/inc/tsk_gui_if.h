#ifndef TSK_GUI_IF_H
#define TSK_GUI_IF_H
/****************************************************************************
#ifdef DOC
File Name		:tsk_gui_if.h
Description		:
Remark			:
Date			:2020/10/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/

/****************************************************************************
 Prototype declaration
*****************************************************************************/
extern void vUartCmdRx(UCHAR rx_data);
/*#if(PCGUI_UART_TX_PDMA_USED)*/
extern void vClearTxData(void);
/*#else*/	/* PCGUI_UART_TX_PDMA_USED */
extern bool bGetUartTxData(UCHAR *tx_data);
/*#endif*/	/* PCGUI_UART_TX_PDMA_USED */

extern void vTskInit_gui_if(void);
extern void vTask_gui_if(void);

#endif /* TSK_GUI_IF_H */
