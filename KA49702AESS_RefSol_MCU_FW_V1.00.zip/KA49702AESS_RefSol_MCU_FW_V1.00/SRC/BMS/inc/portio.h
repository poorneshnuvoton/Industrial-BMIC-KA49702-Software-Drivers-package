#ifndef PORTIO_H
#define PORTIO_H
/****************************************************************************
#ifdef DOC
File Name		:portio.h
Description		:
Remark			:
Date			:2020/10/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/

/****************************************************************************
 define macro
*****************************************************************************/
#define	GPIO_PIN_RESET			0
#define	GPIO_PIN_SET			1

/*---------PORT DEFINITION-------------*/
#if(ESS_DEMO_EVB)
#define	GPIO_PORT_BMIC_SDO		PA9		/* pin10 SPI2_MISO */
#define	GPIO_PORT_BMIC_SDI		PA8		/* pin11 SPI2_MOSI */
#define	GPIO_PORT_BMIC_CLK		PA10	/* pin9 SPI2_CLK */
#define	GPIO_PORT_BMIC_SEN		PA11	/* pin8 SPI2_SS (use as GPIO) */
#else
#define	GPIO_PORT_BMIC_SDO		PC7		/* pin18 SPI1_MISO */
#define	GPIO_PORT_BMIC_SDI		PC6		/* pin19 SPI1_MOSI */
#define	GPIO_PORT_BMIC_CLK		PA7		/* pin20 SPI1_CLK */
#define	GPIO_PORT_BMIC_SEN		PA6		/* pin21 SPI1_SS (use as GPIO) */
#endif /* ESS_DEMO_EVB */

#define	GPIO_PORT_BMIC_ALARM1	PB5		/* pin2 input(default) *//* BMIC ALARM1 output, H->L: Alarm (SCD,OCD,OCC,OV,UV,OTC,OTD,UTC,UTD) */
#define	GPIO_PORT_BMIC_SHDN		PC4		/* pin36 output, L: active, H(1ms): shutdown */
#define	GPIO_PORT_BMIC_FETOFF	PC1		/* pin39 output, L: normal, H: FET force off */
/*#define	GPIO_PORT_BMIC_VPC		PC0*/		/* pin40 output, fixed L after BMIC wake-up  */
#define	GPIO_PORT_BMIC_GPIO1	PB8		/* pin63 input(default) *//* BMIC GPIO1/TMONI1 default TMONI1 */
#define	GPIO_PORT_BMIC_GPIO2	PB7		/* pin64 input(default) *//* BMIC GPIO2 used for CHGOFF boost function */
#define GPIO_PORT_BMIC_GPIO3	PB2		/* pin5 input(default) *//* BMIC GPIO/LP_ST/STB_ST/LOSC/HOSC/ADIRQ1 etc output */
#define	GPIO_PORT_BMIC_GPIO4	PB6		/* pin1 input(default) *//* BMIC MCU INT OR output, H->L: INT */

#define	GPIO_PORT_LED1			PB4		/* pin3 output, LED1(Red), L: on, H: off */
#define	GPIO_PORT_LED2			PB3		/* pin4 output, LED2(Amber), L: on, H: off */
#define	GPIO_PORT_LED3			PF6		/* pin12 output, LED3(Blue), L: on, H: off */
#define	GPIO_PORT_LED4			PC5		/* pin35 output, LED4(Green), L: on, H: off */

#define	GPIO_PORT_DIP_SW1		PD0		/* pin44 input(default) */
#define	GPIO_PORT_DIP_SW2		PD1		/* pin43 input(default) */
#define	GPIO_PORT_DIP_SW3		PD2		/* pin42 input(default) */
#define	GPIO_PORT_DIP_SW4		PD3		/* pin41 input(default) */

#define	GPIO_PORT_CAN_TXD		PB11	/* pin60 CAN_TXD */
#define	GPIO_PORT_CAN_RXD		PB10	/* pin61 CAN_RXD */
#define	GPIO_PORT_CAN_STBY		PB9		/* pin62 output, H: active, L: inactive */

#define	GPIO_PORT_UART3_TXD		PC3		/* pin37 UART3_TXD */
#define	GPIO_PORT_UART3_RXD		PC2		/* pin38 UART3_RXD */

/*---------PORT SETTING MACRO-------------*/
#define	SPI_BMIC_SEN_H()	(GPIO_PORT_BMIC_SEN = GPIO_PIN_SET)
#define	SPI_BMIC_SEN_L()	(GPIO_PORT_BMIC_SEN = GPIO_PIN_RESET)

#define	LED1_LIGHT_ON()		(GPIO_PORT_LED1 = GPIO_PIN_RESET)
#define	LED1_LIGHT_OFF()	(GPIO_PORT_LED1 = GPIO_PIN_SET)

#define	LED2_LIGHT_ON()		(GPIO_PORT_LED2 = GPIO_PIN_RESET)
#define	LED2_LIGHT_OFF()	(GPIO_PORT_LED2 = GPIO_PIN_SET)

#define	LED3_LIGHT_ON()		(GPIO_PORT_LED3 = GPIO_PIN_RESET)
#define	LED3_LIGHT_OFF()	(GPIO_PORT_LED3 = GPIO_PIN_SET)

#define	LED4_LIGHT_ON()		(GPIO_PORT_LED4 = GPIO_PIN_RESET)
#define	LED4_LIGHT_OFF()	(GPIO_PORT_LED4 = GPIO_PIN_SET)


#endif /* PORTIO_H */
