#ifndef DRV_BMIC_H
#define DRV_BMIC_H
/****************************************************************************
#ifdef DOC
File Name		:drv_bmic.h
Description		:
Remark			:
Date			:2023/10/09
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/

/****************************************************************************
 define macro
*****************************************************************************/
#define	BMIC_KA49701A			(0x01u)
#define	BMIC_KA49702A			(0x02u)

/*#define BMIC_IC_TYPE			BMIC_KA49701A	*/
#define	BMIC_IC_TYPE			BMIC_KA49702A

#define	MAX_CELL_NUM			((UCHAR)17u)
#define MIN_CELL_NUM			((UCHAR)4u)
#if(BMIC_IC_TYPE == BMIC_KA49702A)
#define	MAX_THERMISTOR_NUM		((UCHAR)6u)				/* BMIC max TMONI: 6 */
#else
#define	MAX_THERMISTOR_NUM		((UCHAR)5u)				/* BMIC max TMONI: 5 */
#endif /* BMIC_KA49702A */
#define	THERMISTOR_NUM			MAX_THERMISTOR_NUM		/* Range: 1 ~ MAX_THERMISTOR_NUM */

#define	TMONI_GROUP1			(0u)
#define	TMONI_GROUP2			(1u)

#define	TMONI_RFUSE_MAX			(12994u)				/* TMONIx internal pull-up resistance max: 12994ohm */
#define	TMONI_RFUSE_MIN			(7000u)					/* TMONIx internal pull-up resistance min:  7000ohm */

#if(BMIC_IC_TYPE == BMIC_KA49702A)
#define	TMONISEL0_GRP1_MSK		(0x17u)					/* TMONISEL 0 GROUP1 - TMONI1,2,3,5 	(01 0111) */
#define	TMONISEL0_GRP2_MSK		(0x28u)					/* TMONISEL 0 GROUP2 - TMONI4,6 		(10 1000) */
#define	TMONISEL1_GRP1_MSK		(0x13u)					/* TMONISEL 1 GROUP1 - TMONI1,2,5		(01 0011) */
#define	TMONISEL1_GRP2_MSK		(0x2Cu)					/* TMONISEL 1 GROUP2 - TMONI3,4,6		(10 1100) */
#else	/* KA49701A */
#define	TMONISEL0_GRP1_MSK		(0x0Fu)					/* TMONISEL 0 GROUP1 - TMONI1,2,3,4 	( 0 1111) */
#define	TMONISEL0_GRP2_MSK		(0x10u)					/* TMONISEL 0 GROUP2 - TMONI5	 		( 1 0000) */
#define	TMONISEL1_GRP1_MSK		(0x07u)					/* TMONISEL 1 GROUP1 - TMONI1,2,3		( 0 0111) */
#define	TMONISEL1_GRP2_MSK		(0x18u)					/* TMONISEL 1 GROUP2 - TMONI4,5			( 1 1000) */
#endif

/* Over temperature thresholds max & min in Cdegree */
#define	OT_TEMP_THMAX			(100)					/* Over Temperature threshold max 100 Cdegree */
#define	OT_TEMP_THMIN			(60)					/* Over Temperature threshold min 60 Cdegree */
#define	OT_TEMP_THINIT			(80)					/* Over Temperature threshold init 80 Cdegree */
#define	UT_TEMP_THMAX			(0)						/* Under Temperature threshold max 0 Cdegree */
#define	UT_TEMP_THMIN			(-40)					/* Under Temperature threshold min -40 Cdegree */
#define	UT_TEMP_THINIT			(-10)					/* Under Temperature threshold init -10 Cdegree */

/*#define 								(0x0001u)*/		/* bp0 not used										*/
/*#define 								(0x0002u)*/		/* bp1 not used                                     */
#define ERR_IC_SHUTDOWN					(0x0004u)		/* bp2 bit position depends on BMIC(MODE STAT)      */
/*#define 								(0x0008u)*/		/* bp3 not used									   	*/
#define ERR_OVER_CURRENT_CHARGE			(0x0010u)		/* bp4 bit position depends on BMIC(STAT)           */
#define ERR_OVER_CURRENT_DISCHARGE		(0x0020u)		/* bp5 bit position depends on BMIC(STAT)           */
#define ERR_SHORT_CIRCUIT_DET			(0x0040u)		/* bp6 bit position depends on BMIC(STAT)           */
/*#define 								(0x0080u)*/		/* bp7 not used                                     */
#define ERR_UNDER_VOLTAGE				(0x0100u)		/* bp8 bit position depends on BMIC(STAT)           */
#define ERR_OVER_VOLTAGE				(0x0200u)		/* bp9 bit position depends on BMIC(STAT)           */
/*#define 								(0x0400u)*/		/* bp10 not used                                    */
/*#define 								(0x0800u)*/		/* bp11 not used                                    */
#define ERR_UNDER_TEMP_CHARGE			(0x1000u)		/* bp12 - depend on BMIC(STAT5)                     */
#define ERR_UNDER_TEMP_DISCHARGE		(0x2000u)		/* bp13 - depend on BMIC(STAT5)                     */
#define ERR_OVER_TEMP_CHARGE			(0x4000u)		/* bp14 - depend on BMIC(STAT5) 					*/
#define ERR_OVER_TEMP_DISCHARGE			(0x8000u)		/* bp15	- depend on BMIC(STAT5) 					*/
#define MASK_CURRENT_ERR				(0x0070u)		/* bp4~6: current related errors					*/
#define	MASK_VOLTAGE_ERR				(0x0300u)		/* bp9~8: voltage related errors 					*/
#define MASK_TEMPERATURE_ERR			(0xF000u)		/* bp15~12: temperature related errors				*/
#define	MASK_TEMP_VOL_CUR_ERR			(0xF370u)		/* bp15~12, 9~8, 6~4: temperature, voltage and current related errors */
#define	MASK_TEMP_CUR_ERR				(0xF070u)		/* bp15~12, 6~4*/

#define	BMIC_DATA_INPUT_NONE			(0u)
#define	BMIC_DATA_INPUT_NEED			(1u)

#define USE_GPOH_FET					(1u)
#define NOT_USE_GPOH_FET				(0u)

#define	FET_ON							(1u)
#define	FET_OFF							(0u)

#define	ADIL_SLOW_CYCLE_500ms			(2u)			/* KA49701: 500ms/250ms = 2 */
#define	ADIL_FAST_CYCLE_500MS			(16u)			/* KA49701 & other: 500ms/31.25ms = 16	*/
#define	ADIL_DATA_NUM_31_25MS			(ADIL_FAST_CYCLE_500MS)
#define	ADIL_DATA_NUM_62_50MS			(ADIL_FAST_CYCLE_500MS/2u)
#define	ADIL_DATA_NUM_250MS				(ADIL_SLOW_CYCLE_500ms)


/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/
typedef struct {
	bool	BMICMeasured;
	LONG	lBatPackCur_100uA;				/* Pack Current in 100uA */
	ULONG	ulBlkVol_uV[MAX_CELL_NUM];		/* Cell voltage in uV	*/
	SHORT	sTemp_01Cdeg[THERMISTOR_NUM];	/* Temperature in 01Cdeg	*/
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	ULONG	ulVPACKAD_uV;					/* VPACK_AD voltage in uV	*/
#else
	ULONG	ulCV17SAD_uV;					/* CV17S_AD voltage in uV	*/
#endif /* BMIC_KA49702A */
	ULONG	ulVdd50V_uV;					/* VDD50 voltage in uV   */
	ULONG	ulVdd15V_uV;					/* VDD15 voltage in uV   */
	ULONG	ulVRegextV_uV;					/* REGEXT voltage in uV  */
	ULONG	ulVref2V_uV;					/* VREF2 voltage in uV   */
	#if(0)	/* VREF1 not used */
	ULONG	ulVref1V_uV;					/* VREF1 voltage in uV   */
	#endif

#if(BMIC_IC_TYPE == BMIC_KA49702A)
	ULONG	ulGPIOH1V_uV;					/* GPIOH1 voltage in uV */
	ULONG	ulGPIOH2V_uV;					/* GPIOH2 voltage in uV */
#else
	ULONG	ulGPIO1V_uV;					/* GPIO1 voltage in uV */
	ULONG	ulGPIO2V_uV;					/* GPIO2 voltage in uV */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */

	ULONG	ulVpackSumV_uV;					/* Summed Pack Total voltage in uV	*/

	USHORT	usBatPackCur_10mA_300A;			/* Pack Current in 10mA and with 300A offset */
	ULONG	ulBatPackMinBlkVol_uV;			/* Lowest Cell voltage in uV	*/
	ULONG	ulBatPackMaxBlkVol_uV;			/* Highest Cell voltage in uV	*/

	ULONG	ulBatPackErr;					/* Pack Error Info */
	ULONG	ulBatPackErrLog;				/* Pack Error Log */

}TBMIC_Info;

/*--------------------------------------------*/
typedef struct {
	ULONG	ulCellPos;						/* Cell connection position																				*/
	UCHAR	ucSeriesCount;					/* Number of cell in series                                       */
	UCHAR	ucTmoniTempCount;				/* Number of thermistors for temperature detection (num of TMONIx)*/
	ULONG	ulTmoniTempPos;					/* TMONIx temperature thermistor connection position                */
}TBMICCellConf;

/*--------------------------------------------*/
typedef struct {
	USHORT	usOVInfo_vol;					/* Over Voltage (OV) detection threshold (mV)				*/
	UCHAR	ucOVInfo_delay1;				/* Over Voltage (OV) detection delay (4/8/16/32 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms. (Active mode)) */
	UCHAR	ucOVInfo_delay2;				/* Over Voltage (OV) detection delay (1/2/4/8 times of voltage measurement cycle of 1s/2s/4s/8s INTM_TIM2 register setting time(Stby/LP mode)) */
	USHORT	usOVInfo_hys;					/* Over Voltage (OV) hysteresis level (mV)					*/

	USHORT	usUVInfo_vol;					/* Under Voltage (UV) detection threshold (mV)              */
	UCHAR	ucUVInfo_delay1;				/* Under Voltage (UV) detection delay (4/8/16/32 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms. (Active mode)) */
	UCHAR	ucUVInfo_delay2;				/* Under Voltage (UV) detection delay (1/2/4/8 times of voltage measurement cycle of 1s/2s/4s/8s INTM_TIM2 register setting time(Stby/LP mode)) */
	USHORT	usUVInfo_hys;					/* Under Voltage (UV) hysteresis level (mV)					*/

	USHORT	usOCCInfo_cur;					/* Over Current at Charge (OCC) detection threshold (A)		*/
	USHORT	usOCCInfo_delay;				/* Over Current at Charge (OCC) detection delay (msec)		*/
	USHORT	usOCDInfo_cur;					/* Over Current at Discharge (OCD) detection threshold (A)	*/
	USHORT	usOCDInfo_delay;				/* Over Current at Discharge (OCD) detection delay (msec)	*/
	USHORT	usSCDInfo_cur;					/* Short Circuit at Discharge (SCD) detection threshold (A)	*/
	ULONG	ulSCDInfo_delay;				/* Short Circuit at Discharge (SCD) detection delay (usec)	*/

	SHORT	sOTC1Info_temp;					/* Over Temperature in Charge (OTC) detection threshold (Temperature)(for Grp1) */
	SHORT	sOTC2Info_temp;					/* Over Temperature in Charge (OTC) detection threshold (Temperature)(for Grp2) */
	UCHAR	ucOTCInfo_delay1;				/* Over Temperature in Charge (OTC) ALARM delay (4/8/16/32 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms. (Active mode)) */
	UCHAR	ucOTCInfo_delay2;				/* Over Temperature in Charge (OTC) ALARM delay (1/2/4/8 times of voltage measurement cycle of 1s/2s/4s/8s INTM_TIM2 register setting time(Stby/LP mode)) */
	USHORT	usOTCInfo_hys;					/* Over Temperature in Charge (OTC) detection hysteresis level(mv) */

	SHORT	sOTD1Info_temp;					/* Over Temperature in Discharge (OTD) detection threshold (temperature)(for Grp1) */
	SHORT	sOTD2Info_temp;					/* Over Temperature in Discharge (OTD) detection threshold (temperature)(for Grp2) */
	UCHAR	ucOTDInfo_delay1;				/* Over Temperature in Discharge (OTD) ALARM delay (4/8/16/32 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms. (Active mode)) */
	UCHAR	ucOTDInfo_delay2;				/* Over Temperature in Discharge (OTD) ALARM delay (1/2/4/8 times of voltage measurement cycle of 1s/2s/4s/8s INTM_TIM2 register setting time(Stby/LP mode)) */
	USHORT	usOTDInfo_hys;					/* Over Temperature in Discharge (OTD) detection hysteresis level(mv) */

	SHORT	sUTC1Info_temp;					/* Under Temperature in Charge (UTC) detection threshold (temperature)(for Grp1) */
	SHORT	sUTC2Info_temp;					/* Under Temperature in Charge (UTC) detection threshold (temperature)(for Grp2) */
	UCHAR	ucUTCInfo_delay1;				/* Under Temperature in Charge (UTC) ALARM delay (4/8/16/32 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms. (Active mode)) */
	UCHAR	ucUTCInfo_delay2;				/* Under Temperature in Charge (UTC) ALARM delay (1/2/4/8 times of voltage measurement cycle of 1s/2s/4s/8s INTM_TIM2 register setting time(Stby/LP mode)) */
	USHORT	usUTCInfo_hys;					/* Under Temperature in Charge (UTC) detection hysteresis level(mv) */

	SHORT	sUTD1Info_temp;					/* Under Temperature in Discharge (UTD) detection threshold (Temperature)(for Grp1) */
	SHORT	sUTD2Info_temp;					/* Under Temperature in Discharge (UTD) detection threshold (Temperature)(for Grp2) */
	UCHAR	ucUTDInfo_delay1;				/* Under Temperature in Discharge (UTD) ALARM delay (4/8/16/32 times of voltage measurement cycle of 31.25ms/62.5ms/125ms/250ms. (Active mode)) */
	UCHAR	ucUTDInfo_delay2;				/* Under Temperature in Discharge (UTD) ALARM delay (1/2/4/8 times of voltage measurement cycle of 1s/2s/4s/8s INTM_TIM2 register setting time(Stby/LP mode)) */
	USHORT	usUTDInfo_hys;					/* Under Temperature in Discharge (UTD) detection hysteresis level(mv) */

	USHORT	usOTUT_ITHInfo_mA;				/* Current threshold to switch between Charging and Discharging in mA */

	USHORT	usOTUT_MSK;						/* settins for UTDMSK | UTCMSK | OTDMSK | OTCMSK */
}TBMICSetParam;


/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/
enum {
	BMIC_STARTUP = (UCHAR)0u,
	BMIC_NORMAL,
	BMIC_SPIERR,
	BMIC_RESTART,
	BMIC_SHUTDOWN,
#if(BMS_STANDBYMODE_SUPPORT)
	BMIC_LOWPOWER,
	BMIC_STANDBY,
	BMIC_SLEEP,
#endif	/* BMS_STANDBYMODE_SUPPORT */
#if(BMS_DIAGNOSTIC_SUPPORT)
	BMIC_DIAGNOSTIC
#endif /* BMS_DIAGNOSTIC_SUPPORT */
}; /* static ucBMIC_Ctrl_Status */


#if(BMS_STANDBYMODE_SUPPORT)
enum {
	BMIC_OPEMODE_SHUTDOWN = (UCHAR)0u,
	BMIC_OPEMODE_ACTIVE,
	BMIC_OPEMODE_LOWPOWER,
	BMIC_OPEMODE_STANDBY,
	BMIC_OPEMODE_SLEEP
};
#endif	/* BMS_STANDBYMODE_SUPPORT */


enum {
	BMIC_GPIO1 = (UCHAR)0u,
	BMIC_GPIO2,
	BMIC_GPIO3,
	BMIC_GPIO4
};

enum {
	GPIO_SEL_GPIO = (UCHAR)0x00u,		/* 0x00	*/
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	GPIO_SEL_GPIOH1,					/* 0x01 */
	GPIO_SEL_GPIOH2,					/* 0x02 */
#else
/*	GPIO_SEL_GPIO1,	*/                  /* 0x01	*/
/*	GPIO_SEL_GPIO2, */                  /* 0x02	*/
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
	GPIO_SEL_ADIRQ1 = (UCHAR)0x03u,		/* 0x03	*/
	GPIO_SEL_ADIRQ2,                    /* 0x04	*/
	GPIO_SEL_HOSC,                      /* 0x05	*/
	GPIO_SEL_LOSC,                      /* 0x06	*/
	GPIO_SEL_ACTST,                     /* 0x07	*/
	GPIO_SEL_STBST,                     /* 0x08	*/
	GPIO_SEL_LPST,                      /* 0x09	*/
	GPIO_SEL_FUSEFET,                   /* 0x0A	*/
	GPIO_SEL_ALARM2,                    /* 0x0B	*/
										/* 0x0C *//* Prohibited */
	GPIO_SEL_MCUINTOR = (UCHAR)0x0Du,	/* 0x0D */
#if(BMIC_IC_TYPE == BMIC_KA49701A)
	GPIO_SEL_0E,						/* 0x0E *//* GPIO1 - not used, GPIO2/3/4 - CHGOFF_BOOST */
	GPIO_SEL_FET_OUTPUT					/* 0x0F *//* GPIO1/3 - Charge FET output, GPIO2/4 - Discharge FET output */
#else
	GPIO_SEL_0E							/* 0x0E *//* GPIO1 - FETOFF2IN, GPIO2/3/4 - CHGOFF_BOOST */
										/* 0x0F *//* Prohibited */
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */
#if(BMIC_IC_TYPE == BMIC_KA49702A)
	,GPIO_SEL_TMONI = (UCHAR)0x10u		/* 0x10 *//* TMONIx function selection */
#endif
};

#if(1 /* BMIC_IC_TYPE == BMIC_KA49702A */)
#define	GPIOn_SEL_CHGOFFBOOST	GPIO_SEL_0E
#else
/* BMIC_KA49701A(ES) */
#define	GPIO1_SEL_FETOFF2		GPIO_SEL_0E
#define	GPIOn_SEL_CHGOFFBOOST	GPIO_SEL_0E
#endif	/* BMIC_IC_TYPE == BMIC_KA49702A */


/****************************************************************************
 Variable declaration
*****************************************************************************/
extern TBMICCellConf		BMICCellConf;
extern TBMIC_Info			BMIC_Info;
extern TBMICSetParam 		BMICSetParam;

#if(0/*BMS_STANDBYMODE_SUPPORT*/)
extern USHORT usActiveComm_cnt;
#endif /* BMS_STANDBYMODE_SUPPORT */
/****************************************************************************
 Prototype declaration
*****************************************************************************/
extern void vBMIC_InitParams(void);
extern void vBMIC_Send_OVCTL1(void);
extern void vBMIC_Send_UVCTL1(void);
extern void vBMIC_Send_OTCCTL1(void);
extern void vBMIC_Send_OTDCTL1(void);
extern void vBMIC_Send_UTCCTL1(void);
extern void vBMIC_Send_UTDCTL1(void);
extern void vBMIC_Send_OTCTL2(void);
extern void vBMIC_Send_UTCTL2(void);
extern void vBMIC_Send_OTUTITH(void);
extern void vBMIC_Send_OTUTMSK(void);
extern void vBMIC_Send_ALARM_CTL3(void);
extern void vBMIC_Send_ALARM_CTL4(void);
extern UCHAR getBMIC_Ctrl_Status(void);
extern void vBMIC_Ctrl_Startup(void);
extern void vBMIC_Ctrl_Normal(void);
extern void vBMIC_Ctrl_SpiErr(void);
extern void vBMIC_Ctrl_Restart(void);
extern void vBMIC_Ctrl_Shutdown(void);
extern void vBMIC_ShutdownRequest(void);
#if(BMS_DIAGNOSTIC_SUPPORT)
extern void vBMIC_Ctrl_Diagnostic(void);
extern void vBMIC_Diagnostic_Req(UCHAR req);
#endif /* BMS_DIAGNOSTIC_SUPPORT */

#if(BMS_STANDBYMODE_SUPPORT)
extern void vBMIC_Ctrl_RetToActive(void);
extern void vBMIC_Ctrl_Sleep(void);
extern void vBMIC_Ctrl_WakeupWait(void);
extern void vBMIC_Ctrl_ShdnWakeupWait(void);
extern void vBMIC_ChgOpeMode(UCHAR ucOpeMode);
extern UCHAR ucGet_BMICOpeMode(void);
extern void vBMIC_Set_OpeMode_Req(UCHAR req_flg);
extern void vBMIC_SetOpeModeExtChk(void);
#endif	/* BMS_STANDBYMODE_SUPPORT */

extern UCHAR ucBMIC_Send_Req(UCHAR addr, USHORT data, USHORT mask, UCHAR mask_req);
extern void vBMIC_SetCellbalanceReq(ULONG target, UCHAR cb_on_time, UCHAR cb_off_time);
extern ULONG ulBMIC_GetCellbalanceReqPack(void);
extern ULONG ulBMIC_GetCellbalanceReq(void);
extern void vBMIC_GetCellbalanceONOFFtime(UCHAR *cb_on_time, UCHAR *cb_off_time);
extern bool bBMIC_ChkCellbalance(void);

extern void vBMIC_Discharge_FET_Out(UCHAR output);
extern void vBMIC_Charge_FET_Out(UCHAR output);
extern void vBMIC_SHDN_Out(UCHAR output);
extern void vBMIC_FETOFF_Out(UCHAR output);
extern UCHAR ucGetBMIC_ALARM1_In(void);
extern USHORT usBMIC_ReadReg(UCHAR addr);
extern USHORT usBMICReferRegData(UCHAR addr);
extern bool bBMICCheckSpiResult(void);
extern UCHAR ucGetBMIC_SpiErrDetail(void);
extern void vBMIC_Clear_Spi_Err_counter(void);
extern bool bBMIC_ChkSpiMiso(void);
extern void vBMIC_Send_PDREG50en(UCHAR pdreg50en);
extern ULONG ulBMIC_GetBatPackErr(void);

extern void vBMIC_UpdateCtrlStatus(UCHAR ctrlsts);
extern void Wait_msec(USHORT time_inms);
extern void	wait100us(void);
extern void vBMICWriteReg(UCHAR addr, USHORT data);

extern void vBMIC_Set_GPIO_PortSel(UCHAR ucgpio, UCHAR ucport);
extern UCHAR ucGetBMIC_ADIL_LogData(UCHAR *bufadr, UCHAR ucLog);
extern UCHAR ucGetADIL_DataLogStatus(void);
#endif /* DRV_BMIC_H */
