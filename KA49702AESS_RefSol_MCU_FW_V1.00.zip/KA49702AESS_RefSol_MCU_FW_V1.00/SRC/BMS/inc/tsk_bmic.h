#ifndef TSK_BMIC_H
#define TSK_BMIC_H
/****************************************************************************
#ifdef DOC
File Name		:tsk_bmic.h
Description		:
Remark			:
Date			:2020/10/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/

/****************************************************************************
 define macro
*****************************************************************************/
#define	BMIC_SPI_STATUS_WRITE_ERR		(0x01u)
#define	BMIC_SPI_STATUS_READ_ERR		(0x02u)
#define	BMIC_SPI_STATUS_WAKEUP_ERR		(0x0Fu)

#define	BMIC_OPE_FET_CHG_ON				(0x10u)
#define	BMIC_OPE_FET_DIS_ON				(0x20u)
#define	BMIC_OPE_CELL_BALANCE			(0x40u)
#define	BMIC_OPE_STATUS_NORMAL			(0x80u)


/****************************************************************************
 Prototype declaration
*****************************************************************************/

extern void vTskInit_bmic(void);
extern void vTsk_bmic(void);

extern UCHAR	ucGetBMIC_status1(void);
extern UCHAR	ucGetBMIC_status2(void);

extern UCHAR ucCheckOpeModeComm(UCHAR CurOpeMode, UCHAR register_adr,USHORT register_data);
extern void vChangeOpeModeReq(USHORT CurOpeMode, USHORT* register_data);
#endif /* TSK_BMIC_H */
