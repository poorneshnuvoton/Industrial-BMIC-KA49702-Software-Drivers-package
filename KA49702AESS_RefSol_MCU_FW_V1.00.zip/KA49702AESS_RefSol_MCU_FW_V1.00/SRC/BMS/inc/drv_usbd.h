#ifndef DRV_USBD_H
#define DRV_USBD_H
/****************************************************************************
#ifdef DOC
File Name		:drv_usbd.h
Description		:
Remark			:
Date			:2025/01/21
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/

/****************************************************************************
 define macro
*****************************************************************************/


/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/

/****************************************************************************
 Prototype declaration
*****************************************************************************/
extern void vUSBD_Init(void);
extern void vUSBD_main(void);
//extern void VCOM_TransferData(void);
extern void VCOM_USBDTransferOutData(UCHAR data);


#endif /* DRV_USBD_H */
