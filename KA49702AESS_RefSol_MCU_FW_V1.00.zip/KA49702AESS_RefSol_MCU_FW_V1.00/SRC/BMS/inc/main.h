#ifndef MAIN_H
#define MAIN_H
/****************************************************************************
#ifdef DOC
File Name		:main.h
Description		:
Remark			:
Date			:2020/10/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/

/****************************************************************************
 define macro
*****************************************************************************/
#define	HXT_DISABLE				(0u)	/* "0" used external CLK , "1" using internal CLK */
#define PCGUI_IF_USB			(1u)

#if(HXT_DISABLE)
#define CRYSTAL_LESS				0
#else
#define CRYSTAL_LESS				0/*0*/
#endif
#define TRIM_INIT					(SYS_BASE+0x10C)



#if(PCGUI_IF_USB)
#define	PCGUI_UART_TX_PDMA_USED	(0u)
#else
#define	PCGUI_UART_TX_PDMA_USED	(1u)
#endif	/* PCGUI_IF_USB */
#define	BMIC_SPI_PDMA_USED		(0u)

#define	PDMA_USED	(PCGUI_UART_TX_PDMA_USED | BMIC_SPI_PDMA_USED)

#if(PDMA_USED)
#define	BMIC_SPI_TX_PDMA_CH		(0u)
#define	BMIC_SPI_RX_PDMA_CH		(1u)
#define	PCGUI_UART_TX_PDMA_CH	(2u)
#endif	/* PDMA_USED */

#define	BMS_FETSTATE_CTRL		(1u)
#define	BMS_STANDBYMODE_SUPPORT	(1u)	/* Enable 1: support bmic standby/lower power/sleep mode */
#define BMS_DIAGNOSTIC_SUPPORT	(1u)	/* BMS diagnostic function : 1 (Enable), 0 (Disable) */
#define	DIAGNOSTIC_SRPSRN		(1u)	/* BMS diagnostic - SRP/SRN Open & Short Detection: 1 (Enable), 0 (Disable) */

#define BMS_TESTMODE			(1u)	/* Enable 1: Support test mode, Continuous Read/Write */

#define	BMS_ERRSTS_MANUALCLR	(1u)	/* Enable 1: BMS Error status need manually cleared from GUI */

#define ESS_DEMO_CB				(1u)	/* 0: RefSol CB ctl, 1: ESS Demo CB */
#define ESS_DEMO_EVB			(1u)	/* 0: BMS702 MCU Evb, 1: ESS Demo Evb */
/**********************************************************************************************************************************************
					RefSol CB ctrl											|	ESS Demo CB ctrl
(a) CB ON/OFF time: 500ms~1500ms											|	1sec~15sec;
(b) CB ctrl states: ODD CELL CB ->CB OFF ->EVEN CELL CB ->CB OFF			|	CB ON -> CB OFF
(c) Adjacent cells selection: Allowed										|	Not allowed
(d) When EN_MSOCB ON & OFF: loops for CB ctrl states (CB ON & OFF alternate)|   When EN_MSOCB ON:	loops for CB ctrl state (CB ON & OFF alternate)
																			|   When EN_MSOCB OFF: CB ON only
***********************************************************************************************************************************************/

/****************************************************************************
 Variable declaration
*****************************************************************************/


/****************************************************************************
 Prototype declaration
*****************************************************************************/
extern void vTskInit_led(void);
extern void vTsk_led(void);

#if(BMS_FETSTATE_CTRL)
extern void	vTskInit_sys(void);
extern void vTsk_sys(void);
extern UCHAR ucGetBMIC_status3(void);
extern bool bSetFETCtrlMode(UCHAR ucMode);
extern UCHAR ucGetFETCtrlMode(void);
extern void vGetCurrentProtectSetting(UCHAR *desadr, UCHAR *size);
extern UCHAR ucSetProtectSetting(UCHAR *srcadr, UCHAR size);
#endif	/* BMS_FETSTATE_CTRL */

#if(BMS_TESTMODE)
extern UCHAR ucTestMode_Req(UCHAR ucMode, UCHAR ucReq);
extern USHORT usGet_CVADLog(UCHAR cellno, UCHAR cnt);
extern UCHAR ucTM_ContiWriteReq(UCHAR *data);
extern UCHAR ucTM_ContiRWReq(UCHAR *data);
extern void vCtrl_ContinuousRWReg(void);
extern UCHAR ucGetTM_ContiRWReq(UCHAR *Data);
#endif	/* BMS_TESTMODE */

#if defined(SUPPORT_FWUPDATE)
/* upd_prepare */
extern void vSetUPD_PrepareReq(void);
extern void vUPD_Prepare(void);
#endif	/* SUPPORT_FWUPDATE */

#endif /* MAIN_H */
