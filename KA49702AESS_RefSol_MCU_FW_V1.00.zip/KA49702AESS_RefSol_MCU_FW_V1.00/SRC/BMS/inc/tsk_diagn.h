#ifndef TSK_DIAGN_H
#define TSK_DIAGN_H
/****************************************************************************
#ifdef DOC
File Name		:tsk_diagn.h
Description		:
Remark			:
Date			:2022/06/28
Copyright		:Nuvoton Technology Singapore
#endif
*****************************************************************************/

/****************************************************************************
 define macro
*****************************************************************************/
#define DIAGN_INVALID		(0xFFFFFFFF)
#define DIAGN_ERROR_STS		(0xFF)

/* PC GUI diagnostic request type */
#define DIAGN_NEW_REQ		(0x00)
#define DIAGN_STS_REQ		(0x01)
#define DIAGN_RESULT_REQ	(0x02)

#define REQ_LS_CUR_ADC		(0x00000002u)
#define REQ_DIAGN_OSCH		(0x00000000u)
#define REQ_DIAGN_OSCL		(0x00000001u)

/****************************************************************************
 define type (STRUCTURE, UNION)
*****************************************************************************/

/****************************************************************************
 define type (Enumerated type ENUM)
*****************************************************************************/
typedef enum{
	eBMS_DIAGN_CUR_ADC = 1u,                     /* 0x01 Current ADC Diagnostic  */
	eBMS_DIAGN_REGULATOR,						/* 0x02 Regulator Diagnostic */
	eBMS_DIAGN_VREF2,                     		/* 0x03 VREF2 Diagnostic */
	eBMS_DIAGN_MEASUREMENT_SEQ,					/* 0x04 Measurement Sequence Diagnostic */
	eBMS_DIAGN_OSC_CLOCK,                  		/* 0x05 Internal OSC clock Diagnostic */
	eBMS_DIAGN_OPEN_DETECTION,					/* 0x06 Open connection detection Diagnostic */
#if(DIAGNOSTIC_SRPSRN)
	eBMS_DIAGN_SRPSRN_OPENSHORT,				/* 0x07 SRP/SRN Open & Short Detection Diagnostic */
#endif	/* DIAGNOSTIC_SRPSRN */
	eBMS_DIAGN_MAX,
	eBMS_DIAGN_NO_REQ = 0xFFu
}eBMS_DIAGN_REQ;

typedef enum{
	eBMS_DIAGN_NONE = 0u,
	eBMS_DIAGN_START,
	eBMS_DIAGN_INPROGRESS,
	eBMS_DIAGN_COMPLETED,
	eBMS_DIAGN_ERROR = 0xFFu
}eBMS_DIAGN_STS;

/****************************************************************************
 Variable declaration
*****************************************************************************/
extern UCHAR ucdiag_ret_result_flg;

/****************************************************************************
 Prototype declaration
*****************************************************************************/

/* BMIC Safety Diagnostic Function */
extern bool bSetDiag_req(UCHAR ucReq, ULONG ulDetail);
extern void vSetDiag_sts(UCHAR status);
extern UCHAR ucGetDiag_sts(void);
extern UCHAR ucGetDiag_req(void);
extern ULONG ulGetDiag_result(void);
extern bool bValidateDiag_req(UCHAR ucReq, ULONG ulDetail);

extern void vTskInit_Diag(void);
extern void vTskSet_Diag(eBMS_DIAGN_REQ req);
extern void vTskMonitor_Diag(eBMS_DIAGN_REQ req);

#endif /* TSK_DIAGN_H */
